package com.th4.edge.decoboon.clue.asset.configure;

import com.th4.edge.framework.core.Attribute;
import com.th4.edge.framework.core.annotation.Note;

@Note("AI 解读状态")
public enum AiStatus implements Attribute<String> {
    Pending("待解读"),
    Processing("解读中"),
    Done("已解读"),
    Failed("解读失败");

    private final String name;

    AiStatus(String name) {
        this.name = name;
    }

    @Override
    public String getValue() {
        return toString();
    }

    @Override
    public String getName() {
        return name;
    }
}

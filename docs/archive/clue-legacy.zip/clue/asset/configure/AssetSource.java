package com.th4.edge.decoboon.clue.asset.configure;

import com.th4.edge.framework.core.Attribute;
import com.th4.edge.framework.core.annotation.Note;

@Note("素材来源")
public enum AssetSource implements Attribute<String> {
    SiteShoot("工地拍摄"),
    Customer("客户提供"),
    Designer("设计师"),
    Marketing("营销物料");

    private final String name;

    AssetSource(String name) {
        this.name = name;
    }

    @Override
    public String getValue() {
        return toString();
    }

    @Override
    public String getName() {
        return name;
    }
}

package com.th4.edge.decoboon.clue.asset.configure;

import com.th4.edge.framework.core.Attribute;
import com.th4.edge.framework.core.annotation.Note;

@Note("施工阶段")
public enum AssetStage implements Attribute<String> {
    Demolition("拆除"),
    WaterElectric("水电"),
    MasonryWood("泥木"),
    Paint("油漆"),
    Finished("完工");

    private final String name;

    AssetStage(String name) {
        this.name = name;
    }

    @Override
    public String getValue() {
        return toString();
    }

    @Override
    public String getName() {
        return name;
    }
}

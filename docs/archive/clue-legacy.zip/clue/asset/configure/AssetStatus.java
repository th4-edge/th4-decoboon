package com.th4.edge.decoboon.clue.asset.configure;

import com.th4.edge.framework.core.Attribute;
import com.th4.edge.framework.core.annotation.Note;

@Note("素材状态")
public enum AssetStatus implements Attribute<String> {
    Draft("草稿"),
    Stored("已入库"),
    Disabled("已停用"),
    Deleted("已删除");

    private final String name;

    AssetStatus(String name) {
        this.name = name;
    }

    @Override
    public String getValue() {
        return toString();
    }

    @Override
    public String getName() {
        return name;
    }
}

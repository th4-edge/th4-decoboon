package com.th4.edge.decoboon.clue.asset.configure;

import com.th4.edge.framework.core.Attribute;
import com.th4.edge.framework.core.annotation.Note;

@Note("素材类型")
public enum AssetType implements Attribute<String> {
    Video("短视频"),
    Image("照片"),
    Audio("语音"),
    FloorPlan("户型图"),
    Banner("锦旗"),
    Record("留痕材料");

    private final String name;

    AssetType(String name) {
        this.name = name;
    }

    @Override
    public String getValue() {
        return toString();
    }

    @Override
    public String getName() {
        return name;
    }
}

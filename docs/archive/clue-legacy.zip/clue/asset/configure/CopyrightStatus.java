package com.th4.edge.decoboon.clue.asset.configure;

import com.th4.edge.framework.core.Attribute;
import com.th4.edge.framework.core.annotation.Note;

@Note("版权状态")
public enum CopyrightStatus implements Attribute<String> {
    OwnCommercial("自有可商用"),
    CustomerAuthorized("客户授权"),
    NeedConfirm("需确认");

    private final String name;

    CopyrightStatus(String name) {
        this.name = name;
    }

    @Override
    public String getValue() {
        return toString();
    }

    @Override
    public String getName() {
        return name;
    }
}

package com.th4.edge.decoboon.clue.asset.model;

import jakarta.persistence.AttributeOverride;
import jakarta.persistence.AttributeOverrides;
import jakarta.persistence.Embedded;

import com.th4.edge.decoboon.clue.asset.configure.AiStatus;
import com.th4.edge.decoboon.clue.asset.configure.AssetSource;
import com.th4.edge.decoboon.clue.asset.configure.AssetStage;
import com.th4.edge.decoboon.clue.asset.configure.AssetStatus;
import com.th4.edge.decoboon.clue.asset.configure.AssetType;
import com.th4.edge.decoboon.clue.asset.configure.CopyrightStatus;
import com.th4.edge.decoboon.clue.company.model.Employee;
import com.th4.edge.framework.core.annotation.Description;
import com.th4.edge.framework.core.annotation.Note;
import com.th4.edge.framework.core.annotation.Unit;
import com.th4.edge.framework.data.date.model.DateTime;
import com.th4.edge.framework.data.jpa.annotation.Model;
import com.th4.edge.framework.data.jpa.keyword.annotation.Keyword;
import com.th4.edge.framework.data.model.AbstractModel;
import com.th4.edge.framework.data.model.prepare.annotation.CreateTime;
import com.th4.edge.framework.data.model.prepare.annotation.UpdateTime;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Note("素材")
@Description("家装内容生产素材：工地照片/视频/户型图/锦旗/留痕材料，含 AI 解读与版权信息")
@Model
@Entity
@Table(name = "db_clue_asset")
public class Asset extends AbstractModel {

    @Note("素材索引")
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long assetId;

    @Note("归属业务员")
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "emp_id", nullable = false)
    private Employee emp;

    @Note("素材类型")
    @Column(nullable = false, length = 16)
    private AssetType type;

    @Note("素材标题/说明")
    @Keyword
    @Column(length = 128)
    private String title;

    @Note("OSS 地址")
    @Column(nullable = false, length = 512)
    private String url;

    @Note("缩略图")
    @Column(length = 512)
    private String thumbUrl;

    @Note("文件格式")
    @Column(length = 16)
    private String fileFormat;

    @Note("大小")
    @Unit("MB")
    @Column
    private Long size;

    @Note("小区/楼盘")
    @Keyword
    @Column(length = 64)
    private String community;

    @Note("户型")
    @Keyword
    @Column(length = 32)
    private String houseType;

    @Note("风格")
    @Keyword
    @Column(length = 32)
    private String style;

    @Note("施工阶段")
    @Column(length = 32)
    private AssetStage stage;

    @Note("面积")
    @Unit("㎡")
    @Column
    private Long area;

    @Note("素材来源")
    @Column(length = 32)
    private AssetSource source;

    @Note("版权状态")
    @Column(length = 32)
    private CopyrightStatus copyrightStatus;

    @Note("AI 解读状态")
    @Column(length = 32)
    private AiStatus aiStatus = AiStatus.Pending;

    @Note("素材状态")
    @Column(length = 32)
    private AssetStatus status = AssetStatus.Stored;

    @Note("拍摄工地备注")
    @Keyword
    @Column(length = 256)
    private String remark;

    @Note("AI 视觉识别内容描述")
    @Keyword
    @Column(length = 1024)
    private String description;

    @Note("被引用次数")
    @Column
    private Long usageCount = 0L;

    @Note("创建时间")
    @CreateTime
    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "dateTime", column = @Column(name = "create_dateTime")),
            @AttributeOverride(name = "date", column = @Column(name = "create_date")),
            @AttributeOverride(name = "time", column = @Column(name = "create_time")),
            @AttributeOverride(name = "year", column = @Column(name = "create_year")),
            @AttributeOverride(name = "month", column = @Column(name = "create_month")),
            @AttributeOverride(name = "day", column = @Column(name = "create_day")),
            @AttributeOverride(name = "hour", column = @Column(name = "create_hour")),
            @AttributeOverride(name = "minute", column = @Column(name = "create_minute")),
            @AttributeOverride(name = "second", column = @Column(name = "create_second")),
            @AttributeOverride(name = "week", column = @Column(name = "create_week")),
    })
    private DateTime createTime;

    @Note("更新时间")
    @UpdateTime
    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "dateTime", column = @Column(name = "update_dateTime")),
            @AttributeOverride(name = "date", column = @Column(name = "update_date")),
            @AttributeOverride(name = "time", column = @Column(name = "update_time")),
            @AttributeOverride(name = "year", column = @Column(name = "update_year")),
            @AttributeOverride(name = "month", column = @Column(name = "update_month")),
            @AttributeOverride(name = "day", column = @Column(name = "update_day")),
            @AttributeOverride(name = "hour", column = @Column(name = "update_hour")),
            @AttributeOverride(name = "minute", column = @Column(name = "update_minute")),
            @AttributeOverride(name = "second", column = @Column(name = "update_second")),
            @AttributeOverride(name = "week", column = @Column(name = "update_week")),
    })
    private DateTime updateTime;

    public Long getAssetId() { return assetId; }
    public void setAssetId(Long assetId) { this.assetId = assetId; }
    public Employee getEmp() { return emp; }
    public void setEmp(Employee emp) { this.emp = emp; }
    public AssetType getType() { return type; }
    public void setType(AssetType type) { this.type = type; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getUrl() { return url; }
    public void setUrl(String url) { this.url = url; }
    public String getThumbUrl() { return thumbUrl; }
    public void setThumbUrl(String thumbUrl) { this.thumbUrl = thumbUrl; }
    public String getFileFormat() { return fileFormat; }
    public void setFileFormat(String fileFormat) { this.fileFormat = fileFormat; }
    public Long getSize() { return size; }
    public void setSize(Long size) { this.size = size; }
    public String getCommunity() { return community; }
    public void setCommunity(String community) { this.community = community; }
    public String getHouseType() { return houseType; }
    public void setHouseType(String houseType) { this.houseType = houseType; }
    public String getStyle() { return style; }
    public void setStyle(String style) { this.style = style; }
    public AssetStage getStage() { return stage; }
    public void setStage(AssetStage stage) { this.stage = stage; }
    public Long getArea() { return area; }
    public void setArea(Long area) { this.area = area; }
    public AssetSource getSource() { return source; }
    public void setSource(AssetSource source) { this.source = source; }
    public CopyrightStatus getCopyrightStatus() { return copyrightStatus; }
    public void setCopyrightStatus(CopyrightStatus copyrightStatus) { this.copyrightStatus = copyrightStatus; }
    public AiStatus getAiStatus() { return aiStatus; }
    public void setAiStatus(AiStatus aiStatus) { this.aiStatus = aiStatus; }
    public AssetStatus getStatus() { return status; }
    public void setStatus(AssetStatus status) { this.status = status; }
    public String getRemark() { return remark; }
    public void setRemark(String remark) { this.remark = remark; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public Long getUsageCount() { return usageCount; }
    public void setUsageCount(Long usageCount) { this.usageCount = usageCount; }
    public DateTime getCreateTime() { return createTime; }
    public void setCreateTime(DateTime createTime) { this.createTime = createTime; }
    public DateTime getUpdateTime() { return updateTime; }
    public void setUpdateTime(DateTime updateTime) { this.updateTime = updateTime; }
}

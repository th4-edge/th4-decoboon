package com.th4.edge.decoboon.clue.asset.repository;

import com.th4.edge.decoboon.clue.asset.configure.AssetStatus;
import com.th4.edge.decoboon.clue.asset.configure.AssetType;
import com.th4.edge.decoboon.clue.asset.model.Asset;
import com.th4.edge.framework.data.jpa.repository.JpaRepository;

import java.util.Collection;
import java.util.List;

public interface AssetRepository extends JpaRepository<Asset, Long> {

    Asset findByAssetId(Long assetId);

    List<Asset> findByEmp_EmpIdOrderByCreateTimeDesc(Long empId);

    List<Asset> findByEmp_EmpIdAndAssetIdIn(Long empId, Collection<Long> assetIds);

    List<Asset> findByEmp_EmpIdAndStatusOrderByCreateTimeDesc(Long empId, AssetStatus status);

    List<Asset> findByEmp_EmpIdAndTypeOrderByCreateTimeDesc(Long empId, AssetType type);

    List<Asset> findByStatusOrderByCreateTimeDesc(AssetStatus status);

    List<Asset> findByTypeOrderByCreateTimeDesc(AssetType type);
}

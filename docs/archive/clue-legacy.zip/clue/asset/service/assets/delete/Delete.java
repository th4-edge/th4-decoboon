package com.th4.edge.decoboon.clue.asset.service.assets.delete;

import com.th4.edge.decoboon.clue.asset.model.Asset;
import com.th4.edge.framework.service.ModelService;

/**
 * 素材删除服务（软删除）：入参 = 素材实体，响应 = 删除后的素材。
 */
public interface Delete extends ModelService<Asset, Asset> {
}

package com.th4.edge.decoboon.clue.asset.service.assets.delete.support;

import com.th4.edge.decoboon.clue.asset.configure.AssetStatus;
import com.th4.edge.decoboon.clue.asset.model.Asset;
import com.th4.edge.decoboon.clue.asset.repository.AssetRepository;
import com.th4.edge.decoboon.clue.asset.service.assets.delete.Delete;
import com.th4.edge.framework.core.annotation.Description;
import com.th4.edge.framework.core.annotation.Note;
import com.th4.edge.framework.exception.DefaultErrorCode;
import com.th4.edge.framework.exception.DefinedException;
import com.th4.edge.framework.provider.inject.annotation.AutoInject;
import com.th4.edge.framework.provider.validation.annotation.NotNull;
import com.th4.edge.framework.service.annotation.ServiceName;
import org.springframework.stereotype.Service;

@Note("素材删除")
@Description("素材软删除：标记为已删除，保留历史引用")
@Service("decoboon/clue/asset/delete")
@ServiceName("delete")
public class DeleteImpl implements Delete {

    @AutoInject
    @NotNull
    private Long assetId;

    private final AssetRepository assetRepository;

    public DeleteImpl(AssetRepository assetRepository) {
        this.assetRepository = assetRepository;
    }

    @Override
    public Asset call(Asset request) {
        Asset exist = assetRepository.findByAssetId(assetId);
        if (exist == null) {
            throw new DefinedException(new DefaultErrorCode("400", "素材不存在"));
        }
        exist.setStatus(AssetStatus.Deleted);
        return assetRepository.save(exist);
    }
}

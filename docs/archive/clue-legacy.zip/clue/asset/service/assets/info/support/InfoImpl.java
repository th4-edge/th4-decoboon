package com.th4.edge.decoboon.clue.asset.service.assets.info.support;

import com.th4.edge.decoboon.clue.asset.model.Asset;
import com.th4.edge.decoboon.clue.asset.repository.AssetRepository;
import com.th4.edge.decoboon.clue.asset.service.assets.info.Info;
import com.th4.edge.decoboon.clue.company.model.Employee;
import com.th4.edge.framework.core.annotation.Description;
import com.th4.edge.framework.core.annotation.Note;
import com.th4.edge.framework.data.jackson.annotation.IgnoreProperties;
import com.th4.edge.framework.data.jackson.annotation.Properties;
import com.th4.edge.framework.data.jackson.annotation.ServiceProperties;
import com.th4.edge.framework.exception.DefaultErrorCode;
import com.th4.edge.framework.exception.DefinedException;
import com.th4.edge.framework.provider.inject.annotation.AutoInject;
import com.th4.edge.framework.provider.validation.annotation.NotNull;
import com.th4.edge.framework.service.annotation.ServiceName;
import org.springframework.stereotype.Service;

@Note("素材详情")
@Description("按素材索引查询素材详情")
@ServiceProperties(
        uris = "decoboon/clue/asset/info",
        properties = @Properties(ignore = {
                @IgnoreProperties(model = Employee.class, properties = {"phone", "wechat", "password", "displayCompanyName", "active", "company"})
        })
)
@Service("decoboon/clue/asset/info")
@ServiceName("info")
public class InfoImpl implements Info {

    @AutoInject
    @NotNull
    private Long assetId;

    private final AssetRepository assetRepository;

    public InfoImpl(AssetRepository assetRepository) {
        this.assetRepository = assetRepository;
    }

    @Override
    public Asset call(Asset request) {
        Asset exist = assetRepository.findByAssetId(assetId);
        if (exist == null) {
            throw new DefinedException(new DefaultErrorCode("400", "素材不存在"));
        }
        return exist;
    }
}

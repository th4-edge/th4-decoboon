package com.th4.edge.decoboon.clue.asset.service.assets.list;

import com.th4.edge.decoboon.clue.asset.model.Asset;
import com.th4.edge.framework.service.ModelService;

/**
 * 素材列表服务：我的素材 / 全部素材，支持按类型、状态筛选。
 */
public interface List extends ModelService<Asset, java.util.List<Asset>> {
}

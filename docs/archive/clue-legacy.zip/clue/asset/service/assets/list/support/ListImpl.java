package com.th4.edge.decoboon.clue.asset.service.assets.list.support;

import com.th4.edge.decoboon.clue.asset.configure.AssetStatus;
import com.th4.edge.decoboon.clue.asset.configure.AssetType;
import com.th4.edge.decoboon.clue.asset.model.Asset;
import com.th4.edge.decoboon.clue.asset.repository.AssetRepository;
import com.th4.edge.decoboon.clue.asset.service.assets.list.List;
import com.th4.edge.decoboon.clue.company.model.Employee;
import com.th4.edge.framework.core.annotation.Description;
import com.th4.edge.framework.core.annotation.Note;
import com.th4.edge.framework.data.jackson.annotation.IgnoreProperties;
import com.th4.edge.framework.data.jackson.annotation.Properties;
import com.th4.edge.framework.data.jackson.annotation.ServiceProperties;
import com.th4.edge.framework.provider.inject.annotation.AutoInject;
import com.th4.edge.framework.service.annotation.ServiceName;
import org.springframework.stereotype.Service;

@Note("素材列表")
@Description("我的素材 / 全部素材列表，支持按类型、状态筛选")
@ServiceProperties(
        uris = "decoboon/clue/asset/list",
        properties = @Properties(ignore = {
                @IgnoreProperties(model = Employee.class, properties = {"phone", "wechat", "password", "displayCompanyName", "active", "company"})
        })
)
@Service("decoboon/clue/asset/list")
@ServiceName("list")
public class ListImpl implements List {

    @AutoInject
    private Long empId;

    @AutoInject
    private AssetType type;

    @AutoInject
    private AssetStatus status;

    private final AssetRepository assetRepository;

    public ListImpl(AssetRepository assetRepository) {
        this.assetRepository = assetRepository;
    }

    @Override
    public java.util.List<Asset> call(Asset request) {
        if (empId != null) {
            if (status != null) {
                return assetRepository.findByEmp_EmpIdAndStatusOrderByCreateTimeDesc(empId, status);
            }
            if (type != null) {
                return assetRepository.findByEmp_EmpIdAndTypeOrderByCreateTimeDesc(empId, type);
            }
            return assetRepository.findByEmp_EmpIdOrderByCreateTimeDesc(empId);
        }
        if (status != null) {
            return assetRepository.findByStatusOrderByCreateTimeDesc(status);
        }
        if (type != null) {
            return assetRepository.findByTypeOrderByCreateTimeDesc(type);
        }
        return assetRepository.findAll();
    }
}

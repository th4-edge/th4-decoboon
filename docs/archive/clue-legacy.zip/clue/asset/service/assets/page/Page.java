package com.th4.edge.decoboon.clue.asset.service.assets.page;

import com.th4.edge.decoboon.clue.asset.model.Asset;
import com.th4.edge.framework.service.ModelService;

/**
 * 素材分页服务：入参 = 素材实体，响应 = 素材分页。
 */
public interface Page extends ModelService<Asset, org.springframework.data.domain.Page<Asset>> {
}

package com.th4.edge.decoboon.clue.asset.service.assets.page.support;

import com.th4.edge.decoboon.clue.asset.model.Asset;
import com.th4.edge.decoboon.clue.asset.service.assets.page.Page;
import com.th4.edge.decoboon.clue.company.model.Employee;
import com.th4.edge.framework.core.annotation.Description;
import com.th4.edge.framework.core.annotation.Note;
import com.th4.edge.framework.data.jackson.annotation.IgnoreProperties;
import com.th4.edge.framework.data.jackson.annotation.Properties;
import com.th4.edge.framework.data.jackson.annotation.ServiceProperties;
import com.th4.edge.framework.service.annotation.ServiceName;
import com.th4.edge.framework.service.page.context.AbstractPage;
import jakarta.persistence.EntityManager;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

@Note("素材分页")
@Description("按通用查询语法分页查询素材")
@ServiceProperties(
        uris = "decoboon/clue/asset/page",
        properties = @Properties(ignore = {
                @IgnoreProperties(model = Employee.class, properties = {"phone", "wechat", "password", "displayCompanyName", "active", "company"})
        })
)
@Service("decoboon/clue/asset/page")
@ServiceName("page")
@Scope("prototype")
public class PageImpl extends AbstractPage<Asset> implements Page {

    public PageImpl(EntityManager entityManager) {
        super(entityManager);
    }
}

package com.th4.edge.decoboon.clue.asset.service.assets.save;

import com.th4.edge.decoboon.clue.asset.model.Asset;
import com.th4.edge.framework.provider.Provider;

/**
 * 素材保存服务：业务员上传工地照片/视频/语音素材后登记入库。
 * 入参 = 素材实体（为 Asset 服务），响应 = 保存后的素材。
 */
public interface Save extends Provider<Asset, Asset> {
}

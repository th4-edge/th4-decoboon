package com.th4.edge.decoboon.clue.asset.service.assets.save.support;

import com.th4.edge.decoboon.clue.asset.configure.AiStatus;
import com.th4.edge.decoboon.clue.asset.configure.AssetSource;
import com.th4.edge.decoboon.clue.asset.configure.AssetStage;
import com.th4.edge.decoboon.clue.asset.configure.AssetStatus;
import com.th4.edge.decoboon.clue.asset.configure.AssetType;
import com.th4.edge.decoboon.clue.asset.configure.CopyrightStatus;
import com.th4.edge.decoboon.clue.asset.model.Asset;
import com.th4.edge.decoboon.clue.asset.repository.AssetRepository;
import com.th4.edge.decoboon.clue.company.model.Employee;
import com.th4.edge.decoboon.clue.company.repository.EmployeeRepository;
import com.th4.edge.framework.core.annotation.Description;
import com.th4.edge.framework.core.annotation.Note;
import com.th4.edge.framework.data.jackson.annotation.IgnoreProperties;
import com.th4.edge.framework.data.jackson.annotation.Properties;
import com.th4.edge.framework.data.jackson.annotation.ServiceProperties;
import com.th4.edge.framework.provider.inject.annotation.AutoInject;
import com.th4.edge.framework.provider.validation.annotation.Length;
import com.th4.edge.framework.provider.validation.annotation.NotEmpty;
import com.th4.edge.framework.provider.validation.annotation.NotNull;
import com.th4.edge.framework.service.annotation.ServiceName;
import org.springframework.stereotype.Service;

@Note("素材保存")
@Description("业务员上传工地照片/视频/户型图/锦旗/留痕材料，登记业务标签与 AI 解读")
@ServiceProperties(
        uris = "decoboon/clue/asset/save",
        properties = @Properties(ignore = {
                @IgnoreProperties(model = Employee.class, properties = {"phone", "wechat", "password", "displayCompanyName", "active", "company"})
        })
)
@Service("decoboon/clue/asset/save")
@ServiceName("save")
public class Save implements com.th4.edge.decoboon.clue.asset.service.assets.save.Save {

    @AutoInject
    @NotNull
    private Long empId;

    @AutoInject
    @NotNull
    private AssetType type;

    @AutoInject
    @NotEmpty
    @Length(max = 512)
    private String url;

    @AutoInject
    @Length(max = 128)
    private String title;

    @AutoInject
    @Length(max = 512)
    private String thumbUrl;

    @AutoInject
    @Length(max = 16)
    private String fileFormat;

    @AutoInject
    private Long size;

    @AutoInject
    @Length(max = 64)
    private String community;

    @AutoInject
    @Length(max = 32)
    private String houseType;

    @AutoInject
    @Length(max = 32)
    private String style;

    @AutoInject
    private AssetStage stage;

    @AutoInject
    private Long area;

    @AutoInject
    private AssetSource source;

    @AutoInject
    private CopyrightStatus copyrightStatus;

    @AutoInject
    private AiStatus aiStatus;

    @AutoInject
    private AssetStatus status;

    @AutoInject
    @Length(max = 256)
    private String remark;

    @AutoInject
    @Length(max = 1024)
    private String description;

    private final AssetRepository assetRepository;
    private final EmployeeRepository employeeRepository;

    public Save(AssetRepository assetRepository, EmployeeRepository employeeRepository) {
        this.assetRepository = assetRepository;
        this.employeeRepository = employeeRepository;
    }

    @Override
    public Asset call(Asset request) {
        Employee emp = employeeRepository.findByEmpId(empId);

        Asset asset = new Asset();
        asset.setEmp(emp);
        asset.setType(type);
        asset.setUrl(url);
        asset.setTitle(title);
        asset.setThumbUrl(thumbUrl);
        asset.setFileFormat(fileFormat);
        asset.setSize(size);
        asset.setCommunity(community);
        asset.setHouseType(houseType);
        asset.setStyle(style);
        asset.setStage(stage);
        asset.setArea(area);
        asset.setSource(source);
        asset.setCopyrightStatus(copyrightStatus);
        asset.setAiStatus(aiStatus == null ? AiStatus.Pending : aiStatus);
        asset.setStatus(status == null ? AssetStatus.Stored : status);
        asset.setRemark(remark);
        asset.setDescription(description);
        asset.setUsageCount(0L);

        return assetRepository.save(asset);
    }
}

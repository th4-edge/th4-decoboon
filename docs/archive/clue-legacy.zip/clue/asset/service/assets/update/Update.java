package com.th4.edge.decoboon.clue.asset.service.assets.update;

import com.th4.edge.decoboon.clue.asset.model.Asset;
import com.th4.edge.framework.service.ModelService;

/**
 * 素材更新服务：入参 = 素材实体，响应 = 更新后的素材。
 */
public interface Update extends ModelService<Asset, Asset> {
}

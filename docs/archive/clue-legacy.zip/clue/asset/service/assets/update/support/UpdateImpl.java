package com.th4.edge.decoboon.clue.asset.service.assets.update.support;

import com.th4.edge.decoboon.clue.asset.configure.AiStatus;
import com.th4.edge.decoboon.clue.asset.configure.AssetSource;
import com.th4.edge.decoboon.clue.asset.configure.AssetStage;
import com.th4.edge.decoboon.clue.asset.configure.AssetStatus;
import com.th4.edge.decoboon.clue.asset.configure.AssetType;
import com.th4.edge.decoboon.clue.asset.configure.CopyrightStatus;
import com.th4.edge.decoboon.clue.asset.model.Asset;
import com.th4.edge.decoboon.clue.asset.repository.AssetRepository;
import com.th4.edge.decoboon.clue.asset.service.assets.update.Update;
import com.th4.edge.decoboon.clue.company.model.Employee;
import com.th4.edge.framework.core.annotation.Description;
import com.th4.edge.framework.core.annotation.Note;
import com.th4.edge.framework.data.jackson.annotation.IgnoreProperties;
import com.th4.edge.framework.data.jackson.annotation.Properties;
import com.th4.edge.framework.data.jackson.annotation.ServiceProperties;
import com.th4.edge.framework.exception.DefaultErrorCode;
import com.th4.edge.framework.exception.DefinedException;
import com.th4.edge.framework.provider.inject.annotation.AutoInject;
import com.th4.edge.framework.provider.validation.annotation.Length;
import com.th4.edge.framework.provider.validation.annotation.NotNull;
import com.th4.edge.framework.service.annotation.ServiceName;
import org.springframework.stereotype.Service;

@Note("素材更新")
@Description("编辑素材的标题、业务标签、版权、AI 解读等字段")
@ServiceProperties(
        uris = "decoboon/clue/asset/update",
        properties = @Properties(ignore = {
                @IgnoreProperties(model = Employee.class, properties = {"phone", "wechat", "password", "displayCompanyName", "active", "company"})
        })
)
@Service("decoboon/clue/asset/update")
@ServiceName("update")
public class UpdateImpl implements Update {

    @AutoInject
    @NotNull
    private Long assetId;

    @AutoInject
    private AssetType type;

    @AutoInject
    @Length(max = 128)
    private String title;

    @AutoInject
    @Length(max = 512)
    private String thumbUrl;

    @AutoInject
    @Length(max = 64)
    private String community;

    @AutoInject
    @Length(max = 32)
    private String houseType;

    @AutoInject
    @Length(max = 32)
    private String style;

    @AutoInject
    private AssetStage stage;

    @AutoInject
    private Long area;

    @AutoInject
    private AssetSource source;

    @AutoInject
    private CopyrightStatus copyrightStatus;

    @AutoInject
    private AiStatus aiStatus;

    @AutoInject
    private AssetStatus status;

    @AutoInject
    @Length(max = 256)
    private String remark;

    @AutoInject
    @Length(max = 1024)
    private String description;

    private final AssetRepository assetRepository;

    public UpdateImpl(AssetRepository assetRepository) {
        this.assetRepository = assetRepository;
    }

    @Override
    public Asset call(Asset request) {
        Asset exist = assetRepository.findByAssetId(assetId);
        if (exist == null) {
            throw new DefinedException(new DefaultErrorCode("400", "素材不存在"));
        }
        if (type != null) exist.setType(type);
        if (title != null) exist.setTitle(title);
        if (thumbUrl != null) exist.setThumbUrl(thumbUrl);
        if (community != null) exist.setCommunity(community);
        if (houseType != null) exist.setHouseType(houseType);
        if (style != null) exist.setStyle(style);
        if (stage != null) exist.setStage(stage);
        if (area != null) exist.setArea(area);
        if (source != null) exist.setSource(source);
        if (copyrightStatus != null) exist.setCopyrightStatus(copyrightStatus);
        if (aiStatus != null) exist.setAiStatus(aiStatus);
        if (status != null) exist.setStatus(status);
        if (remark != null) exist.setRemark(remark);
        if (description != null) exist.setDescription(description);
        return assetRepository.save(exist);
    }
}

package com.th4.edge.decoboon.clue.company.model;
import jakarta.persistence.AttributeOverride;
import jakarta.persistence.AttributeOverrides;
import jakarta.persistence.Embedded;

import com.th4.edge.framework.core.annotation.Note;
import com.th4.edge.framework.data.date.model.DateTime;
import com.th4.edge.framework.data.jpa.annotation.Model;
import com.th4.edge.framework.data.jpa.keyword.annotation.Keyword;
import com.th4.edge.framework.data.model.AbstractModel;
import com.th4.edge.framework.data.model.prepare.annotation.CreateTime;
import com.th4.edge.framework.data.model.prepare.annotation.UpdateTime;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Note("业务员")
@Model
@Entity
@Table(name = "db_clue_employee")
public class Employee extends AbstractModel {

    @Note("业务员索引")
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long empId;

    @Note("所属公司")
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "company_id", nullable = false)
    private Company company;

    @Note("姓名")
    @Keyword
    @Column(nullable = false, length = 32)
    private String name;

    @Note("电话")
    @Keyword
    @Column(length = 20)
    private String phone;

    @Note("微信")
    @Keyword
    @Column(length = 64)
    private String wechat;

    @Note("默认公司名展示（前端下拉默认项）")
    @Keyword
    @Column(length = 64)
    private String displayCompanyName;

    @Note("在职状态")
    @Column(nullable = false)
    private Boolean active = Boolean.TRUE;

    @Note("创建时间")
    @CreateTime
    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name="dateTime", column=@Column(name="create_dateTime")),
            @AttributeOverride(name="date", column=@Column(name="create_date")),
            @AttributeOverride(name="time", column=@Column(name="create_time")),
            @AttributeOverride(name="year", column=@Column(name="create_year")),
            @AttributeOverride(name="month", column=@Column(name="create_month")),
            @AttributeOverride(name="day", column=@Column(name="create_day")),
            @AttributeOverride(name="hour", column=@Column(name="create_hour")),
            @AttributeOverride(name="minute", column=@Column(name="create_minute")),
            @AttributeOverride(name="second", column=@Column(name="create_second")),
            @AttributeOverride(name="week", column=@Column(name="create_week")),
        })
    private DateTime createTime;

    @Note("更新时间")
    @UpdateTime
    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name="dateTime", column=@Column(name="update_dateTime")),
            @AttributeOverride(name="date", column=@Column(name="update_date")),
            @AttributeOverride(name="time", column=@Column(name="update_time")),
            @AttributeOverride(name="year", column=@Column(name="update_year")),
            @AttributeOverride(name="month", column=@Column(name="update_month")),
            @AttributeOverride(name="day", column=@Column(name="update_day")),
            @AttributeOverride(name="hour", column=@Column(name="update_hour")),
            @AttributeOverride(name="minute", column=@Column(name="update_minute")),
            @AttributeOverride(name="second", column=@Column(name="update_second")),
            @AttributeOverride(name="week", column=@Column(name="update_week")),
        })
    private DateTime updateTime;

    public Long getEmpId() {
        return empId;
    }

    public void setEmpId(Long empId) {
        this.empId = empId;
    }

    public Company getCompany() {
        return company;
    }

    public void setCompany(Company company) {
        this.company = company;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getWechat() {
        return wechat;
    }

    public void setWechat(String wechat) {
        this.wechat = wechat;
    }

    public String getDisplayCompanyName() {
        return displayCompanyName;
    }

    public void setDisplayCompanyName(String displayCompanyName) {
        this.displayCompanyName = displayCompanyName;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    public DateTime getCreateTime() {
        return createTime;
    }

    public void setCreateTime(DateTime createTime) {
        this.createTime = createTime;
    }

    public DateTime getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(DateTime updateTime) {
        this.updateTime = updateTime;
    }
}

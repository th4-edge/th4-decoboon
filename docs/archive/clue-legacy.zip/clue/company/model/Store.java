package com.th4.edge.decoboon.clue.company.model;
import jakarta.persistence.AttributeOverride;
import jakarta.persistence.AttributeOverrides;
import jakarta.persistence.Embedded;

import com.th4.edge.framework.core.annotation.Note;
import com.th4.edge.framework.data.date.model.DateTime;
import com.th4.edge.framework.data.jpa.annotation.Model;
import com.th4.edge.framework.data.jpa.keyword.annotation.Keyword;
import com.th4.edge.framework.data.model.AbstractModel;
import com.th4.edge.framework.data.model.prepare.annotation.CreateTime;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Note("门店")
@Model
@Entity
@Table(name = "db_clue_store")
public class Store extends AbstractModel {

    @Note("门店索引")
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long storeId;

    @Note("所属公司")
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "company_id", nullable = false)
    private Company company;

    @Note("门店名称")
    @Keyword
    @Column(nullable = false, length = 64)
    private String name;

    @Note("门店地址")
    @Keyword
    @Column(length = 256)
    private String address;

    @Note("创建时间")
    @CreateTime
    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name="dateTime", column=@Column(name="create_dateTime")),
            @AttributeOverride(name="date", column=@Column(name="create_date")),
            @AttributeOverride(name="time", column=@Column(name="create_time")),
            @AttributeOverride(name="year", column=@Column(name="create_year")),
            @AttributeOverride(name="month", column=@Column(name="create_month")),
            @AttributeOverride(name="day", column=@Column(name="create_day")),
            @AttributeOverride(name="hour", column=@Column(name="create_hour")),
            @AttributeOverride(name="minute", column=@Column(name="create_minute")),
            @AttributeOverride(name="second", column=@Column(name="create_second")),
            @AttributeOverride(name="week", column=@Column(name="create_week")),
        })
    private DateTime createTime;

    public Long getStoreId() {
        return storeId;
    }

    public void setStoreId(Long storeId) {
        this.storeId = storeId;
    }

    public Company getCompany() {
        return company;
    }

    public void setCompany(Company company) {
        this.company = company;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public DateTime getCreateTime() {
        return createTime;
    }

    public void setCreateTime(DateTime createTime) {
        this.createTime = createTime;
    }
}

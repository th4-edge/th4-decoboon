package com.th4.edge.decoboon.clue.company.repository;

import com.th4.edge.decoboon.clue.company.model.Company;
import com.th4.edge.framework.data.jpa.repository.JpaRepository;

public interface CompanyRepository extends JpaRepository<Company, Long> {

    Company findByCompanyId(Long companyId);

    Company findFirstByEnabledTrue();
}

package com.th4.edge.decoboon.clue.company.repository;

import com.th4.edge.decoboon.clue.company.model.Employee;
import com.th4.edge.framework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    List<Employee> findByCompany_CompanyId(Long companyId);

    List<Employee> findByCompany_CompanyIdAndActiveTrue(Long companyId);

    Employee findByPhone(String phone);

    Employee findByEmpId(Long empId);
}

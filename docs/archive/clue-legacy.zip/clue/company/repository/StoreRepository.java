package com.th4.edge.decoboon.clue.company.repository;

import com.th4.edge.decoboon.clue.company.model.Store;
import com.th4.edge.framework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface StoreRepository extends JpaRepository<Store, Long> {

    List<Store> findByCompany_CompanyId(Long companyId);
}

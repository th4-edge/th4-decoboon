package com.th4.edge.decoboon.clue.configure;

import com.th4.edge.admin.system.annotation.Role;
import com.th4.edge.admin.system.annotation.Route;
import com.th4.edge.admin.system.annotation.View;
import org.springframework.stereotype.Component;

/**
 * 老板（boss）角色与页面注册。
 * <p>
 * 角色 home = /boss；页面分「经营看板」「获客管理」「团队管理」三组；
 * 页面组件路径与前端 th4-decoboon-web 的 src/views/decoboon/boss/** 一一对应。
 */
@Role(idKey = "boss", name = "老板", title = "家装宝 · 装修获客", component = "views/admin/Home.vue", user = true)
@View(name = "获客看板", parent = "经营看板@TrendCharts", path = "clue/statistic/dashboard", icon = "DataAnalysis", priority = 1,
        route = @Route(component = "views/decoboon/boss/clue/statistic/dashboard/DashboardView.vue"),
        roles = {@Role(idKey = "boss")})
@View(name = "业务员排行", parent = "经营看板@TrendCharts", path = "clue/statistic/rank", icon = "Trophy", priority = 2,
        route = @Route(component = "views/decoboon/boss/clue/statistic/rank/RankView.vue"),
        roles = {@Role(idKey = "boss")})
@View(name = "线索管理", parent = "获客管理@Promotion", path = "clue/lead/lead", icon = "Message", priority = 1,
        route = @Route(component = "views/decoboon/boss/clue/lead/lead/manage/LeadManageView.vue"),
        roles = {@Role(idKey = "boss")})
@View(name = "线索跟进", parent = "获客管理@Promotion", path = "clue/lead/follow", icon = "ChatLineRound", priority = 2,
        route = @Route(component = "views/decoboon/boss/clue/lead/follow/manage/LeadFollowManageView.vue"),
        roles = {@Role(idKey = "boss")})
@View(name = "素材管理", parent = "获客管理@Promotion", path = "clue/asset/asset", icon = "Picture", priority = 3,
        route = @Route(component = "views/decoboon/boss/clue/asset/asset/manage/AssetManageView.vue"),
        roles = {@Role(idKey = "boss")})
@View(name = "视频管理", parent = "获客管理@Promotion", path = "clue/video/video", icon = "VideoCamera", priority = 4,
        route = @Route(component = "views/decoboon/boss/clue/video/video/manage/VideoManageView.vue"),
        roles = {@Role(idKey = "boss")})
@View(name = "视频数据", parent = "获客管理@Promotion", path = "clue/video/stat", icon = "DataLine", priority = 5,
        route = @Route(component = "views/decoboon/boss/clue/video/stat/manage/VideoStatManageView.vue"),
        roles = {@Role(idKey = "boss")})
@View(name = "视频文案", parent = "获客管理@Promotion", path = "clue/video/copy", icon = "Document", priority = 6,
        route = @Route(component = "views/decoboon/boss/clue/video/copy/manage/VideoCopyManageView.vue"),
        roles = {@Role(idKey = "boss")})
@View(name = "模板管理", parent = "获客管理@Promotion", path = "clue/video/template", icon = "Files", priority = 7,
        route = @Route(component = "views/decoboon/boss/clue/video/template/manage/TemplateManageView.vue"),
        roles = {@Role(idKey = "boss")})
@View(name = "话术库管理", parent = "获客管理@Promotion", path = "clue/video/script", icon = "Notebook", priority = 8,
        route = @Route(component = "views/decoboon/boss/clue/video/script/manage/VideoScriptManageView.vue"),
        roles = {@Role(idKey = "boss")})
@View(name = "员工管理", parent = "团队管理@UserFilled", path = "clue/company/employee", icon = "User", priority = 1,
        route = @Route(component = "views/decoboon/boss/clue/company/employee/manage/EmployeeManageView.vue"),
        roles = {@Role(idKey = "boss")})
@View(name = "公司管理", parent = "团队管理@UserFilled", path = "clue/company/company", icon = "OfficeBuilding", priority = 2,
        route = @Route(component = "views/decoboon/boss/clue/company/company/manage/CompanyManageView.vue"),
        roles = {@Role(idKey = "boss")})
@View(name = "门店管理", parent = "团队管理@UserFilled", path = "clue/company/store", icon = "Shop", priority = 3,
        route = @Route(component = "views/decoboon/boss/clue/company/store/manage/StoreManageView.vue"),
        roles = {@Role(idKey = "boss")})
@View(name = "风格画像", parent = "团队管理@UserFilled", path = "clue/video/styleProfile", icon = "Brush", priority = 4,
        route = @Route(component = "views/decoboon/boss/clue/video/styleProfile/manage/StyleProfileManageView.vue"),
        roles = {@Role(idKey = "boss")})
//@Component
public class BossViewConfigure {
}

package com.th4.edge.decoboon.clue.configure;

import com.th4.edge.admin.system.annotation.Role;
import com.th4.edge.admin.system.annotation.Route;
import com.th4.edge.admin.system.annotation.View;
import org.springframework.stereotype.Component;

/**
 * 业务员（marketer）角色与页面注册。
 * <p>
 * 角色 home = /marketer；
 * 菜单按工作流分组：工作台/数据看板（一级）、内容生产、客户跟进、内容支撑；
 * 页面组件路径与前端 th4-decoboon-web 的 src/views/decoboon/marketer/** 一一对应。
 */
@Role(idKey = "marketer", name = "业务员", title = "家装宝 · 装修获客", component = "views/admin/Home.vue", user = true)
@View(name = "工作台", path = "home", icon = "HomeFilled", priority = 1,
        route = @Route(component = "views/decoboon/marketer/home/WorkbenchView.vue"),
        roles = {@Role(idKey = "marketer")})
@View(name = "数据看板", path = "statistic/dashboard", icon = "TrendCharts", priority = 2,
        route = @Route(component = "views/decoboon/marketer/statistic/dashboard/DashboardView.vue"),
        roles = {@Role(idKey = "marketer")})
@View(name = "发布短视频", parent = "内容生产@VideoCamera", path = "clue/video/video/publish", icon = "Promotion", priority = 1,
        route = @Route(component = "views/decoboon/marketer/clue/video/video/publish/PublishView.vue"),
        roles = {@Role(idKey = "marketer")})
@View(name = "短视频", parent = "内容生产@VideoCamera", path = "video/dashboard", icon = "VideoCamera", priority = 2,
        route = @Route(component = "views/decoboon/marketer/clue/video/video/dashboard/VideoDashboardView.vue"),
        roles = {@Role(idKey = "marketer")})
@View(name = "线索登记", parent = "客户跟进@Message", path = "clue/lead/register", icon = "EditPen", priority = 1,
        route = @Route(component = "views/decoboon/marketer/clue/lead/register/LeadRegisterView.vue"),
        roles = {@Role(idKey = "marketer")})
@View(name = "我的线索", parent = "客户跟进@Message", path = "clue/lead/lead", icon = "Message", priority = 2,
        route = @Route(component = "views/decoboon/marketer/clue/lead/lead/manage/LeadManageView.vue"),
        roles = {@Role(idKey = "marketer")})
@View(name = "素材管理", parent = "内容支撑@Files", path = "clue/asset/asset", icon = "Picture", priority = 1,
        route = @Route(component = "views/decoboon/marketer/clue/asset/asset/manage/AssetManageView.vue"),
        roles = {@Role(idKey = "marketer")})
@View(name = "模板库", parent = "内容支撑@Files", path = "clue/video/template", icon = "Files", priority = 2,
        route = @Route(component = "views/decoboon/marketer/clue/video/template/TemplateListView.vue"),
        roles = {@Role(idKey = "marketer")})
@View(name = "话术库", parent = "内容支撑@Files", path = "clue/video/script", icon = "Notebook", priority = 3,
        route = @Route(component = "views/decoboon/marketer/clue/video/script/ScriptListView.vue"),
        roles = {@Role(idKey = "marketer")})
@View(name = "视频生成", parent = "内容支撑@Files", path = "clue/video/generate", icon = "MagicStick", priority = 4,
        route = @Route(component = "views/decoboon/marketer/clue/video/generate/GenerateView.vue"),
        roles = {@Role(idKey = "marketer")})
@View(name = "视频任务", parent = "内容支撑@Files", path = "clue/video/task", icon = "Timer", priority = 5,
        route = @Route(component = "views/decoboon/marketer/clue/video/task/manage/VideoTaskManageView.vue"),
        roles = {@Role(idKey = "marketer")})
@View(name = "我的视频", parent = "内容支撑@Files", path = "clue/video/video", icon = "VideoCamera", priority = 6,
        route = @Route(component = "views/decoboon/marketer/clue/video/video/manage/VideoManageView.vue"),
        roles = {@Role(idKey = "marketer")})
@Component
public class MarketerViewConfigure {
}

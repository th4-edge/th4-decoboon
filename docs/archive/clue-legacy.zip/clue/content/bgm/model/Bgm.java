package com.th4.edge.decoboon.clue.content.bgm.model;

import com.th4.edge.decoboon.clue.asset.configure.CopyrightStatus;
import com.th4.edge.decoboon.clue.video.configure.PublishChannel;
import com.th4.edge.framework.core.annotation.Description;
import com.th4.edge.framework.core.annotation.Note;
import com.th4.edge.framework.data.date.model.DateTime;
import com.th4.edge.framework.data.jpa.annotation.Model;
import com.th4.edge.framework.data.jpa.keyword.annotation.Keyword;
import com.th4.edge.framework.data.model.AbstractModel;
import com.th4.edge.framework.data.model.prepare.annotation.CreateTime;
import com.th4.edge.framework.data.model.prepare.annotation.UpdateTime;
import jakarta.persistence.*;

@Note("BGM库")
@Description("短视频背景音乐资源，含风格与版权状态")
@Model
@Entity
@Table(name = "db_clue_content_bgm")
public class Bgm extends AbstractModel {

    @Note("BGM索引")
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long bgmId;

    @Note("BGM名称")
    @Keyword
    @Column(nullable = false, length = 128)
    private String name;

    @Note("风格")
    @Keyword
    @Column(length = 64)
    private String style;

    @Note("适用渠道")
    @Column(nullable = false, length = 32)
    private PublishChannel channel;

    @Note("版权状态")
    @Column(length = 32)
    private CopyrightStatus copyrightStatus;

    @Note("时长(秒)")
    @Column
    private Long duration;

    @Note("资源地址")
    @Column(length = 512)
    private String url;

    @Note("使用次数")
    @Column
    private Long usageCount = 0L;

    @Note("启用状态")
    @Column
    private Boolean enabled = Boolean.TRUE;

    @Note("创建时间")
    @CreateTime
    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "dateTime", column = @Column(name = "create_dateTime")),
            @AttributeOverride(name = "date", column = @Column(name = "create_date")),
            @AttributeOverride(name = "time", column = @Column(name = "create_time")),
    })
    private DateTime createTime;

    @Note("更新时间")
    @UpdateTime
    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "dateTime", column = @Column(name = "update_dateTime")),
            @AttributeOverride(name = "date", column = @Column(name = "update_date")),
            @AttributeOverride(name = "time", column = @Column(name = "update_time")),
    })
    private DateTime updateTime;

    public Long getBgmId() { return bgmId; }
    public void setBgmId(Long bgmId) { this.bgmId = bgmId; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getStyle() { return style; }
    public void setStyle(String style) { this.style = style; }
    public PublishChannel getChannel() { return channel; }
    public void setChannel(PublishChannel channel) { this.channel = channel; }
    public CopyrightStatus getCopyrightStatus() { return copyrightStatus; }
    public void setCopyrightStatus(CopyrightStatus copyrightStatus) { this.copyrightStatus = copyrightStatus; }
    public Long getDuration() { return duration; }
    public void setDuration(Long duration) { this.duration = duration; }
    public String getUrl() { return url; }
    public void setUrl(String url) { this.url = url; }
    public Long getUsageCount() { return usageCount; }
    public void setUsageCount(Long usageCount) { this.usageCount = usageCount; }
    public Boolean getEnabled() { return enabled; }
    public void setEnabled(Boolean enabled) { this.enabled = enabled; }
    public DateTime getCreateTime() { return createTime; }
    public void setCreateTime(DateTime createTime) { this.createTime = createTime; }
    public DateTime getUpdateTime() { return updateTime; }
    public void setUpdateTime(DateTime updateTime) { this.updateTime = updateTime; }
}

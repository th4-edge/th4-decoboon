package com.th4.edge.decoboon.clue.content.bgm.repository;

import com.th4.edge.decoboon.clue.content.bgm.model.Bgm;
import com.th4.edge.decoboon.clue.video.configure.PublishChannel;
import com.th4.edge.framework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface BgmRepository extends JpaRepository<Bgm, Long> {

    List<Bgm> findByEnabledOrderByCreateTimeDesc(Boolean enabled);

    List<Bgm> findByChannelOrderByCreateTimeDesc(PublishChannel channel);

    List<Bgm> findByChannelAndEnabledOrderByCreateTimeDesc(PublishChannel channel, Boolean enabled);
}

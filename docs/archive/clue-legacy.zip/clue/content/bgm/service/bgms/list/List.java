package com.th4.edge.decoboon.clue.content.bgm.service.bgms.list;

import com.th4.edge.decoboon.clue.content.bgm.model.Bgm;
import com.th4.edge.framework.service.ModelService;

/**
 * BGM库列表服务：入参 = BGM库实体，响应 = 列表。
 */
public interface List extends ModelService<Bgm, java.util.List<Bgm>> {
}

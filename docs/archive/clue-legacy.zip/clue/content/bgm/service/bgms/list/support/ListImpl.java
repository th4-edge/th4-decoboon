package com.th4.edge.decoboon.clue.content.bgm.service.bgms.list.support;

import com.th4.edge.decoboon.clue.content.bgm.model.Bgm;
import com.th4.edge.decoboon.clue.content.bgm.repository.BgmRepository;
import com.th4.edge.decoboon.clue.content.bgm.service.bgms.list.List;
import com.th4.edge.decoboon.clue.video.configure.PublishChannel;
import com.th4.edge.framework.core.annotation.Description;
import com.th4.edge.framework.core.annotation.Note;
import com.th4.edge.framework.provider.inject.annotation.AutoInject;
import com.th4.edge.framework.service.annotation.ServiceName;
import org.springframework.stereotype.Service;

@Note("BGM库列表")
@Description("按渠道/启用状态查询BGM库")
@Service("decoboon/clue/content/bgm/list")
@ServiceName("list")
public class ListImpl implements List {

    @AutoInject
    private PublishChannel channel;

    @AutoInject
    private Boolean enabled;

    private final BgmRepository repository;

    public ListImpl(BgmRepository repository) {
        this.repository = repository;
    }

    @Override
    public java.util.List<Bgm> call(Bgm request) {
        if (channel != null) {
            return enabled == null
                    ? repository.findByChannelOrderByCreateTimeDesc(channel)
                    : repository.findByChannelAndEnabledOrderByCreateTimeDesc(channel, enabled);
        }
        return enabled == null ? repository.findAll() : repository.findByEnabledOrderByCreateTimeDesc(enabled);
    }
}

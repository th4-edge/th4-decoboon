package com.th4.edge.decoboon.clue.content.bgm.service.bgms.save;

import com.th4.edge.decoboon.clue.content.bgm.model.Bgm;
import com.th4.edge.framework.service.ModelService;

/**
 * BGM库保存服务：入参 = BGM库实体，响应 = 保存后的实体。
 */
public interface Save extends ModelService<Bgm, Bgm> {
}

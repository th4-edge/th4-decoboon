package com.th4.edge.decoboon.clue.content.bgm.service.bgms.save.support;

import com.th4.edge.decoboon.clue.asset.configure.CopyrightStatus;
import com.th4.edge.decoboon.clue.content.bgm.model.Bgm;
import com.th4.edge.decoboon.clue.content.bgm.repository.BgmRepository;
import com.th4.edge.decoboon.clue.content.bgm.service.bgms.save.Save;
import com.th4.edge.decoboon.clue.video.configure.PublishChannel;
import com.th4.edge.framework.core.annotation.Description;
import com.th4.edge.framework.core.annotation.Note;
import com.th4.edge.framework.provider.inject.annotation.AutoInject;
import com.th4.edge.framework.provider.validation.annotation.NotEmpty;
import com.th4.edge.framework.provider.validation.annotation.NotNull;
import com.th4.edge.framework.service.annotation.ServiceName;
import org.springframework.stereotype.Service;

@Note("BGM库保存")
@Description("新增BGM资源")
@Service("decoboon/clue/content/bgm/save")
@ServiceName("save")
public class SaveImpl implements Save {

    @AutoInject
    @NotEmpty
    private String name;

    @AutoInject
    private String style;

    @AutoInject
    @NotNull
    private PublishChannel channel;

    @AutoInject
    private CopyrightStatus copyrightStatus;

    @AutoInject
    private Long duration;

    @AutoInject
    private String url;

    @AutoInject
    private Boolean enabled;

    private final BgmRepository repository;

    public SaveImpl(BgmRepository repository) {
        this.repository = repository;
    }

    @Override
    public Bgm call(Bgm request) {
        Bgm e = new Bgm();
        e.setName(name);
        e.setStyle(style);
        e.setChannel(channel);
        e.setCopyrightStatus(copyrightStatus);
        e.setDuration(duration);
        e.setUrl(url);
        e.setUsageCount(0L);
        e.setEnabled(enabled == null ? Boolean.TRUE : enabled);
        return repository.save(e);
    }
}

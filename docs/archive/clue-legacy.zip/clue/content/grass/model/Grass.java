package com.th4.edge.decoboon.clue.content.grass.model;

import com.th4.edge.decoboon.clue.video.configure.PublishChannel;
import com.th4.edge.framework.core.annotation.Description;
import com.th4.edge.framework.core.annotation.Note;
import com.th4.edge.framework.data.date.model.DateTime;
import com.th4.edge.framework.data.jpa.annotation.Model;
import com.th4.edge.framework.data.jpa.keyword.annotation.Keyword;
import com.th4.edge.framework.data.model.AbstractModel;
import com.th4.edge.framework.data.model.prepare.annotation.CreateTime;
import com.th4.edge.framework.data.model.prepare.annotation.UpdateTime;
import jakarta.persistence.*;

@Note("种草库")
@Description("种草笔记模板：痛点→方案→案例→钩子")
@Model
@Entity
@Table(name = "db_clue_content_grass")
public class Grass extends AbstractModel {

    @Note("种草索引")
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long grassId;

    @Note("种草标题")
    @Keyword
    @Column(nullable = false, length = 128)
    private String title;

    @Note("适用场景")
    @Keyword
    @Column(length = 64)
    private String scene;

    @Note("发布渠道")
    @Column(nullable = false, length = 32)
    private PublishChannel channel;

    @Note("种草内容")
    @Keyword
    @Column(length = 2048)
    private String content;

    @Note("标签")
    @Keyword
    @Column(length = 256)
    private String tags;

    @Note("被引用次数")
    @Column
    private Long usageCount = 0L;

    @Note("启用状态")
    @Column
    private Boolean enabled = Boolean.TRUE;

    @Note("创建时间")
    @CreateTime
    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "dateTime", column = @Column(name = "create_dateTime")),
            @AttributeOverride(name = "date", column = @Column(name = "create_date")),
            @AttributeOverride(name = "time", column = @Column(name = "create_time")),
    })
    private DateTime createTime;

    @Note("更新时间")
    @UpdateTime
    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "dateTime", column = @Column(name = "update_dateTime")),
            @AttributeOverride(name = "date", column = @Column(name = "update_date")),
            @AttributeOverride(name = "time", column = @Column(name = "update_time")),
    })
    private DateTime updateTime;

    public Long getGrassId() { return grassId; }
    public void setGrassId(Long grassId) { this.grassId = grassId; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getScene() { return scene; }
    public void setScene(String scene) { this.scene = scene; }
    public PublishChannel getChannel() { return channel; }
    public void setChannel(PublishChannel channel) { this.channel = channel; }
    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }
    public String getTags() { return tags; }
    public void setTags(String tags) { this.tags = tags; }
    public Long getUsageCount() { return usageCount; }
    public void setUsageCount(Long usageCount) { this.usageCount = usageCount; }
    public Boolean getEnabled() { return enabled; }
    public void setEnabled(Boolean enabled) { this.enabled = enabled; }
    public DateTime getCreateTime() { return createTime; }
    public void setCreateTime(DateTime createTime) { this.createTime = createTime; }
    public DateTime getUpdateTime() { return updateTime; }
    public void setUpdateTime(DateTime updateTime) { this.updateTime = updateTime; }
}

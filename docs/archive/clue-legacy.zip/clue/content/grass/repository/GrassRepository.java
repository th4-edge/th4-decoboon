package com.th4.edge.decoboon.clue.content.grass.repository;

import com.th4.edge.decoboon.clue.content.grass.model.Grass;
import com.th4.edge.decoboon.clue.video.configure.PublishChannel;
import com.th4.edge.framework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface GrassRepository extends JpaRepository<Grass, Long> {

    List<Grass> findByEnabledOrderByCreateTimeDesc(Boolean enabled);

    List<Grass> findByChannelOrderByCreateTimeDesc(PublishChannel channel);

    List<Grass> findByChannelAndEnabledOrderByCreateTimeDesc(PublishChannel channel, Boolean enabled);
}

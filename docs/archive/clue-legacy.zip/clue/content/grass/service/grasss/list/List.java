package com.th4.edge.decoboon.clue.content.grass.service.grasss.list;

import com.th4.edge.decoboon.clue.content.grass.model.Grass;
import com.th4.edge.framework.service.ModelService;

/**
 * 种草库列表服务：入参 = 种草库实体，响应 = 列表。
 */
public interface List extends ModelService<Grass, java.util.List<Grass>> {
}

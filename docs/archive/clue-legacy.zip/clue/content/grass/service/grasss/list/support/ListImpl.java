package com.th4.edge.decoboon.clue.content.grass.service.grasss.list.support;

import com.th4.edge.decoboon.clue.content.grass.model.Grass;
import com.th4.edge.decoboon.clue.content.grass.repository.GrassRepository;
import com.th4.edge.decoboon.clue.content.grass.service.grasss.list.List;
import com.th4.edge.decoboon.clue.video.configure.PublishChannel;
import com.th4.edge.framework.core.annotation.Description;
import com.th4.edge.framework.core.annotation.Note;
import com.th4.edge.framework.provider.inject.annotation.AutoInject;
import com.th4.edge.framework.service.annotation.ServiceName;
import org.springframework.stereotype.Service;

@Note("种草库列表")
@Description("按渠道/启用状态查询种草库")
@Service("decoboon/clue/content/grass/list")
@ServiceName("list")
public class ListImpl implements List {

    @AutoInject
    private PublishChannel channel;

    @AutoInject
    private Boolean enabled;

    private final GrassRepository repository;

    public ListImpl(GrassRepository repository) {
        this.repository = repository;
    }

    @Override
    public java.util.List<Grass> call(Grass request) {
        if (channel != null) {
            return enabled == null
                    ? repository.findByChannelOrderByCreateTimeDesc(channel)
                    : repository.findByChannelAndEnabledOrderByCreateTimeDesc(channel, enabled);
        }
        return enabled == null ? repository.findAll() : repository.findByEnabledOrderByCreateTimeDesc(enabled);
    }
}

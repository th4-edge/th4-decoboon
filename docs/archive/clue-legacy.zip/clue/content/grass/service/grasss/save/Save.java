package com.th4.edge.decoboon.clue.content.grass.service.grasss.save;

import com.th4.edge.decoboon.clue.content.grass.model.Grass;
import com.th4.edge.framework.service.ModelService;

/**
 * 种草库保存服务：入参 = 种草库实体，响应 = 保存后的实体。
 */
public interface Save extends ModelService<Grass, Grass> {
}

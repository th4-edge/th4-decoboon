package com.th4.edge.decoboon.clue.content.grass.service.grasss.save.support;

import com.th4.edge.decoboon.clue.content.grass.model.Grass;
import com.th4.edge.decoboon.clue.content.grass.repository.GrassRepository;
import com.th4.edge.decoboon.clue.content.grass.service.grasss.save.Save;
import com.th4.edge.decoboon.clue.video.configure.PublishChannel;
import com.th4.edge.framework.core.annotation.Description;
import com.th4.edge.framework.core.annotation.Note;
import com.th4.edge.framework.provider.inject.annotation.AutoInject;
import com.th4.edge.framework.provider.validation.annotation.NotEmpty;
import com.th4.edge.framework.provider.validation.annotation.NotNull;
import com.th4.edge.framework.service.annotation.ServiceName;
import org.springframework.stereotype.Service;

@Note("种草库保存")
@Description("新增种草模板")
@Service("decoboon/clue/content/grass/save")
@ServiceName("save")
public class SaveImpl implements Save {

    @AutoInject
    @NotEmpty
    private String title;

    @AutoInject
    private String scene;

    @AutoInject
    @NotNull
    private PublishChannel channel;

    @AutoInject
    private String content;

    @AutoInject
    private String tags;

    @AutoInject
    private Boolean enabled;

    private final GrassRepository repository;

    public SaveImpl(GrassRepository repository) {
        this.repository = repository;
    }

    @Override
    public Grass call(Grass request) {
        Grass e = new Grass();
        e.setTitle(title);
        e.setScene(scene);
        e.setChannel(channel);
        e.setContent(content);
        e.setTags(tags);
        e.setUsageCount(0L);
        e.setEnabled(enabled == null ? Boolean.TRUE : enabled);
        return repository.save(e);
    }
}

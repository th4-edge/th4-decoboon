package com.th4.edge.decoboon.clue.content.subtitle.model;

import com.th4.edge.decoboon.clue.video.configure.PublishChannel;
import com.th4.edge.framework.core.annotation.Description;
import com.th4.edge.framework.core.annotation.Note;
import com.th4.edge.framework.data.date.model.DateTime;
import com.th4.edge.framework.data.jpa.annotation.Model;
import com.th4.edge.framework.data.jpa.keyword.annotation.Keyword;
import com.th4.edge.framework.data.model.AbstractModel;
import com.th4.edge.framework.data.model.prepare.annotation.CreateTime;
import com.th4.edge.framework.data.model.prepare.annotation.UpdateTime;
import jakarta.persistence.*;

@Note("字幕模板库")
@Description("短视频字幕模板：字体/颜色/位置/渠道适配")
@Model
@Entity
@Table(name = "db_clue_content_subtitle")
public class SubtitleTemplate extends AbstractModel {

    @Note("字幕模板索引")
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long subtitleId;

    @Note("模板名称")
    @Keyword
    @Column(nullable = false, length = 128)
    private String name;

    @Note("样式")
    @Keyword
    @Column(length = 64)
    private String style;

    @Note("适用渠道")
    @Column(nullable = false, length = 32)
    private PublishChannel channel;

    @Note("字体")
    @Column(length = 64)
    private String font;

    @Note("颜色")
    @Column(length = 32)
    private String color;

    @Note("位置")
    @Column(length = 32)
    private String position;

    @Note("使用次数")
    @Column
    private Long usageCount = 0L;

    @Note("启用状态")
    @Column
    private Boolean enabled = Boolean.TRUE;

    @Note("创建时间")
    @CreateTime
    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "dateTime", column = @Column(name = "create_dateTime")),
            @AttributeOverride(name = "date", column = @Column(name = "create_date")),
            @AttributeOverride(name = "time", column = @Column(name = "create_time")),
    })
    private DateTime createTime;

    @Note("更新时间")
    @UpdateTime
    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "dateTime", column = @Column(name = "update_dateTime")),
            @AttributeOverride(name = "date", column = @Column(name = "update_date")),
            @AttributeOverride(name = "time", column = @Column(name = "update_time")),
    })
    private DateTime updateTime;

    public Long getSubtitleId() { return subtitleId; }
    public void setSubtitleId(Long subtitleId) { this.subtitleId = subtitleId; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getStyle() { return style; }
    public void setStyle(String style) { this.style = style; }
    public PublishChannel getChannel() { return channel; }
    public void setChannel(PublishChannel channel) { this.channel = channel; }
    public String getFont() { return font; }
    public void setFont(String font) { this.font = font; }
    public String getColor() { return color; }
    public void setColor(String color) { this.color = color; }
    public String getPosition() { return position; }
    public void setPosition(String position) { this.position = position; }
    public Long getUsageCount() { return usageCount; }
    public void setUsageCount(Long usageCount) { this.usageCount = usageCount; }
    public Boolean getEnabled() { return enabled; }
    public void setEnabled(Boolean enabled) { this.enabled = enabled; }
    public DateTime getCreateTime() { return createTime; }
    public void setCreateTime(DateTime createTime) { this.createTime = createTime; }
    public DateTime getUpdateTime() { return updateTime; }
    public void setUpdateTime(DateTime updateTime) { this.updateTime = updateTime; }
}

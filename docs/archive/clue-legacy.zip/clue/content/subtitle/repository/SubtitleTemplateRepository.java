package com.th4.edge.decoboon.clue.content.subtitle.repository;

import com.th4.edge.decoboon.clue.content.subtitle.model.SubtitleTemplate;
import com.th4.edge.decoboon.clue.video.configure.PublishChannel;
import com.th4.edge.framework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface SubtitleTemplateRepository extends JpaRepository<SubtitleTemplate, Long> {

    List<SubtitleTemplate> findByEnabledOrderByCreateTimeDesc(Boolean enabled);

    List<SubtitleTemplate> findByChannelOrderByCreateTimeDesc(PublishChannel channel);

    List<SubtitleTemplate> findByChannelAndEnabledOrderByCreateTimeDesc(PublishChannel channel, Boolean enabled);
}

package com.th4.edge.decoboon.clue.content.subtitle.service.subtitles.list;

import com.th4.edge.decoboon.clue.content.subtitle.model.SubtitleTemplate;
import com.th4.edge.framework.service.ModelService;

/**
 * 字幕模板库列表服务：入参 = 字幕模板库实体，响应 = 列表。
 */
public interface List extends ModelService<SubtitleTemplate, java.util.List<SubtitleTemplate>> {
}

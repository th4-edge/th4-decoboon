package com.th4.edge.decoboon.clue.content.subtitle.service.subtitles.list.support;

import com.th4.edge.decoboon.clue.content.subtitle.model.SubtitleTemplate;
import com.th4.edge.decoboon.clue.content.subtitle.repository.SubtitleTemplateRepository;
import com.th4.edge.decoboon.clue.content.subtitle.service.subtitles.list.List;
import com.th4.edge.decoboon.clue.video.configure.PublishChannel;
import com.th4.edge.framework.core.annotation.Description;
import com.th4.edge.framework.core.annotation.Note;
import com.th4.edge.framework.provider.inject.annotation.AutoInject;
import com.th4.edge.framework.service.annotation.ServiceName;
import org.springframework.stereotype.Service;

@Note("字幕模板库列表")
@Description("按渠道/启用状态查询字幕模板库")
@Service("decoboon/clue/content/subtitle/list")
@ServiceName("list")
public class ListImpl implements List {

    @AutoInject
    private PublishChannel channel;

    @AutoInject
    private Boolean enabled;

    private final SubtitleTemplateRepository repository;

    public ListImpl(SubtitleTemplateRepository repository) {
        this.repository = repository;
    }

    @Override
    public java.util.List<SubtitleTemplate> call(SubtitleTemplate request) {
        if (channel != null) {
            return enabled == null
                    ? repository.findByChannelOrderByCreateTimeDesc(channel)
                    : repository.findByChannelAndEnabledOrderByCreateTimeDesc(channel, enabled);
        }
        return enabled == null ? repository.findAll() : repository.findByEnabledOrderByCreateTimeDesc(enabled);
    }
}

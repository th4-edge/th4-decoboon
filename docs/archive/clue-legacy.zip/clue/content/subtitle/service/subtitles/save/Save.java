package com.th4.edge.decoboon.clue.content.subtitle.service.subtitles.save;

import com.th4.edge.decoboon.clue.content.subtitle.model.SubtitleTemplate;
import com.th4.edge.framework.service.ModelService;

/**
 * 字幕模板库保存服务：入参 = 字幕模板库实体，响应 = 保存后的实体。
 */
public interface Save extends ModelService<SubtitleTemplate, SubtitleTemplate> {
}

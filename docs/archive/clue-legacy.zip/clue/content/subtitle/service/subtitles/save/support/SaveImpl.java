package com.th4.edge.decoboon.clue.content.subtitle.service.subtitles.save.support;

import com.th4.edge.decoboon.clue.content.subtitle.model.SubtitleTemplate;
import com.th4.edge.decoboon.clue.content.subtitle.repository.SubtitleTemplateRepository;
import com.th4.edge.decoboon.clue.content.subtitle.service.subtitles.save.Save;
import com.th4.edge.decoboon.clue.video.configure.PublishChannel;
import com.th4.edge.framework.core.annotation.Description;
import com.th4.edge.framework.core.annotation.Note;
import com.th4.edge.framework.provider.inject.annotation.AutoInject;
import com.th4.edge.framework.provider.validation.annotation.NotEmpty;
import com.th4.edge.framework.provider.validation.annotation.NotNull;
import com.th4.edge.framework.service.annotation.ServiceName;
import org.springframework.stereotype.Service;

@Note("字幕模板库保存")
@Description("新增字幕模板")
@Service("decoboon/clue/content/subtitle/save")
@ServiceName("save")
public class SaveImpl implements Save {

    @AutoInject
    @NotEmpty
    private String name;

    @AutoInject
    private String style;

    @AutoInject
    @NotNull
    private PublishChannel channel;

    @AutoInject
    private String font;

    @AutoInject
    private String color;

    @AutoInject
    private String position;

    @AutoInject
    private Boolean enabled;

    private final SubtitleTemplateRepository repository;

    public SaveImpl(SubtitleTemplateRepository repository) {
        this.repository = repository;
    }

    @Override
    public SubtitleTemplate call(SubtitleTemplate request) {
        SubtitleTemplate e = new SubtitleTemplate();
        e.setName(name);
        e.setStyle(style);
        e.setChannel(channel);
        e.setFont(font);
        e.setColor(color);
        e.setPosition(position);
        e.setUsageCount(0L);
        e.setEnabled(enabled == null ? Boolean.TRUE : enabled);
        return repository.save(e);
    }
}

package com.th4.edge.decoboon.clue.content.topic.model;

import com.th4.edge.decoboon.clue.video.configure.PublishChannel;
import com.th4.edge.framework.core.annotation.Description;
import com.th4.edge.framework.core.annotation.Note;
import com.th4.edge.framework.data.date.model.DateTime;
import com.th4.edge.framework.data.jpa.annotation.Model;
import com.th4.edge.framework.data.jpa.keyword.annotation.Keyword;
import com.th4.edge.framework.data.model.AbstractModel;
import com.th4.edge.framework.data.model.prepare.annotation.CreateTime;
import com.th4.edge.framework.data.model.prepare.annotation.UpdateTime;
import jakarta.persistence.*;

@Note("话题库")
@Description("按小区/户型/风格/渠道沉淀的选题话题")
@Model
@Entity
@Table(name = "db_clue_content_topic")
public class Topic extends AbstractModel {

    @Note("话题索引")
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long topicId;

    @Note("话题标题")
    @Keyword
    @Column(nullable = false, length = 128)
    private String title;

    @Note("发布渠道")
    @Column(nullable = false, length = 32)
    private PublishChannel channel;

    @Note("话题标签")
    @Keyword
    @Column(length = 256)
    private String tags;

    @Note("被引用次数")
    @Column
    private Long usageCount = 0L;

    @Note("启用状态")
    @Column
    private Boolean enabled = Boolean.TRUE;

    @Note("创建时间")
    @CreateTime
    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "dateTime", column = @Column(name = "create_dateTime")),
            @AttributeOverride(name = "date", column = @Column(name = "create_date")),
            @AttributeOverride(name = "time", column = @Column(name = "create_time")),
    })
    private DateTime createTime;

    @Note("更新时间")
    @UpdateTime
    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "dateTime", column = @Column(name = "update_dateTime")),
            @AttributeOverride(name = "date", column = @Column(name = "update_date")),
            @AttributeOverride(name = "time", column = @Column(name = "update_time")),
    })
    private DateTime updateTime;

    public Long getTopicId() { return topicId; }
    public void setTopicId(Long topicId) { this.topicId = topicId; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public PublishChannel getChannel() { return channel; }
    public void setChannel(PublishChannel channel) { this.channel = channel; }
    public String getTags() { return tags; }
    public void setTags(String tags) { this.tags = tags; }
    public Long getUsageCount() { return usageCount; }
    public void setUsageCount(Long usageCount) { this.usageCount = usageCount; }
    public Boolean getEnabled() { return enabled; }
    public void setEnabled(Boolean enabled) { this.enabled = enabled; }
    public DateTime getCreateTime() { return createTime; }
    public void setCreateTime(DateTime createTime) { this.createTime = createTime; }
    public DateTime getUpdateTime() { return updateTime; }
    public void setUpdateTime(DateTime updateTime) { this.updateTime = updateTime; }
}

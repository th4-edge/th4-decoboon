package com.th4.edge.decoboon.clue.content.topic.repository;

import com.th4.edge.decoboon.clue.content.topic.model.Topic;
import com.th4.edge.decoboon.clue.video.configure.PublishChannel;
import com.th4.edge.framework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface TopicRepository extends JpaRepository<Topic, Long> {

    List<Topic> findByEnabledOrderByCreateTimeDesc(Boolean enabled);

    List<Topic> findByChannelOrderByCreateTimeDesc(PublishChannel channel);

    List<Topic> findByChannelAndEnabledOrderByCreateTimeDesc(PublishChannel channel, Boolean enabled);
}

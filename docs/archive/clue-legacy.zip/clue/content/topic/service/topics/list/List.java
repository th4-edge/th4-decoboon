package com.th4.edge.decoboon.clue.content.topic.service.topics.list;

import com.th4.edge.decoboon.clue.content.topic.model.Topic;
import com.th4.edge.framework.service.ModelService;

/**
 * 话题库列表服务：入参 = 话题库实体，响应 = 列表。
 */
public interface List extends ModelService<Topic, java.util.List<Topic>> {
}

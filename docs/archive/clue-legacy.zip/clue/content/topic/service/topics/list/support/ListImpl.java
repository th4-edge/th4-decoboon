package com.th4.edge.decoboon.clue.content.topic.service.topics.list.support;

import com.th4.edge.decoboon.clue.content.topic.model.Topic;
import com.th4.edge.decoboon.clue.content.topic.repository.TopicRepository;
import com.th4.edge.decoboon.clue.content.topic.service.topics.list.List;
import com.th4.edge.decoboon.clue.video.configure.PublishChannel;
import com.th4.edge.framework.core.annotation.Description;
import com.th4.edge.framework.core.annotation.Note;
import com.th4.edge.framework.provider.inject.annotation.AutoInject;
import com.th4.edge.framework.service.annotation.ServiceName;
import org.springframework.stereotype.Service;

@Note("话题库列表")
@Description("按渠道/启用状态查询话题库")
@Service("decoboon/clue/content/topic/list")
@ServiceName("list")
public class ListImpl implements List {

    @AutoInject
    private PublishChannel channel;

    @AutoInject
    private Boolean enabled;

    private final TopicRepository repository;

    public ListImpl(TopicRepository repository) {
        this.repository = repository;
    }

    @Override
    public java.util.List<Topic> call(Topic request) {
        if (channel != null) {
            return enabled == null
                    ? repository.findByChannelOrderByCreateTimeDesc(channel)
                    : repository.findByChannelAndEnabledOrderByCreateTimeDesc(channel, enabled);
        }
        return enabled == null ? repository.findAll() : repository.findByEnabledOrderByCreateTimeDesc(enabled);
    }
}

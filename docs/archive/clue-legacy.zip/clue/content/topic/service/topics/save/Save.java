package com.th4.edge.decoboon.clue.content.topic.service.topics.save;

import com.th4.edge.decoboon.clue.content.topic.model.Topic;
import com.th4.edge.framework.service.ModelService;

/**
 * 话题库保存服务：入参 = 话题库实体，响应 = 保存后的实体。
 */
public interface Save extends ModelService<Topic, Topic> {
}

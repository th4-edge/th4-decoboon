package com.th4.edge.decoboon.clue.content.topic.service.topics.save.support;

import com.th4.edge.decoboon.clue.content.topic.model.Topic;
import com.th4.edge.decoboon.clue.content.topic.repository.TopicRepository;
import com.th4.edge.decoboon.clue.content.topic.service.topics.save.Save;
import com.th4.edge.decoboon.clue.video.configure.PublishChannel;
import com.th4.edge.framework.core.annotation.Description;
import com.th4.edge.framework.core.annotation.Note;
import com.th4.edge.framework.provider.inject.annotation.AutoInject;
import com.th4.edge.framework.provider.validation.annotation.NotEmpty;
import com.th4.edge.framework.provider.validation.annotation.NotNull;
import com.th4.edge.framework.service.annotation.ServiceName;
import org.springframework.stereotype.Service;

@Note("话题库保存")
@Description("新增话题")
@Service("decoboon/clue/content/topic/save")
@ServiceName("save")
public class SaveImpl implements Save {

    @AutoInject
    @NotEmpty
    private String title;

    @AutoInject
    @NotNull
    private PublishChannel channel;

    @AutoInject
    private String tags;

    @AutoInject
    private Boolean enabled;

    private final TopicRepository repository;

    public SaveImpl(TopicRepository repository) {
        this.repository = repository;
    }

    @Override
    public Topic call(Topic request) {
        Topic e = new Topic();
        e.setTitle(title);
        e.setChannel(channel);
        e.setTags(tags);
        e.setUsageCount(0L);
        e.setEnabled(enabled == null ? Boolean.TRUE : enabled);
        return repository.save(e);
    }
}

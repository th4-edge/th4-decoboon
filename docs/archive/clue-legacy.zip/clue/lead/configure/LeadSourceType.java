package com.th4.edge.decoboon.clue.lead.configure;

import com.th4.edge.framework.core.Attribute;
import com.th4.edge.framework.core.annotation.Note;

@Note("线索来源类型")
public enum LeadSourceType implements Attribute<String> {

    Douyin("抖音"),
    TubaRabbit("土巴兔"),
    FriendIntroduce("朋友介绍"),
    Other("其他");

    private final String name;

    LeadSourceType(String name) {
        this.name = name;
    }

    @Override
    public String getValue() {
        return toString();
    }

    @Override
    public String getName() {
        return name;
    }
}

package com.th4.edge.decoboon.clue.lead.configure;

import com.th4.edge.framework.core.Attribute;
import com.th4.edge.framework.core.annotation.Note;

@Note("线索状态")
public enum LeadState implements Attribute<String> {

    PendingContact("待联系"),
    PendingMeasure("待量房"),
    Measured("已量房"),
    Signed("已签约"),
    Abandoned("已流失");

    private final String name;

    LeadState(String name) {
        this.name = name;
    }

    @Override
    public String getValue() {
        return toString();
    }

    @Override
    public String getName() {
        return name;
    }
}

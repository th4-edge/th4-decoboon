package com.th4.edge.decoboon.clue.lead.model;
import jakarta.persistence.AttributeOverride;
import jakarta.persistence.AttributeOverrides;
import jakarta.persistence.Embedded;

import com.th4.edge.decoboon.clue.company.model.Company;
import com.th4.edge.decoboon.clue.company.model.Employee;
import com.th4.edge.decoboon.clue.lead.configure.LeadState;
import com.th4.edge.decoboon.clue.video.model.Video;
import com.th4.edge.framework.core.annotation.Description;
import com.th4.edge.framework.core.annotation.Note;
import com.th4.edge.framework.core.annotation.Unit;
import com.th4.edge.framework.data.date.model.DateTime;
import com.th4.edge.framework.data.jpa.annotation.Model;
import com.th4.edge.framework.data.jpa.keyword.annotation.Keyword;
import com.th4.edge.framework.data.model.AbstractModel;
import com.th4.edge.framework.data.model.prepare.annotation.CreateTime;
import com.th4.edge.framework.data.model.prepare.annotation.UpdateTime;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Note("获客线索")
@Description("业务员登记的客户线索，自动关联来源视频实现归因")
@Model
@Entity
@Table(name = "db_clue_lead")
public class Lead extends AbstractModel {

    @Note("线索索引")
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long leadId;

    @Note("登记业务员")
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "emp_id", nullable = false)
    private Employee emp;

    @Note("所属公司")
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "company_id", nullable = false)
    private Company company;

    @Note("客户称呼")
    @Keyword
    @Column(nullable = false, length = 32)
    private String customerName;

    @Note("联系电话/微信")
    @Keyword
    @Column(nullable = false, length = 64)
    private String contact;

    @Note("需求描述")
    @Keyword
    @Column(length = 512)
    private String requirement;

    @Note("来源视频")
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "video_id")
    private Video video;

    @Note("来源渠道")
    @Keyword
    @Column(length = 64)
    private String source;

    @Note("当前状态")
    @Column(nullable = false, length = 16)
    private LeadState state = LeadState.PendingContact;

    @Note("最近跟进时间")
    @Embedded

    @AttributeOverrides({

            @AttributeOverride(name="dateTime", column=@Column(name="follow_dateTime")),

            @AttributeOverride(name="date", column=@Column(name="follow_date")),

            @AttributeOverride(name="time", column=@Column(name="follow_time")),

            @AttributeOverride(name="year", column=@Column(name="follow_year")),

            @AttributeOverride(name="month", column=@Column(name="follow_month")),

            @AttributeOverride(name="day", column=@Column(name="follow_day")),

            @AttributeOverride(name="hour", column=@Column(name="follow_hour")),

            @AttributeOverride(name="minute", column=@Column(name="follow_minute")),

            @AttributeOverride(name="second", column=@Column(name="follow_second")),

            @AttributeOverride(name="week", column=@Column(name="follow_week")),

        })

    private DateTime lastFollowTime;

    @Note("预计产值")
    @Unit("元")
    @Column
    private Long estimatedValue;

    @Note("签约产值")
    @Unit("元")
    @Column
    private Long signedValue;

    @Note("创建时间")
    @CreateTime
    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name="dateTime", column=@Column(name="create_dateTime")),
            @AttributeOverride(name="date", column=@Column(name="create_date")),
            @AttributeOverride(name="time", column=@Column(name="create_time")),
            @AttributeOverride(name="year", column=@Column(name="create_year")),
            @AttributeOverride(name="month", column=@Column(name="create_month")),
            @AttributeOverride(name="day", column=@Column(name="create_day")),
            @AttributeOverride(name="hour", column=@Column(name="create_hour")),
            @AttributeOverride(name="minute", column=@Column(name="create_minute")),
            @AttributeOverride(name="second", column=@Column(name="create_second")),
            @AttributeOverride(name="week", column=@Column(name="create_week")),
        })
    private DateTime createTime;

    @Note("更新时间")
    @UpdateTime
    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name="dateTime", column=@Column(name="update_dateTime")),
            @AttributeOverride(name="date", column=@Column(name="update_date")),
            @AttributeOverride(name="time", column=@Column(name="update_time")),
            @AttributeOverride(name="year", column=@Column(name="update_year")),
            @AttributeOverride(name="month", column=@Column(name="update_month")),
            @AttributeOverride(name="day", column=@Column(name="update_day")),
            @AttributeOverride(name="hour", column=@Column(name="update_hour")),
            @AttributeOverride(name="minute", column=@Column(name="update_minute")),
            @AttributeOverride(name="second", column=@Column(name="update_second")),
            @AttributeOverride(name="week", column=@Column(name="update_week")),
        })
    private DateTime updateTime;

    public Long getLeadId() {
        return leadId;
    }

    public void setLeadId(Long leadId) {
        this.leadId = leadId;
    }

    public Employee getEmp() {
        return emp;
    }

    public void setEmp(Employee emp) {
        this.emp = emp;
    }

    public Company getCompany() {
        return company;
    }

    public void setCompany(Company company) {
        this.company = company;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getRequirement() {
        return requirement;
    }

    public void setRequirement(String requirement) {
        this.requirement = requirement;
    }

    public Video getVideo() {
        return video;
    }

    public void setVideo(Video video) {
        this.video = video;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public LeadState getState() {
        return state;
    }

    public void setState(LeadState state) {
        this.state = state;
    }

    public DateTime getLastFollowTime() {
        return lastFollowTime;
    }

    public void setLastFollowTime(DateTime lastFollowTime) {
        this.lastFollowTime = lastFollowTime;
    }

    public Long getEstimatedValue() {
        return estimatedValue;
    }

    public void setEstimatedValue(Long estimatedValue) {
        this.estimatedValue = estimatedValue;
    }

    public Long getSignedValue() {
        return signedValue;
    }

    public void setSignedValue(Long signedValue) {
        this.signedValue = signedValue;
    }

    public DateTime getCreateTime() {
        return createTime;
    }

    public void setCreateTime(DateTime createTime) {
        this.createTime = createTime;
    }

    public DateTime getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(DateTime updateTime) {
        this.updateTime = updateTime;
    }
}

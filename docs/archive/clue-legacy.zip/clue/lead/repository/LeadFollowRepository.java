package com.th4.edge.decoboon.clue.lead.repository;

import com.th4.edge.decoboon.clue.lead.model.LeadFollow;
import com.th4.edge.framework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface LeadFollowRepository extends JpaRepository<LeadFollow, Long> {

    List<LeadFollow> findByLead_LeadIdOrderByCreateTimeDesc(Long leadId);
}

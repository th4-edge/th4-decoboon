package com.th4.edge.decoboon.clue.lead.repository;

import com.th4.edge.decoboon.clue.lead.configure.LeadState;
import com.th4.edge.decoboon.clue.lead.model.Lead;
import com.th4.edge.framework.data.jpa.repository.JpaRepository;

import java.util.Collection;
import java.util.List;

public interface LeadRepository extends JpaRepository<Lead, Long> {

    List<Lead> findByEmp_EmpIdOrderByCreateTimeDesc(Long empId);

    List<Lead> findByCompany_CompanyIdOrderByCreateTimeDesc(Long companyId);

    List<Lead> findByCompany_CompanyIdAndStateOrderByCreateTimeDesc(Long companyId, LeadState state);

    List<Lead> findByEmp_EmpIdAndState(Long empId, LeadState state);

    long countByCompany_CompanyIdAndState(Long companyId, LeadState state);

    long countByCompany_CompanyIdAndStateIn(Long companyId, Collection<LeadState> states);

    long countByEmp_EmpId(Long empId);

    Lead findByLeadId(Long leadId);

    List<Lead> findByVideo_VideoId(Long videoId);
}

package com.th4.edge.decoboon.clue.lead.service.leads.follow;

import com.th4.edge.decoboon.clue.lead.model.LeadFollow;
import com.th4.edge.framework.provider.Provider;

/**
 * 线索跟进服务：业务员对线索做一次跟进记录，可同步推进线索状态。
 * 入参 = 跟进记录实体（为 LeadFollow 服务），响应 = 保存后的跟进记录。
 */
public interface Follow extends Provider<LeadFollow, LeadFollow> {
}

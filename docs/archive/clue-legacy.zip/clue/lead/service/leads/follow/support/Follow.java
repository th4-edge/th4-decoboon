package com.th4.edge.decoboon.clue.lead.service.leads.follow.support;

import com.th4.edge.decoboon.clue.company.model.Employee;
import com.th4.edge.decoboon.clue.company.repository.EmployeeRepository;
import com.th4.edge.decoboon.clue.lead.configure.LeadState;
import com.th4.edge.decoboon.clue.lead.model.Lead;
import com.th4.edge.decoboon.clue.lead.model.LeadFollow;
import com.th4.edge.decoboon.clue.lead.repository.LeadFollowRepository;
import com.th4.edge.decoboon.clue.lead.repository.LeadRepository;
import com.th4.edge.framework.core.annotation.Description;
import com.th4.edge.framework.core.annotation.Note;
import com.th4.edge.framework.data.date.model.DateTime;
import com.th4.edge.framework.exception.DefaultErrorCode;
import com.th4.edge.framework.exception.DefinedException;
import com.th4.edge.framework.provider.inject.annotation.AutoInject;
import com.th4.edge.framework.provider.validation.annotation.Length;
import com.th4.edge.framework.provider.validation.annotation.NotEmpty;
import com.th4.edge.framework.provider.validation.annotation.NotNull;
import com.th4.edge.framework.service.annotation.ServiceName;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

/**
 * 线索跟进实现：前端提交字段经 @AutoInject 成员变量注入并校验，
 * 创建跟进记录并同步更新线索状态/最近跟进时间/签约产值。
 */
@Note("线索跟进")
@Description("业务员对线索做跟进记录，可同步推进线索状态与签约产值")
@Service("decoboon/clue/lead/follow")
@ServiceName("follow")
public class Follow implements com.th4.edge.decoboon.clue.lead.service.leads.follow.Follow {

    /** 前端传入：线索 ID */
    @AutoInject
    @NotNull
    private Long leadId;

    /** 前端传入：跟进业务员 ID */
    @AutoInject
    @NotNull
    private Long empId;

    /** 前端传入：跟进内容 */
    @AutoInject
    @NotEmpty
    @Length(max = 512)
    private String content;

    /** 前端传入：跟进后新状态（可空，不传则不改变状态） */
    @AutoInject
    private LeadState toState;

    /** 前端传入：签约产值（当 toState=Signed 时使用） */
    @AutoInject
    private Long signedValue;

    private final LeadRepository leadRepository;
    private final LeadFollowRepository leadFollowRepository;
    private final EmployeeRepository employeeRepository;

    public Follow(LeadRepository leadRepository,
                  LeadFollowRepository leadFollowRepository,
                  EmployeeRepository employeeRepository) {
        this.leadRepository = leadRepository;
        this.leadFollowRepository = leadFollowRepository;
        this.employeeRepository = employeeRepository;
    }

    @Override
    @Transactional
    public LeadFollow call(LeadFollow request) {
        // 1. 按 leadId 查线索，不存在则抛业务异常
        Lead lead = leadRepository.findByLeadId(leadId);
        if (lead == null) {
            throw new DefinedException(new DefaultErrorCode("400", "线索不存在"));
        }

        // 2. 按 empId 查跟进业务员
        Employee emp = employeeRepository.findByEmpId(empId);

        // 3. 创建跟进记录并组装对象关联
        LeadFollow follow = new LeadFollow();
        follow.setLead(lead);
        follow.setEmp(emp);
        follow.setContent(content);
        follow.setToState(toState);
        LeadFollow saved = leadFollowRepository.save(follow);

        // 4. 更新线索：状态 / 最近跟进时间 / 签约产值
        if (toState != null) {
            lead.setState(toState);
        }
        lead.setLastFollowTime(new DateTime(LocalDateTime.now()));
        if (toState == LeadState.Signed && signedValue != null) {
            lead.setSignedValue(signedValue);
        }
        leadRepository.save(lead);

        // 5. 返回保存后的跟进记录
        return saved;
    }
}

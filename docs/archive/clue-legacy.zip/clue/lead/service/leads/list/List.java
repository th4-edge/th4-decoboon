package com.th4.edge.decoboon.clue.lead.service.leads.list;

import com.th4.edge.decoboon.clue.lead.model.Lead;
import com.th4.edge.framework.service.ModelService;

/**
 * 线索列表服务：我的线索 / 公司全部线索，支持按状态筛选。
 * 入参 = 线索实体（为 Lead 服务），响应 = 线索列表。
 */
public interface List extends ModelService<Lead, java.util.List<Lead>> {
}

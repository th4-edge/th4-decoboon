package com.th4.edge.decoboon.clue.lead.service.leads.list.support;

import com.th4.edge.decoboon.clue.company.model.Employee;
import com.th4.edge.decoboon.clue.lead.configure.LeadState;
import com.th4.edge.decoboon.clue.lead.model.Lead;
import com.th4.edge.decoboon.clue.lead.repository.LeadRepository;
import com.th4.edge.decoboon.clue.lead.service.leads.list.List;
import com.th4.edge.decoboon.clue.video.model.Video;
import com.th4.edge.framework.core.annotation.Description;
import com.th4.edge.framework.core.annotation.Note;
import com.th4.edge.framework.data.jackson.annotation.IgnoreProperties;
import com.th4.edge.framework.data.jackson.annotation.Properties;
import com.th4.edge.framework.data.jackson.annotation.ServiceProperties;
import com.th4.edge.framework.provider.inject.annotation.AutoInject;
import com.th4.edge.framework.service.annotation.ServiceName;
import org.springframework.stereotype.Service;

/**
 * 线索列表实现：查询条件（归属业务员/公司/状态）由 @AutoInject 成员变量注入，
 * 序列化时用 @ServiceProperties 过滤关联对象（员工/视频）的敏感与冗余字段。
 */
@Note("线索列表")
@Description("我的线索 / 公司全部线索，支持按状态筛选")
@ServiceProperties(
        uris = "decoboon/clue/lead/list",
        properties = @Properties(ignore = {
                @IgnoreProperties(model = Employee.class, properties = {"phone", "wechat", "displayCompanyName", "active"}),
                @IgnoreProperties(model = Video.class, properties = {"url", "size", "duration"})
        })
)
@Service("decoboon/clue/lead/list")
@ServiceName("list")
public class ListImpl implements List {

    /** 前端传入：归属业务员（我的线索） */
    @AutoInject
    private Long empId;

    /** 前端传入：所属公司（公司全部线索） */
    @AutoInject
    private Long companyId;

    /** 前端传入：线索状态 */
    @AutoInject
    private LeadState state;

    private final LeadRepository leadRepository;

    public ListImpl(LeadRepository leadRepository) {
        this.leadRepository = leadRepository;
    }

    @Override
    public java.util.List<Lead> call(Lead lead) {
        if (empId != null) {
            return state == null
                    ? leadRepository.findByEmp_EmpIdOrderByCreateTimeDesc(empId)
                    : leadRepository.findByEmp_EmpIdAndState(empId, state);
        }
        if (companyId != null) {
            return state == null
                    ? leadRepository.findByCompany_CompanyIdOrderByCreateTimeDesc(companyId)
                    : leadRepository.findByCompany_CompanyIdAndStateOrderByCreateTimeDesc(companyId, state);
        }
        return leadRepository.findAll();
    }
}

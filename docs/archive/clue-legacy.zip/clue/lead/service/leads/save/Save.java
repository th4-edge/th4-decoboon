package com.th4.edge.decoboon.clue.lead.service.leads.save;

import com.th4.edge.decoboon.clue.lead.model.Lead;
import com.th4.edge.framework.service.ModelService;

/**
 * 线索登记服务：业务员登记客户，自动关联来源视频（归因）。
 * 入参 = 线索实体，响应 = 登记后的线索。
 */
public interface Save extends ModelService<Lead, Lead> {
}

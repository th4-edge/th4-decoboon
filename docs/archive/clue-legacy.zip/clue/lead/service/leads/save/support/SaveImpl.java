package com.th4.edge.decoboon.clue.lead.service.leads.save.support;

import com.th4.edge.decoboon.clue.company.model.Company;
import com.th4.edge.decoboon.clue.company.model.Employee;
import com.th4.edge.decoboon.clue.company.repository.CompanyRepository;
import com.th4.edge.decoboon.clue.company.repository.EmployeeRepository;
import com.th4.edge.decoboon.clue.lead.configure.LeadState;
import com.th4.edge.decoboon.clue.lead.model.Lead;
import com.th4.edge.decoboon.clue.lead.repository.LeadRepository;
import com.th4.edge.decoboon.clue.lead.service.leads.save.Save;
import com.th4.edge.decoboon.clue.video.model.Video;
import com.th4.edge.decoboon.clue.video.repository.VideoRepository;
import com.th4.edge.framework.core.annotation.Description;
import com.th4.edge.framework.core.annotation.Note;
import com.th4.edge.framework.provider.inject.annotation.AutoInject;
import com.th4.edge.framework.provider.validation.annotation.Length;
import com.th4.edge.framework.provider.validation.annotation.NotEmpty;
import com.th4.edge.framework.provider.validation.annotation.NotNull;
import com.th4.edge.framework.service.annotation.ServiceName;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * 线索登记实现：前端提交字段经 @AutoInject 成员变量注入并校验，
 * 在 call() 内把业务员/公司/来源视频组装为对象关联后落库。
 */
@Note("线索登记")
@Description("业务员登记客户，自动关联来源视频（归因）")
@Service("decoboon/clue/lead/register")
@ServiceName("save")
public class SaveImpl implements Save {

    /** 前端传入：登记业务员 */
    @AutoInject
    @NotNull
    private Long empId;

    /** 前端传入：所属公司 */
    @AutoInject
    @NotNull
    private Long companyId;

    /** 前端传入：客户称呼 */
    @AutoInject
    @NotEmpty
    @Length(max = 32)
    private String customerName;

    /** 前端传入：联系电话/微信 */
    @AutoInject
    @NotEmpty
    @Length(max = 64)
    private String contact;

    /** 前端传入：需求描述 */
    @AutoInject
    @Length(max = 512)
    private String requirement;

    /** 前端传入：来源视频（归因，可空） */
    @AutoInject
    private Long videoId;

    /** 前端传入：来源渠道 */
    @AutoInject
    @Length(max = 64)
    private String source;

    private final LeadRepository leadRepository;
    private final EmployeeRepository employeeRepository;
    private final CompanyRepository companyRepository;
    private final VideoRepository videoRepository;

    public SaveImpl(LeadRepository leadRepository,
                    EmployeeRepository employeeRepository,
                    CompanyRepository companyRepository,
                    VideoRepository videoRepository) {
        this.leadRepository = leadRepository;
        this.employeeRepository = employeeRepository;
        this.companyRepository = companyRepository;
        this.videoRepository = videoRepository;
    }

    @Override
    @Transactional
    public Lead call(Lead lead) {
        Employee emp = employeeRepository.findByEmpId(empId);
        Company company = companyRepository.findByCompanyId(companyId);
        Video video = videoId == null ? null : videoRepository.findByVideoId(videoId);

        Lead saved = new Lead();
        saved.setEmp(emp);
        saved.setCompany(company);
        saved.setCustomerName(customerName);
        saved.setContact(contact);
        saved.setRequirement(requirement);
        // 归因：线索自动关联来源视频，便于老板看“每条视频带来多少客户”
        saved.setVideo(video);
        saved.setSource(source);
        saved.setState(LeadState.PendingContact);
        return leadRepository.save(saved);
    }
}

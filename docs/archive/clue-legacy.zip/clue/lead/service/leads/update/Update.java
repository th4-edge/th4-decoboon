package com.th4.edge.decoboon.clue.lead.service.leads.update;

import com.th4.edge.decoboon.clue.lead.model.Lead;
import com.th4.edge.framework.provider.Provider;

/**
 * 线索更新服务：业务员修改线索的客户信息/需求/来源/预计产值等字段。
 * 入参 = 线索实体（为 Lead 服务），响应 = 更新后的线索。
 */
public interface Update extends Provider<Lead, Lead> {
}

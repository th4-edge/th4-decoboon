package com.th4.edge.decoboon.clue.lead.service.leads.update.support;

import com.th4.edge.decoboon.clue.company.model.Employee;
import com.th4.edge.decoboon.clue.lead.model.Lead;
import com.th4.edge.decoboon.clue.lead.repository.LeadRepository;
import com.th4.edge.decoboon.clue.video.model.Video;
import com.th4.edge.decoboon.clue.video.repository.VideoRepository;
import com.th4.edge.framework.core.annotation.Description;
import com.th4.edge.framework.core.annotation.Note;
import com.th4.edge.framework.data.jackson.annotation.IgnoreProperties;
import com.th4.edge.framework.data.jackson.annotation.Properties;
import com.th4.edge.framework.data.jackson.annotation.ServiceProperties;
import com.th4.edge.framework.exception.DefaultErrorCode;
import com.th4.edge.framework.exception.DefinedException;
import com.th4.edge.framework.provider.inject.annotation.AutoInject;
import com.th4.edge.framework.provider.validation.annotation.Length;
import com.th4.edge.framework.provider.validation.annotation.NotNull;
import com.th4.edge.framework.service.annotation.ServiceName;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * 线索更新实现：前端提交字段经 @AutoInject 成员变量注入并校验，
 * 非空字段逐一覆盖到线索实体，传了 videoId 则更新来源视频关联。
 */
@Note("线索更新")
@Description("业务员修改线索客户信息/需求/来源/预计产值，可更新来源视频关联")
@ServiceProperties(
        uris = "decoboon/clue/lead/update",
        properties = @Properties(ignore = {
                @IgnoreProperties(model = Employee.class, properties = {"phone", "wechat"})
        })
)
@Service("decoboon/clue/lead/update")
@ServiceName("update")
public class Update implements com.th4.edge.decoboon.clue.lead.service.leads.update.Update {

    /** 前端传入：线索 ID */
    @AutoInject
    @NotNull
    private Long leadId;

    /** 前端传入：客户称呼（可空，不传不更新） */
    @AutoInject
    @Length(max = 32)
    private String customerName;

    /** 前端传入：联系电话/微信（可空） */
    @AutoInject
    @Length(max = 64)
    private String contact;

    /** 前端传入：需求描述（可空） */
    @AutoInject
    @Length(max = 512)
    private String requirement;

    /** 前端传入：来源渠道（可空） */
    @AutoInject
    @Length(max = 64)
    private String source;

    /** 前端传入：预计产值（可空） */
    @AutoInject
    private Long estimatedValue;

    /** 前端传入：来源视频 ID（可空，传了则更新关联） */
    @AutoInject
    private Long videoId;

    private final LeadRepository leadRepository;
    private final VideoRepository videoRepository;

    public Update(LeadRepository leadRepository, VideoRepository videoRepository) {
        this.leadRepository = leadRepository;
        this.videoRepository = videoRepository;
    }

    @Override
    @Transactional
    public Lead call(Lead request) {
        // 1. 按 leadId 查线索，不存在则抛业务异常
        Lead lead = leadRepository.findByLeadId(leadId);
        if (lead == null) {
            throw new DefinedException(new DefaultErrorCode("400", "线索不存在"));
        }

        // 2. 非空字段逐一覆盖
        if (customerName != null) {
            lead.setCustomerName(customerName);
        }
        if (contact != null) {
            lead.setContact(contact);
        }
        if (requirement != null) {
            lead.setRequirement(requirement);
        }
        if (source != null) {
            lead.setSource(source);
        }
        if (estimatedValue != null) {
            lead.setEstimatedValue(estimatedValue);
        }

        // 3. 传了 videoId 则查视频并更新来源视频关联
        if (videoId != null) {
            Video video = videoRepository.findByVideoId(videoId);
            if (video == null) {
                throw new DefinedException(new DefaultErrorCode("400", "来源视频不存在"));
            }
            lead.setVideo(video);
        }

        // 4. 保存并返回更新后的线索
        return leadRepository.save(lead);
    }
}

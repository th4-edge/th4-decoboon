package com.th4.edge.decoboon.clue.statistic.service.dashboard;

import com.th4.edge.framework.provider.Provider;

/**
 * 老板本月获客看板服务（统计域，入参为语义化统计查询条件）。
 * 响应 = 统计结果对象（非实体，统计域允许）。
 */
public interface Dashboard extends Provider<DashboardQuery, DashboardVo> {
}

package com.th4.edge.decoboon.clue.statistic.service.dashboard;

import com.th4.edge.framework.provider.validation.annotation.NotNull;

/**
 * 看板统计查询条件（统计域专属入参，非 DTO）。
 */
public class DashboardQuery {

    /** 公司 */
    @NotNull
    private Long companyId;

    /** 统计月份（yyyy-MM，可选，默认本月） */
    private String month;

    public Long getCompanyId() {
        return companyId;
    }

    public void setCompanyId(Long companyId) {
        this.companyId = companyId;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }
}

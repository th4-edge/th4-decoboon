package com.th4.edge.decoboon.clue.statistic.service.dashboard;

/**
 * 老板本月获客看板结果（统计域专属响应对象）。
 */
public class DashboardVo {

    private Long companyId;
    private String companyName;
    private Long videoCount;
    private Long leadCount;
    private Long pendingContactCount;
    private Long pendingMeasureCount;
    private Long measuredCount;
    private Long signedCount;
    private Long signedValue;
    private Long toolCost;
    private Long unitCost;

    public Long getCompanyId() {
        return companyId;
    }

    public void setCompanyId(Long companyId) {
        this.companyId = companyId;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public Long getVideoCount() {
        return videoCount;
    }

    public void setVideoCount(Long videoCount) {
        this.videoCount = videoCount;
    }

    public Long getLeadCount() {
        return leadCount;
    }

    public void setLeadCount(Long leadCount) {
        this.leadCount = leadCount;
    }

    public Long getPendingContactCount() {
        return pendingContactCount;
    }

    public void setPendingContactCount(Long pendingContactCount) {
        this.pendingContactCount = pendingContactCount;
    }

    public Long getPendingMeasureCount() {
        return pendingMeasureCount;
    }

    public void setPendingMeasureCount(Long pendingMeasureCount) {
        this.pendingMeasureCount = pendingMeasureCount;
    }

    public Long getMeasuredCount() {
        return measuredCount;
    }

    public void setMeasuredCount(Long measuredCount) {
        this.measuredCount = measuredCount;
    }

    public Long getSignedCount() {
        return signedCount;
    }

    public void setSignedCount(Long signedCount) {
        this.signedCount = signedCount;
    }

    public Long getSignedValue() {
        return signedValue;
    }

    public void setSignedValue(Long signedValue) {
        this.signedValue = signedValue;
    }

    public Long getToolCost() {
        return toolCost;
    }

    public void setToolCost(Long toolCost) {
        this.toolCost = toolCost;
    }

    public Long getUnitCost() {
        return unitCost;
    }

    public void setUnitCost(Long unitCost) {
        this.unitCost = unitCost;
    }
}

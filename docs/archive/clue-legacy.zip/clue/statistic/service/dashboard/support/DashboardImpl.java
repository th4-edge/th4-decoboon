package com.th4.edge.decoboon.clue.statistic.service.dashboard.support;

import com.th4.edge.decoboon.clue.company.model.Company;
import com.th4.edge.decoboon.clue.company.model.Employee;
import com.th4.edge.decoboon.clue.company.repository.CompanyRepository;
import com.th4.edge.decoboon.clue.company.repository.EmployeeRepository;
import com.th4.edge.decoboon.clue.lead.configure.LeadState;
import com.th4.edge.decoboon.clue.lead.model.Lead;
import com.th4.edge.decoboon.clue.lead.repository.LeadRepository;
import com.th4.edge.decoboon.clue.statistic.service.dashboard.Dashboard;
import com.th4.edge.decoboon.clue.statistic.service.dashboard.DashboardQuery;
import com.th4.edge.decoboon.clue.statistic.service.dashboard.DashboardVo;
import com.th4.edge.decoboon.clue.video.repository.VideoRepository;
import com.th4.edge.framework.core.annotation.Description;
import com.th4.edge.framework.core.annotation.Note;
import com.th4.edge.framework.service.annotation.ServiceName;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 老板本月获客看板实现：视频数/线索数/量房/签约/签约产值/单客成本（ROI 一目了然）。
 * 统计域允许语义化入参（DashboardQuery），不走 AutoInject 成员变量。
 */
@Note("老板看板")
@Description("老板本月获客看板：视频数/线索数/量房/签约/签约产值/单客成本")
@Service("decoboon/clue/statistic/dashboard")
@ServiceName("dashboard")
public class DashboardImpl implements Dashboard {

    private final CompanyRepository companyRepository;
    private final EmployeeRepository employeeRepository;
    private final VideoRepository videoRepository;
    private final LeadRepository leadRepository;

    public DashboardImpl(CompanyRepository companyRepository,
                         EmployeeRepository employeeRepository,
                         VideoRepository videoRepository,
                         LeadRepository leadRepository) {
        this.companyRepository = companyRepository;
        this.employeeRepository = employeeRepository;
        this.videoRepository = videoRepository;
        this.leadRepository = leadRepository;
    }

    @Override
    public DashboardVo call(DashboardQuery query) {
        Long companyId = query.getCompanyId();
        Company company = companyRepository.findByCompanyId(companyId);
        List<Employee> employees = employeeRepository.findByCompany_CompanyId(companyId);

        long videoCount = 0L;
        for (Employee emp : employees) {
            videoCount += videoRepository.countByEmp_EmpId(emp.getEmpId());
        }

        long signedCount = leadRepository.countByCompany_CompanyIdAndState(companyId, LeadState.Signed);
        long signedValue = 0L;
        for (Lead lead : leadRepository.findByCompany_CompanyIdAndStateOrderByCreateTimeDesc(companyId, LeadState.Signed)) {
            signedValue += (lead.getSignedValue() == null ? 0L : lead.getSignedValue());
        }

        DashboardVo vo = new DashboardVo();
        vo.setCompanyId(companyId);
        vo.setCompanyName(company == null ? null : company.getName());
        vo.setVideoCount(videoCount);
        vo.setLeadCount(leadRepository.countByCompany_CompanyIdAndStateIn(companyId, List.of(
                LeadState.PendingContact, LeadState.PendingMeasure, LeadState.Measured, LeadState.Signed)));
        vo.setPendingContactCount(leadRepository.countByCompany_CompanyIdAndState(companyId, LeadState.PendingContact));
        vo.setPendingMeasureCount(leadRepository.countByCompany_CompanyIdAndState(companyId, LeadState.PendingMeasure));
        vo.setMeasuredCount(leadRepository.countByCompany_CompanyIdAndState(companyId, LeadState.Measured));
        vo.setSignedCount(signedCount);
        vo.setSignedValue(signedValue);
        // 单客获客成本 = 工具成本 ÷ 签约数（对比土巴兔 3000 元）
        long toolCost = "299".equals(company == null ? null : company.getPlanCode()) ? 299L : 0L;
        vo.setToolCost(toolCost);
        vo.setUnitCost(signedCount == 0L ? 0L : Math.round(toolCost * 1.0 / signedCount));
        return vo;
    }
}

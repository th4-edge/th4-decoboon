package com.th4.edge.decoboon.clue.statistic.service.mydashboard;

import com.th4.edge.framework.provider.Provider;

/**
 * 业务员数据看板服务（统计域，入参为语义化统计查询条件）。
 * 响应 = 数据看板统计结果对象。
 */
public interface MyDashboard extends Provider<MyDashboardQuery, MyDashboardVo> {
}

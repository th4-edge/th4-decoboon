package com.th4.edge.decoboon.clue.statistic.service.mydashboard;

import com.th4.edge.framework.provider.validation.annotation.NotNull;

/**
 * 数据看板统计查询条件（统计域专属入参，非 DTO）。
 */
public class MyDashboardQuery {

    @NotNull
    private Long empId;

    /** 统计月份（1-12，可选，默认当前月） */
    private Integer month;

    public Long getEmpId() {
        return empId;
    }

    public void setEmpId(Long empId) {
        this.empId = empId;
    }

    public Integer getMonth() {
        return month;
    }

    public void setMonth(Integer month) {
        this.month = month;
    }
}

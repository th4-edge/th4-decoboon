package com.th4.edge.decoboon.clue.statistic.service.mydashboard;

import com.th4.edge.framework.core.annotation.Note;

/**
 * 业务员数据看板结果（统计域专属响应对象）。
 */
@Note("业务员数据看板结果")
public class MyDashboardVo {

    @Note("本月发布视频数")
    private Long monthPublishedCount = 0L;

    @Note("本月新增线索数")
    private Long monthNewLeadCount = 0L;

    @Note("待跟进线索数")
    private Long pendingFollowCount = 0L;

    @Note("本月签约数")
    private Long signedCount = 0L;

    @Note("本月签约产值")
    private Long signedValue = 0L;

    @Note("漏斗：待联系")
    private Long funnelPendingContact = 0L;

    @Note("漏斗：待量房")
    private Long funnelPendingMeasure = 0L;

    @Note("漏斗：已量房")
    private Long funnelMeasured = 0L;

    @Note("漏斗：已签约")
    private Long funnelSigned = 0L;

    @Note("我的发布数排名")
    private Integer myPublishedRank = 0;

    @Note("我的线索数排名")
    private Integer myLeadRank = 0;

    @Note("我的签约产值排名")
    private Integer mySignedValueRank = 0;

    @Note("团队人均发布数")
    private Double teamAvgPublished = 0.0;

    @Note("团队人均线索数")
    private Double teamAvgLead = 0.0;

    @Note("团队最高签约产值")
    private Long teamMaxSignedValue = 0L;

    @Note("团队人数")
    private Integer teamSize = 0;

    public Long getMonthPublishedCount() {
        return monthPublishedCount;
    }

    public void setMonthPublishedCount(Long monthPublishedCount) {
        this.monthPublishedCount = monthPublishedCount;
    }

    public Long getMonthNewLeadCount() {
        return monthNewLeadCount;
    }

    public void setMonthNewLeadCount(Long monthNewLeadCount) {
        this.monthNewLeadCount = monthNewLeadCount;
    }

    public Long getPendingFollowCount() {
        return pendingFollowCount;
    }

    public void setPendingFollowCount(Long pendingFollowCount) {
        this.pendingFollowCount = pendingFollowCount;
    }

    public Long getSignedCount() {
        return signedCount;
    }

    public void setSignedCount(Long signedCount) {
        this.signedCount = signedCount;
    }

    public Long getSignedValue() {
        return signedValue;
    }

    public void setSignedValue(Long signedValue) {
        this.signedValue = signedValue;
    }

    public Long getFunnelPendingContact() {
        return funnelPendingContact;
    }

    public void setFunnelPendingContact(Long funnelPendingContact) {
        this.funnelPendingContact = funnelPendingContact;
    }

    public Long getFunnelPendingMeasure() {
        return funnelPendingMeasure;
    }

    public void setFunnelPendingMeasure(Long funnelPendingMeasure) {
        this.funnelPendingMeasure = funnelPendingMeasure;
    }

    public Long getFunnelMeasured() {
        return funnelMeasured;
    }

    public void setFunnelMeasured(Long funnelMeasured) {
        this.funnelMeasured = funnelMeasured;
    }

    public Long getFunnelSigned() {
        return funnelSigned;
    }

    public void setFunnelSigned(Long funnelSigned) {
        this.funnelSigned = funnelSigned;
    }

    public Integer getMyPublishedRank() {
        return myPublishedRank;
    }

    public void setMyPublishedRank(Integer myPublishedRank) {
        this.myPublishedRank = myPublishedRank;
    }

    public Integer getMyLeadRank() {
        return myLeadRank;
    }

    public void setMyLeadRank(Integer myLeadRank) {
        this.myLeadRank = myLeadRank;
    }

    public Integer getMySignedValueRank() {
        return mySignedValueRank;
    }

    public void setMySignedValueRank(Integer mySignedValueRank) {
        this.mySignedValueRank = mySignedValueRank;
    }

    public Double getTeamAvgPublished() {
        return teamAvgPublished;
    }

    public void setTeamAvgPublished(Double teamAvgPublished) {
        this.teamAvgPublished = teamAvgPublished;
    }

    public Double getTeamAvgLead() {
        return teamAvgLead;
    }

    public void setTeamAvgLead(Double teamAvgLead) {
        this.teamAvgLead = teamAvgLead;
    }

    public Long getTeamMaxSignedValue() {
        return teamMaxSignedValue;
    }

    public void setTeamMaxSignedValue(Long teamMaxSignedValue) {
        this.teamMaxSignedValue = teamMaxSignedValue;
    }

    public Integer getTeamSize() {
        return teamSize;
    }

    public void setTeamSize(Integer teamSize) {
        this.teamSize = teamSize;
    }
}

package com.th4.edge.decoboon.clue.statistic.service.mydashboard.support;

import com.th4.edge.decoboon.clue.company.model.Employee;
import com.th4.edge.decoboon.clue.company.repository.EmployeeRepository;
import com.th4.edge.decoboon.clue.lead.configure.LeadState;
import com.th4.edge.decoboon.clue.lead.model.Lead;
import com.th4.edge.decoboon.clue.lead.repository.LeadRepository;
import com.th4.edge.decoboon.clue.statistic.service.mydashboard.MyDashboard;
import com.th4.edge.decoboon.clue.statistic.service.mydashboard.MyDashboardQuery;
import com.th4.edge.decoboon.clue.statistic.service.mydashboard.MyDashboardVo;
import com.th4.edge.decoboon.clue.video.configure.VideoState;
import com.th4.edge.decoboon.clue.video.model.Video;
import com.th4.edge.decoboon.clue.video.repository.VideoRepository;
import com.th4.edge.framework.core.annotation.Description;
import com.th4.edge.framework.core.annotation.Note;
import com.th4.edge.framework.data.date.model.DateTime;
import com.th4.edge.framework.service.annotation.ServiceName;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 业务员数据看板实现：本月发布/线索/签约/漏斗/团队排行/团队均值。
 * 统计域允许语义化入参（MyDashboardQuery），不走 AutoInject 成员变量。
 */
@Note("业务员数据看板")
@Description("业务员数据看板：本月数据+线索漏斗+团队排行+团队均值")
@Service("decoboon/clue/statistic/my-dashboard")
@ServiceName("my-dashboard")
public class MyDashboardImpl implements MyDashboard {

    private final EmployeeRepository employeeRepository;
    private final LeadRepository leadRepository;
    private final VideoRepository videoRepository;

    public MyDashboardImpl(EmployeeRepository employeeRepository,
                           LeadRepository leadRepository,
                           VideoRepository videoRepository) {
        this.employeeRepository = employeeRepository;
        this.leadRepository = leadRepository;
        this.videoRepository = videoRepository;
    }

    @Override
    public MyDashboardVo call(MyDashboardQuery query) {
        Long empId = query.getEmpId();
        Employee emp = employeeRepository.findByEmpId(empId);

        MyDashboardVo vo = new MyDashboardVo();
        if (emp == null || emp.getCompany() == null) {
            return vo;
        }

        Long companyId = emp.getCompany().getCompanyId();
        List<Employee> team = employeeRepository.findByCompany_CompanyId(companyId);
        int teamSize = team == null ? 0 : team.size();
        vo.setTeamSize(teamSize);

        LocalDate now = LocalDate.now();
        int targetYear = now.getYear();
        int targetMonth = query.getMonth() == null ? now.getMonthValue() : query.getMonth();

        // 计算每个员工的本月指标
        Map<Long, Long> publishedByEmp = new HashMap<>();
        Map<Long, Long> leadByEmp = new HashMap<>();
        Map<Long, Long> signedValueByEmp = new HashMap<>();

        long myPublished = 0L;
        long myLead = 0L;
        long mySignedCount = 0L;
        long mySignedValue = 0L;
        long pendingFollow = 0L;
        long funnelPendingContact = 0L;
        long funnelPendingMeasure = 0L;
        long funnelMeasured = 0L;
        long funnelSigned = 0L;

        if (team != null) {
            for (Employee member : team) {
                Long memberId = member.getEmpId();
                long memberPublished = 0L;
                long memberLead = 0L;
                long memberSignedValue = 0L;

                // 该员工本月发布视频数
                List<Video> memberVideos = videoRepository.findByEmp_EmpIdOrderByCreateTimeDesc(memberId);
                for (Video v : memberVideos) {
                    if (v.getState() == VideoState.Published && isTargetMonth(v.getCreateTime(), targetYear, targetMonth)) {
                        memberPublished++;
                    }
                }
                publishedByEmp.put(memberId, memberPublished);

                // 该员工本月线索 & 签约
                List<Lead> memberLeads = leadRepository.findByEmp_EmpIdOrderByCreateTimeDesc(memberId);
                for (Lead lead : memberLeads) {
                    boolean inMonth = isTargetMonth(lead.getCreateTime(), targetYear, targetMonth);
                    if (inMonth) {
                        memberLead++;
                        if (lead.getState() == LeadState.Signed) {
                            memberSignedValue += lead.getSignedValue() == null ? 0L : lead.getSignedValue();
                        }
                    }
                    // 当前员工的全量漏斗 & 待跟进
                    if (memberId.equals(empId)) {
                        LeadState state = lead.getState();
                        if (state == LeadState.PendingContact) {
                            funnelPendingContact++;
                            pendingFollow++;
                        } else if (state == LeadState.PendingMeasure) {
                            funnelPendingMeasure++;
                            pendingFollow++;
                        } else if (state == LeadState.Measured) {
                            funnelMeasured++;
                        } else if (state == LeadState.Signed) {
                            funnelSigned++;
                        }
                        if (inMonth) {
                            if (state == LeadState.Signed) {
                                mySignedCount++;
                            }
                        }
                    }
                }
                leadByEmp.put(memberId, memberLead);
                signedValueByEmp.put(memberId, memberSignedValue);

                if (memberId.equals(empId)) {
                    myPublished = memberPublished;
                    myLead = memberLead;
                    mySignedValue = memberSignedValue;
                }
            }
        }

        vo.setMonthPublishedCount(myPublished);
        vo.setMonthNewLeadCount(myLead);
        vo.setPendingFollowCount(pendingFollow);
        vo.setSignedCount(mySignedCount);
        vo.setSignedValue(mySignedValue);
        vo.setFunnelPendingContact(funnelPendingContact);
        vo.setFunnelPendingMeasure(funnelPendingMeasure);
        vo.setFunnelMeasured(funnelMeasured);
        vo.setFunnelSigned(funnelSigned);

        // 排行（并列取最小排名：严格大于者数量 + 1）
        vo.setMyPublishedRank(calcRank(publishedByEmp, empId));
        vo.setMyLeadRank(calcRank(leadByEmp, empId));
        vo.setMySignedValueRank(calcRank(signedValueByEmp, empId));

        // 团队均值 & 最高签约产值
        if (teamSize > 0) {
            long totalPublished = 0L;
            long totalLead = 0L;
            long maxSignedValue = 0L;
            for (Employee member : team) {
                Long mid = member.getEmpId();
                totalPublished += publishedByEmp.getOrDefault(mid, 0L);
                totalLead += leadByEmp.getOrDefault(mid, 0L);
                long sv = signedValueByEmp.getOrDefault(mid, 0L);
                if (sv > maxSignedValue) {
                    maxSignedValue = sv;
                }
            }
            vo.setTeamAvgPublished(round1(totalPublished * 1.0 / teamSize));
            vo.setTeamAvgLead(round1(totalLead * 1.0 / teamSize));
            vo.setTeamMaxSignedValue(maxSignedValue);
        }

        return vo;
    }

    private boolean isTargetMonth(DateTime createTime, int year, int month) {
        if (createTime == null) {
            return false;
        }
        Integer y = createTime.getYear();
        Integer m = createTime.getMonth();
        return y != null && m != null && y == year && m == month;
    }

    private int calcRank(Map<Long, Long> metricByEmp, Long empId) {
        Long myValue = metricByEmp.getOrDefault(empId, 0L);
        int greater = 0;
        for (Map.Entry<Long, Long> entry : metricByEmp.entrySet()) {
            if (entry.getValue() > myValue) {
                greater++;
            }
        }
        return greater + 1;
    }

    private double round1(double value) {
        return Math.round(value * 10.0) / 10.0;
    }
}

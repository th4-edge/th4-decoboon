package com.th4.edge.decoboon.clue.statistic.service.myworkbench;

import com.th4.edge.framework.provider.Provider;

/**
 * 业务员工作台统计服务（统计域，入参为语义化统计查询条件）。
 * 响应 = 工作台统计结果对象。
 */
public interface MyWorkbench extends Provider<MyWorkbenchQuery, MyWorkbenchVo> {
}

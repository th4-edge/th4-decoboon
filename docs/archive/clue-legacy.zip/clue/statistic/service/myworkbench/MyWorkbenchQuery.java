package com.th4.edge.decoboon.clue.statistic.service.myworkbench;

import com.th4.edge.framework.provider.validation.annotation.NotNull;

/**
 * 工作台统计查询条件（统计域专属入参，非 DTO）。
 */
public class MyWorkbenchQuery {

    @NotNull
    private Long empId;

    public Long getEmpId() {
        return empId;
    }

    public void setEmpId(Long empId) {
        this.empId = empId;
    }
}

package com.th4.edge.decoboon.clue.statistic.service.myworkbench;

import com.th4.edge.decoboon.clue.lead.model.Lead;
import com.th4.edge.decoboon.clue.video.model.Video;
import com.th4.edge.framework.core.annotation.Note;

import java.util.List;

/**
 * 业务员工作台统计结果（统计域专属响应对象）。
 */
@Note("业务员工作台统计结果")
public class MyWorkbenchVo {

    @Note("待联系线索数")
    private Long pendingContactCount = 0L;

    @Note("生成中任务数")
    private Long generatingTaskCount = 0L;

    @Note("草稿视频数")
    private Long draftVideoCount = 0L;

    @Note("今日发布视频数")
    private Long todayPublishedCount = 0L;

    @Note("今日新增线索数")
    private Long todayNewLeadCount = 0L;

    @Note("本周签约产值")
    private Long weekSignedValue = 0L;

    @Note("最近3条视频")
    private List<Video> recentVideos;

    @Note("最近3条线索")
    private List<Lead> recentLeads;

    public Long getPendingContactCount() {
        return pendingContactCount;
    }

    public void setPendingContactCount(Long pendingContactCount) {
        this.pendingContactCount = pendingContactCount;
    }

    public Long getGeneratingTaskCount() {
        return generatingTaskCount;
    }

    public void setGeneratingTaskCount(Long generatingTaskCount) {
        this.generatingTaskCount = generatingTaskCount;
    }

    public Long getDraftVideoCount() {
        return draftVideoCount;
    }

    public void setDraftVideoCount(Long draftVideoCount) {
        this.draftVideoCount = draftVideoCount;
    }

    public Long getTodayPublishedCount() {
        return todayPublishedCount;
    }

    public void setTodayPublishedCount(Long todayPublishedCount) {
        this.todayPublishedCount = todayPublishedCount;
    }

    public Long getTodayNewLeadCount() {
        return todayNewLeadCount;
    }

    public void setTodayNewLeadCount(Long todayNewLeadCount) {
        this.todayNewLeadCount = todayNewLeadCount;
    }

    public Long getWeekSignedValue() {
        return weekSignedValue;
    }

    public void setWeekSignedValue(Long weekSignedValue) {
        this.weekSignedValue = weekSignedValue;
    }

    public List<Video> getRecentVideos() {
        return recentVideos;
    }

    public void setRecentVideos(List<Video> recentVideos) {
        this.recentVideos = recentVideos;
    }

    public List<Lead> getRecentLeads() {
        return recentLeads;
    }

    public void setRecentLeads(List<Lead> recentLeads) {
        this.recentLeads = recentLeads;
    }
}

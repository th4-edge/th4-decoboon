package com.th4.edge.decoboon.clue.statistic.service.myworkbench.support;

import com.th4.edge.decoboon.clue.lead.configure.LeadState;
import com.th4.edge.decoboon.clue.lead.model.Lead;
import com.th4.edge.decoboon.clue.lead.repository.LeadRepository;
import com.th4.edge.decoboon.clue.statistic.service.myworkbench.MyWorkbench;
import com.th4.edge.decoboon.clue.statistic.service.myworkbench.MyWorkbenchQuery;
import com.th4.edge.decoboon.clue.statistic.service.myworkbench.MyWorkbenchVo;
import com.th4.edge.decoboon.clue.video.configure.VideoState;
import com.th4.edge.decoboon.clue.video.configure.VideoTaskState;
import com.th4.edge.decoboon.clue.video.model.Video;
import com.th4.edge.decoboon.clue.video.model.VideoTask;
import com.th4.edge.decoboon.clue.video.repository.VideoRepository;
import com.th4.edge.decoboon.clue.video.repository.VideoTaskRepository;
import com.th4.edge.framework.core.annotation.Description;
import com.th4.edge.framework.core.annotation.Note;
import com.th4.edge.framework.data.date.model.DateTime;
import com.th4.edge.framework.service.annotation.ServiceName;
import org.springframework.stereotype.Service;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.List;

/**
 * 业务员工作台统计实现：待联系/生成中/草稿/今日发布/今日线索/本周签约产值/最近视频线索。
 * 统计域允许语义化入参（MyWorkbenchQuery），不走 AutoInject 成员变量。
 */
@Note("业务员工作台")
@Description("业务员工作台：待办计数+今日数据+本周签约+最近视频线索")
@Service("decoboon/clue/statistic/my-workbench")
@ServiceName("my-workbench")
public class MyWorkbenchImpl implements MyWorkbench {

    private final LeadRepository leadRepository;
    private final VideoRepository videoRepository;
    private final VideoTaskRepository videoTaskRepository;

    public MyWorkbenchImpl(LeadRepository leadRepository,
                           VideoRepository videoRepository,
                           VideoTaskRepository videoTaskRepository) {
        this.leadRepository = leadRepository;
        this.videoRepository = videoRepository;
        this.videoTaskRepository = videoTaskRepository;
    }

    @Override
    public MyWorkbenchVo call(MyWorkbenchQuery query) {
        Long empId = query.getEmpId();
        LocalDate today = LocalDate.now();
        LocalDate weekStart = today.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY));
        LocalDate weekEnd = today.with(TemporalAdjusters.nextOrSame(DayOfWeek.SUNDAY));

        MyWorkbenchVo vo = new MyWorkbenchVo();

        // 待联系线索数
        long pendingContactCount = 0L;
        // 生成中任务数
        long generatingTaskCount = 0L;
        // 草稿视频数
        long draftVideoCount = 0L;
        // 今日发布视频数
        long todayPublishedCount = 0L;
        // 今日新增线索数
        long todayNewLeadCount = 0L;
        // 本周签约产值
        long weekSignedValue = 0L;

        // 线索全量（按 emp）
        List<Lead> leads = leadRepository.findByEmp_EmpIdOrderByCreateTimeDesc(empId);
        for (Lead lead : leads) {
            if (lead.getState() == LeadState.PendingContact) {
                pendingContactCount++;
            }
            if (isToday(lead.getCreateTime(), today)) {
                todayNewLeadCount++;
            }
            if (lead.getState() == LeadState.Signed && isThisWeek(lead.getCreateTime(), weekStart, weekEnd)) {
                weekSignedValue += lead.getSignedValue() == null ? 0L : lead.getSignedValue();
            }
        }

        // 视频任务全量（按 emp）
        List<VideoTask> tasks = videoTaskRepository.findByEmp_EmpIdOrderByCreateTimeDesc(empId);
        for (VideoTask task : tasks) {
            VideoTaskState state = task.getState();
            if (state != VideoTaskState.Done && state != VideoTaskState.Failed) {
                generatingTaskCount++;
            }
        }

        // 视频全量（按 emp）
        List<Video> videos = videoRepository.findByEmp_EmpIdOrderByCreateTimeDesc(empId);
        for (Video video : videos) {
            if (video.getState() == VideoState.Draft) {
                draftVideoCount++;
            }
            if (video.getState() == VideoState.Published && isToday(video.getCreateTime(), today)) {
                todayPublishedCount++;
            }
        }

        vo.setPendingContactCount(pendingContactCount);
        vo.setGeneratingTaskCount(generatingTaskCount);
        vo.setDraftVideoCount(draftVideoCount);
        vo.setTodayPublishedCount(todayPublishedCount);
        vo.setTodayNewLeadCount(todayNewLeadCount);
        vo.setWeekSignedValue(weekSignedValue);

        // 最近3条视频
        List<Video> recentVideos = new ArrayList<>();
        for (int i = 0; i < Math.min(3, videos.size()); i++) {
            recentVideos.add(videos.get(i));
        }
        vo.setRecentVideos(recentVideos);

        // 最近3条线索
        List<Lead> recentLeads = new ArrayList<>();
        for (int i = 0; i < Math.min(3, leads.size()); i++) {
            recentLeads.add(leads.get(i));
        }
        vo.setRecentLeads(recentLeads);

        return vo;
    }

    private boolean isToday(DateTime createTime, LocalDate today) {
        if (createTime == null) {
            return false;
        }
        Integer year = createTime.getYear();
        Integer month = createTime.getMonth();
        Integer day = createTime.getDay();
        return year != null && month != null && day != null
                && year == today.getYear()
                && month == today.getMonthValue()
                && day == today.getDayOfMonth();
    }

    private boolean isThisWeek(DateTime createTime, LocalDate weekStart, LocalDate weekEnd) {
        if (createTime == null) {
            return false;
        }
        LocalDate date = createTime.toLocalDate();
        if (date == null) {
            return false;
        }
        return !date.isBefore(weekStart) && !date.isAfter(weekEnd);
    }
}

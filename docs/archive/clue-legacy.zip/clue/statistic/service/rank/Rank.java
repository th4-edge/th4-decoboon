package com.th4.edge.decoboon.clue.statistic.service.rank;

import com.th4.edge.framework.provider.Provider;

import java.util.List;

/**
 * 业务员排行服务（统计域）：发了几条视频 / 带几条线索 / 签约额（激励与提醒）。
 */
public interface Rank extends Provider<RankQuery, List<RankVo>> {
}

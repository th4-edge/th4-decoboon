package com.th4.edge.decoboon.clue.statistic.service.rank;

/**
 * 业务员排行结果项（统计域专属响应对象）。
 */
public class RankVo {

    private Long empId;
    private String name;
    private Long videoCount;
    private Long leadCount;
    private Long signedCount;
    private Long signedValue;

    public Long getEmpId() {
        return empId;
    }

    public void setEmpId(Long empId) {
        this.empId = empId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Long getVideoCount() {
        return videoCount;
    }

    public void setVideoCount(Long videoCount) {
        this.videoCount = videoCount;
    }

    public Long getLeadCount() {
        return leadCount;
    }

    public void setLeadCount(Long leadCount) {
        this.leadCount = leadCount;
    }

    public Long getSignedCount() {
        return signedCount;
    }

    public void setSignedCount(Long signedCount) {
        this.signedCount = signedCount;
    }

    public Long getSignedValue() {
        return signedValue;
    }

    public void setSignedValue(Long signedValue) {
        this.signedValue = signedValue;
    }
}

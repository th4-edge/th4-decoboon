package com.th4.edge.decoboon.clue.statistic.service.rank.support;

import com.th4.edge.decoboon.clue.company.model.Employee;
import com.th4.edge.decoboon.clue.company.repository.EmployeeRepository;
import com.th4.edge.decoboon.clue.lead.configure.LeadState;
import com.th4.edge.decoboon.clue.lead.model.Lead;
import com.th4.edge.decoboon.clue.lead.repository.LeadRepository;
import com.th4.edge.decoboon.clue.statistic.service.rank.Rank;
import com.th4.edge.decoboon.clue.statistic.service.rank.RankQuery;
import com.th4.edge.decoboon.clue.statistic.service.rank.RankVo;
import com.th4.edge.decoboon.clue.video.repository.VideoRepository;
import com.th4.edge.framework.core.annotation.Description;
import com.th4.edge.framework.core.annotation.Note;
import com.th4.edge.framework.service.annotation.ServiceName;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * 业务员排行实现：发了几条视频 / 带几条线索 / 签约额（激励与提醒）。
 * 统计域允许语义化入参（RankQuery）。
 */
@Note("业务员排行")
@Description("业务员排行：视频数/线索数/签约额（激励与提醒）")
@Service("decoboon/clue/statistic/salesman-rank")
@ServiceName("rank")
public class RankImpl implements Rank {

    private final EmployeeRepository employeeRepository;
    private final VideoRepository videoRepository;
    private final LeadRepository leadRepository;

    public RankImpl(EmployeeRepository employeeRepository,
                    VideoRepository videoRepository,
                    LeadRepository leadRepository) {
        this.employeeRepository = employeeRepository;
        this.videoRepository = videoRepository;
        this.leadRepository = leadRepository;
    }

    @Override
    public List<RankVo> call(RankQuery query) {
        List<Employee> employees = employeeRepository.findByCompany_CompanyIdAndActiveTrue(query.getCompanyId());
        List<RankVo> ranks = new ArrayList<>();
        for (Employee emp : employees) {
            List<Lead> signedLeads = leadRepository.findByEmp_EmpIdAndState(emp.getEmpId(), LeadState.Signed);
            long signedValue = 0L;
            for (Lead lead : signedLeads) {
                signedValue += (lead.getSignedValue() == null ? 0L : lead.getSignedValue());
            }
            RankVo vo = new RankVo();
            vo.setEmpId(emp.getEmpId());
            vo.setName(emp.getName());
            vo.setVideoCount(videoRepository.countByEmp_EmpId(emp.getEmpId()));
            vo.setLeadCount(leadRepository.countByEmp_EmpId(emp.getEmpId()));
            vo.setSignedCount((long) signedLeads.size());
            vo.setSignedValue(signedValue);
            ranks.add(vo);
        }
        ranks.sort(Comparator.comparing(RankVo::getSignedValue).reversed());
        return ranks;
    }
}

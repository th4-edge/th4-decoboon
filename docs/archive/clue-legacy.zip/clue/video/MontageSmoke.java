package com.th4.edge.decoboon.clue.video;

import com.th4.edge.decoboon.clue.video.media.FfmpegCli;
import com.th4.edge.decoboon.clue.video.planner.SegmentPlan;
import com.th4.edge.decoboon.clue.video.planner.VideoPlanner;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/**
 * 混剪管线冒烟测试（不启动 Spring，直接 new Planner + Cli 跑通整条链路）。
 * 用法：java -cp "target/classes:target/lib/*" com.th4.edge.decoboon.clue.video.MontageSmoke
 */
public class MontageSmoke {

    private static final long TASK_ID = 999L;

    public static void main(String[] args) throws Exception {
        String base = Path.of("").toAbsolutePath().toString();
        List<String> images = List.of(
                base + "/data/media/task-8/slots/slot-1.jpg",
                base + "/data/media/task-8/slots/slot-2.jpg",
                base + "/data/media/task-8/slots/slot-3.jpg"
        );

        System.out.println("========== [1/4] 计划生成 ==========");
        VideoPlanner planner = new VideoPlanner();
        VideoPlanner.Options opts = VideoPlanner.Options.defaults();
        List<SegmentPlan> plans = planner.plan(images, opts);
        double totalDur = planner.totalDuration(plans);
        for (SegmentPlan p : plans) {
            System.out.printf("  段%d  时长=%.2fs  运镜=%s  zoom=%.2f→%.2f  brightness=%.3f%n",
                    p.index(), p.durationSec(), p.move(), p.zoomFrom(), p.zoomTo(), p.brightness());
        }
        System.out.printf("  成片总时长=%.2fs（含 %.1fs xfade 转场）%n", totalDur, opts.fadeSec());

        System.out.println("========== [2/4] 分段渲染（KenBurns + 色彩归一） ==========");
        FfmpegCli cli = new FfmpegCli();
        List<Path> segments = new ArrayList<>();
        long t0 = System.currentTimeMillis();
        for (SegmentPlan p : plans) {
            long s = System.currentTimeMillis();
            Path seg = cli.renderSegment(p, TASK_ID);
            segments.add(seg);
            System.out.printf("  段%d 渲染完成  %dms  -> %s%n", p.index(),
                    System.currentTimeMillis() - s, seg.getFileName());
        }
        System.out.printf("  分段渲染总耗时 %dms%n", System.currentTimeMillis() - t0);

        System.out.println("========== [3/4] 合并（xfade 交叉溶解） ==========");
        long m0 = System.currentTimeMillis();
        Path out = cli.mergeSegments(segments, opts.fadeSec(), totalDur, null, TASK_ID);
        System.out.printf("  合并完成  %dms  -> %s%n", System.currentTimeMillis() - m0, out);

        System.out.println("========== [4/4] 输出校验 ==========");
        ProcessBuilder pb = new ProcessBuilder("ffprobe", "-v", "error",
                "-select_streams", "v:0",
                "-show_entries", "stream=width,height,r_frame_rate,nb_frames,duration",
                "-show_entries", "format=size,bit_rate",
                "-of", "default=noprint_wrappers=1",
                out.toAbsolutePath().toString());
        pb.redirectErrorStream(true);
        Process p = pb.start();
        String probe = new String(p.getInputStream().readAllBytes());
        p.waitFor();
        System.out.println(probe);
        System.out.println("========== 冒烟测试通过 ==========");
        System.out.println("输出文件: " + out.toAbsolutePath());
    }
}

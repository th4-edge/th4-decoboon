package com.th4.edge.decoboon.clue.video.ai;

import com.th4.edge.decoboon.clue.video.configure.ScriptScene;
import com.th4.edge.decoboon.clue.video.configure.ScriptStructure;
import com.th4.edge.decoboon.clue.video.model.StyleProfile;
import com.th4.edge.decoboon.clue.video.model.Template;
import com.th4.edge.decoboon.clue.video.model.VideoScript;
import com.th4.edge.decoboon.clue.video.model.VideoTask;
import com.th4.edge.decoboon.clue.video.repository.StyleProfileRepository;
import com.th4.edge.decoboon.clue.video.repository.TemplateRepository;
import com.th4.edge.decoboon.clue.video.repository.VideoScriptRepository;
import com.th4.edge.decoboon.clue.video.media.AssetTaggerService;
import com.th4.edge.decoboon.clue.video.media.DashScopeVisionService;
import com.th4.edge.framework.core.annotation.Note;
import io.agentscope.core.message.Msg;
import io.agentscope.core.message.MsgRole;
import io.agentscope.core.model.Model;
import io.agentscope.core.model.ModelCreationContext;
import io.agentscope.core.model.ModelRegistry;
import io.agentscope.core.tool.Toolkit;
import io.agentscope.harness.agent.HarnessAgent;
import io.agentscope.harness.agent.memory.compaction.CompactionConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.nio.file.Path;
import java.time.Duration;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * AI 文案生成器：基于 AgentScope Harness + DeepSeek 生成抖音发布文案。
 * <p>
 * - 接入：ModelRegistry.resolve("deepseek:<model>")（openai 扩展内 DeepSeekModelProvider，SPI 自动注册）；
 * - Key 来源：application.yml 的 th4.edge.decoboon.ai.deepseek.api-key，或环境变量 DEEPSEEK_API_KEY；
 * - 未配置 Key 或调用失败时降级为本地 Mock 文案，保证出片流水线不被阻断。
 */
@Note("AI 文案生成器")
@Component
public class AiScriptWriter {

    private static final Logger log = LoggerFactory.getLogger(AiScriptWriter.class);

    private final TemplateRepository templateRepository;
    private final VideoScriptRepository scriptRepository;
    private final StyleProfileRepository styleProfileRepository;
    private final SaveVideoScriptTool saveVideoScriptTool;
    private final AssetTaggerService assetTaggerService;
    private final DashScopeVisionService visionService;
    private final AssetPickerService assetPickerService;
    private final String apiKey;
    private final String model;
    private final String baseUrl;
    /** L3 每段 I2V 生成秒数，用于约束文案时长与动效容量匹配 */
    private final int l3Duration;
    /** 话术直出次数上限：用满后退休轮换，防 100 条一个味 */
    private static final int SCRIPT_MAX_USE = 3;

    public AiScriptWriter(TemplateRepository templateRepository,
                          VideoScriptRepository scriptRepository,
                          StyleProfileRepository styleProfileRepository,
                          SaveVideoScriptTool saveVideoScriptTool,
                          AssetTaggerService assetTaggerService,
                          DashScopeVisionService visionService,
                          AssetPickerService assetPickerService,
                          @Value("${th4.edge.decoboon.ai.deepseek.api-key:}") String apiKey,
                          @Value("${th4.edge.decoboon.ai.deepseek.model:deepseek-chat}") String model,
                          @Value("${th4.edge.decoboon.ai.deepseek.base-url:https://api.deepseek.com}") String baseUrl,
                          @Value("${th4.edge.decoboon.video.l3.duration:10}") int l3Duration) {
        this.templateRepository = templateRepository;
        this.scriptRepository = scriptRepository;
        this.styleProfileRepository = styleProfileRepository;
        this.saveVideoScriptTool = saveVideoScriptTool;
        this.assetTaggerService = assetTaggerService;
        this.visionService = visionService;
        this.assetPickerService = assetPickerService;
        String resolvedKey = StringUtils.hasText(apiKey) ? apiKey : System.getenv("DEEPSEEK_API_KEY");
        this.apiKey = resolvedKey;
        this.model = model;
        this.baseUrl = baseUrl;
        this.l3Duration = Math.max(5, l3Duration);
    }

    /**
     * 为生成任务写文案：素材语义化（视觉识别）→ 素材描述注入 Prompt → DeepSeek 生成
     * → 一致性校验（不过则带素材关键词重写一次）→ 仍失败降级本地 Mock。
     */
    public ScriptResult writeScript(VideoTask task) {
        Template template = task.getTemplate();
        String sysPrompt = (template != null && StringUtils.hasText(template.getScriptPrompt()))
                ? template.getScriptPrompt()
                : "你是装修短视频文案写手，用接地气的口吻写抖音文案，像说真话的老朋友。";
        // A1+A2：素材语义化（描述入库复用，视觉识别失败降级文件名/备注）
        List<AssetTaggerService.AssetDesc> assets = assetTaggerService.describeAssets(task.getAssetIds(), task.getTaskId(), false);
        // ③ 素材自动筛选：AI 挑"值得出片"的图（控 I2V 成本、剔低信息量画面）；子集驱动文案与花字
        List<Long> pickedIds = assetPickerService.pick(assets, task.getTaskId());
        List<AssetTaggerService.AssetDesc> picked = new ArrayList<>();
        for (AssetTaggerService.AssetDesc a : assets) {
            if (pickedIds.contains(a.assetId())) {
                picked.add(a);
            }
        }
        List<String> taglines = new ArrayList<>();
        for (AssetTaggerService.AssetDesc a : picked) {
            if (StringUtils.hasText(a.tagline())) {
                taglines.add(a.tagline());
            }
        }
        // P2b 风格画像：按业务员加载画像（风格档+结构偏好）；无画像则随机抽结构保差异化
        Long empId = task.getEmp() == null ? null : task.getEmp().getEmpId();
        StyleProfile profile = empId == null ? null
                : styleProfileRepository.findByEmp_EmpIdAndEnabledTrue(empId);
        ScriptStructure structure = resolveStructure(profile);
        log.info("[P2b] 任务{} emp={} 画像={} 结构={}",
                task.getTaskId(), empId, profile == null ? "无" : profile.getStyle() + "/" + profile.getStructurePref(),
                structure == null ? "无" : structure.getName());
        String userPrompt = buildUserPrompt(task, template, picked, profile, structure);

        // P2a 话术库：按场景命中可复用话术 → 0 LLM 费直出（轮换防同质化）；未命中再走 LLM
        ScriptResult hit = tryHitScriptLib(task, template, picked, taglines, pickedIds, profile);
        if (hit != null) {
            return hit;
        }

        if (!StringUtils.hasText(apiKey)) {
            log.warn("[Ai] 未配置 DEEPSEEK_API_KEY，任务{} 使用本地 Mock 文案", task.getTaskId());
            return mockScript(task, template, taglines, pickedIds);
        }
        try {
            ScriptResult result = callDeepSeek(task, sysPrompt, userPrompt, taglines, pickedIds, picked, profile);
            // 超长兜底：文案太长会被 I2V 段强制慢放失真，压缩重写一次（模型偶发不守字数约束）
            int maxWords = (int) Math.round(Math.max(18, picked.size() * l3Duration - 8) * 4.5);
            if (result.content().length() > maxWords * 1.3) {
                log.info("[Ai] 任务{} 文案超长({}字>{})，压缩重写一次", task.getTaskId(), result.content().length(), maxWords);
                String compressPrompt = userPrompt
                        + "\n你上一版口播太长，压缩到约 " + maxWords + " 字：删掉啰嗦铺垫，保留开头钩子、核心施工卖点、结尾引导互动，"
                        + "每句话仍要能对上素材画面。只输出正文，从第一个字起就是可播正文。";
                ScriptResult compact = callDeepSeek(task, sysPrompt, compressPrompt, taglines, pickedIds, picked, profile);
                if (compact.content().length() < result.content().length()) {
                    result = compact;
                }
            }
            // C1 一致性校验：文案是否覆盖素材关键元素；仅当存在真实视觉描述时强制
            if (hasRealVision(picked) && !consistencyPass(result.content(), picked)) {
                log.warn("[Ai] 任务{} 文案未覆盖素材关键元素，携带素材描述重写一次", task.getTaskId());
                String retryPrompt = userPrompt
                        + "\n【重要】你上一版文案没有覆盖素材画面里的关键内容，观感会\"对不上画面\"。"
                        + "请围绕下面这些素材关键元素展开口播，至少分别提到或对应到它们：\n"
                        + String.join("、", keywords(picked))
                        + "\n重写一版，只输出最终可直接发布的口播脚本正文，严禁解释与 Markdown 标记。";
                ScriptResult retried = callDeepSeek(task, sysPrompt, retryPrompt, taglines, pickedIds, picked, profile);
                if (consistencyPass(retried.content(), picked)) {
                    log.info("[Ai] 任务{} 重写后文案通过一致性校验", task.getTaskId());
                    return retried;
                }
                log.warn("[Ai] 任务{} 重写后仍不达标，采用第二版（内容已贴近素材）", task.getTaskId());
                return retried;
            }
            return result;
        } catch (Exception e) {
            log.error("[Ai] DeepSeek 生成失败，任务{} 降级 Mock：{}", task.getTaskId(), e.getMessage(), e);
            return mockScript(task, template, taglines, pickedIds);
        }
    }

    /**
     * 通过 AgentScope Harness 调用 DeepSeek：Agent 携带模板 sysPrompt + 落盘工具，
     * 一次对话产出发布文案。
     */
    private ScriptResult callDeepSeek(VideoTask task, String sysPrompt, String userPrompt, List<String> taglines,
                                      List<Long> pickedAssetIds, List<AssetTaggerService.AssetDesc> picked,
                                      StyleProfile profile) {
        Model modelRef = ModelRegistry.resolve("deepseek:" + model,
                ModelCreationContext.builder().apiKey(apiKey).baseUrl(baseUrl).build());

        Toolkit toolkit = new Toolkit();
        toolkit.registerTool(saveVideoScriptTool);

        HarnessAgent agent = HarnessAgent.builder()
                .name("script-writer")
                .sysPrompt(sysPrompt)
                .model(modelRef)
                .workspace(Path.of("data", "agent-workspace", "task-" + task.getTaskId()))
                .compaction(CompactionConfig.builder()
                        .triggerMessages(8)
                        .keepMessages(4)
                        .flushBeforeCompact(true)
                        .build())
                .toolkit(toolkit)
                .maxIters(3)
                .maxRetries(2)
                .build();
        try (agent) {
            Msg resp = agent.call(Msg.builder().role(MsgRole.USER).textContent(userPrompt).build())
                    .block(Duration.ofSeconds(90));
            if (resp == null || !StringUtils.hasText(resp.getTextContent())) {
                throw new IllegalStateException("Agent 未返回文案内容");
            }
            String content = resp.getTextContent().trim();
            content = cleanContent(content);
            log.info("[Ai] 任务{} 文案生成成功（{}字）", task.getTaskId(), content.length());
            // P2a：LLM 新生成的话术自动入库沉淀（库随使用增长，后续同场景可免 LLM）
            saveToScriptLib(task, picked, content, profile);
            // 无论模型是否主动调用 save_video_script，均经工具落盘草稿，保证产物一致
            try {
                saveVideoScriptTool.save(content, String.valueOf(task.getTaskId()));
            } catch (Exception e) {
                log.warn("[Ai] 在线文案落盘失败: {}", e.getMessage());
            }
            return new ScriptResult(content, "#装修 #工地实拍 #合肥装修", "合肥", taglines, pickedAssetIds);
        }
    }

    // ---------- P2a 话术库：场景命中直出 + 差异化轮换 + 自动入库沉淀 ----------

    /** 场景关键词词典（按顺序匹配，先水电后其余） */
    private static final String[][] SCENE_DICT = {
            {ScriptScene.WaterElectric.toString(), "线管,水电,水管,封口,防水,接头,验收,强弱电,管道,渗水"},
            {ScriptScene.Tiling.toString(), "瓦工,贴砖,瓷砖,空鼓,找平,留缝"},
            {ScriptScene.Waterproof.toString(), "刷防水,闭水,返潮"},
            {ScriptScene.Cabinet.toString(), "定制,柜子,衣柜,橱柜,板材"},
    };

    /** 从素材描述 + 钩子推断话术场景 */
    private ScriptScene inferScene(List<AssetTaggerService.AssetDesc> assets, String hook) {
        StringBuilder text = new StringBuilder(hook == null ? "" : hook);
        for (AssetTaggerService.AssetDesc a : assets) {
            if (a.description() != null) {
                text.append(' ').append(a.description());
            }
        }
        String all = text.toString();
        for (String[] entry : SCENE_DICT) {
            for (String w : entry[1].split(",")) {
                if (all.contains(w)) {
                    return ScriptScene.valueOf(entry[0]);
                }
            }
        }
        return ScriptScene.General;
    }

    /** 话术 tags 是否对上素材画面（防"错场景话术"配错图，保持素材-文案对齐） */
    private boolean contentAligns(VideoScript script, List<AssetTaggerService.AssetDesc> assets) {
        if (!StringUtils.hasText(script.getTags())) {
            return false;
        }
        StringBuilder all = new StringBuilder();
        for (AssetTaggerService.AssetDesc a : assets) {
            if (a.description() != null) {
                all.append(a.description());
            }
        }
        String text = all.toString();
        for (String t : script.getTags().split(",")) {
            if (StringUtils.hasText(t) && text.contains(t.trim())) {
                return true;
            }
        }
        return false;
    }

    /**
     * 话术库命中：推断场景 → 查启用话术（效果分高/使用次数少优先）→
     * 未用满且内容对得上素材的，直接出稿（0 LLM 费），useCount++ 实现轮换防同质化。
     * 未命中返回 null，继续走 LLM。
     */
    private ScriptResult tryHitScriptLib(VideoTask task, Template template,
                                         List<AssetTaggerService.AssetDesc> picked,
                                         List<String> taglines, List<Long> pickedIds, StyleProfile profile) {
        try {
            int maxWords = (int) Math.round(Math.max(18, picked.size() * l3Duration - 8) * 4.5);
            ScriptScene scene = inferScene(picked, task.getHook());
            List<VideoScript> candidates = scriptRepository
                    .findBySceneAndEnabledTrueOrderByScoreDescUseCountAsc(scene);
            if (candidates.isEmpty()) {
                log.info("[ScriptLib] 场景{} 无可用话术，走 LLM", scene);
                return null;
            }
            for (VideoScript c : candidates) {
                if (c.getUseCount() >= SCRIPT_MAX_USE) {
                    continue; // 用满退休，轮换下一条
                }
                if (c.getContent().length() > maxWords * 1.3) {
                    continue; // 字数超 I2V 容量，跳过（避免慢放失真）
                }
                if (!styleMatches(profile, c)) {
                    continue; // P2b：话术风格与画像风格不符，跳过（走 LLM 按画像风格生成）
                }
                if (!contentAligns(c, picked)) {
                    continue; // 话术对不上本次素材画面，跳过
                }
                c.setUseCount(c.getUseCount() + 1);
                scriptRepository.save(c);
                try {
                    saveVideoScriptTool.save(c.getContent(), String.valueOf(task.getTaskId()));
                } catch (Exception e) {
                    log.warn("[Ai] 话术命中落盘失败: {}", e.getMessage());
                }
                log.info("[ScriptLib] 任务{} 命中话术#{} [{}·{}] 直出（{}字，已用{}/{}），0 LLM 调用",
                        task.getTaskId(), c.getScriptId(), scene, c.getStyle(), c.getContent().length(),
                        c.getUseCount(), SCRIPT_MAX_USE);
                return new ScriptResult(c.getContent(), "#装修 #工地实拍 #合肥装修", "合肥", taglines, pickedIds);
            }
            log.info("[ScriptLib] 场景{} 话术未命中（全用满/字数超/不对齐），走 LLM", scene);
            return null;
        } catch (Exception e) {
            log.warn("[ScriptLib] 话术命中异常，回退 LLM: {}", e.getMessage());
            return null;
        }
    }

    /** LLM 新生成文案自动入库：按场景归类，随使用增长成为差异化来源 */
    private void saveToScriptLib(VideoTask task, List<AssetTaggerService.AssetDesc> picked, String content, StyleProfile profile) {
        try {
            if (!StringUtils.hasText(content)) {
                return;
            }
            ScriptScene scene = inferScene(picked, task.getHook());
            List<String> kws = keywords(picked);
            String tags = kws.stream().limit(5).reduce((a, b) -> a + "," + b).orElse("");
            VideoScript s = new VideoScript();
            s.setScene(scene);
            s.setStyle(profile != null && StringUtils.hasText(profile.getStyle()) ? profile.getStyle() : "土味");
            s.setHook(StringUtils.hasText(task.getHook()) ? task.getHook() : null);
            s.setContent(content.length() > 2000 ? content.substring(0, 2000) : content);
            s.setTags(tags);
            s.setScore(0);
            s.setUseCount(0);
            s.setEnabled(Boolean.TRUE);
            scriptRepository.save(s);
            log.info("[ScriptLib] 任务{} 生成文案已入库（场景{}，id={}，{}字）", task.getTaskId(), scene, s.getScriptId(), content.length());
        } catch (Exception e) {
            log.warn("[ScriptLib] 文案入库失败: {}", e.getMessage());
        }
    }

    // ---------- 提示词泄漏清洗（C1 重写时模型偶发把重写指令/元叙述写进正文） ----------

    /** 删除正文中残留的生成/重写提示词片段，保证成片文案干净 */
    private String cleanContent(String raw) {
        if (!StringUtils.hasText(raw)) {
            return raw;
        }
        String s = raw;
        // 1) 已知整段指令残片（字面删除）
        for (String p : LEAK_LITERALS) {
            s = s.replace(p, "");
        }
        // 2) 循环剥离正文开头的"写作元叙述分句"（模型措辞多变，按语义特征兜底）
        String t = s;
        int stripped = 0;
        boolean changed = true;
        while (changed && stripped < 5) {
            Matcher m = META_CLAUSE.matcher(t);
            if (m.find()) {
                t = t.substring(m.end());
                stripped++;
            } else {
                changed = false;
            }
        }
        s = t;
        s = s.replaceAll("\\s+", " ").trim();
        s = s.replaceAll("^[，,。\\s]+", "").trim();
        return s;
    }

    private static final String[] LEAK_LITERALS = {
            "结尾引导互动。纯正文输出：",
            "结尾引导互动。",
            "纯正文输出：",
            "只输出最终可直接发布的口播脚本正文，严禁解释与 Markdown 标记。",
            "严禁任何解释、前缀、寒暄、\"收到/好的\"或 Markdown 标记。",
            "重写一版，",
            "请围绕下面这些素材关键元素展开口播，",
            "至少分别提到或对应到它们：",
            "【重要】你上一版文案没有覆盖素材画面里的关键内容，观感会\"对不上画面\"。",
    };

    /**
     * 写作元叙述分句：包含写作行为词（版本/切入/角度/措辞/重写/覆盖/画面/抓手/叙事等）
     * 或以中文引号引用"话术/结构/策略"的分句。真实口播正文是"直接面向观众说话"，
     * 几乎不以这些词开头、也不会在开头用引号引用术语；模型泄漏的重写指令则高频命中。
     * 从头逐句剥离（最多 5 句），直到开头分句不含元特征。
     */
    private static final Pattern META_CLAUSE = Pattern.compile(
            "^[^，,。\\n]{0,40}(?:版本|切入|角度|句式|措辞|重写|覆盖|画面|素材补全|写出|上一版|补全|纯正文|结尾引导|严禁|只输出|围绕|提到或对应|第[一二三四五六七八九十0-9]+版|抓手|叙事|引入|不重|前面几版|验收顺序|三步检查|[\\\"“][^，,。\\n]{0,25}[\\\"”])[^，,。\\n]{0,20}[，,。]");

    // ---------- P2b 风格画像：结构解析 + 风格匹配 + 风格描述 ----------

    /** 解析本次叙事结构：画像有首选结构用画像的，否则随机抽（保同素材差异化） */
    private ScriptStructure resolveStructure(StyleProfile profile) {
        if (profile != null && StringUtils.hasText(profile.getStructurePref())) {
            try {
                return ScriptStructure.valueOf(profile.getStructurePref());
            } catch (IllegalArgumentException e) {
                // 画像结构名非法则回落随机
            }
        }
        ScriptStructure[] all = ScriptStructure.values();
        return all[(int) (Math.random() * all.length)];
    }

    /** 话术风格是否匹配画像风格（无画像或画像无风格时全部通过） */
    private boolean styleMatches(StyleProfile profile, VideoScript script) {
        if (profile == null || !StringUtils.hasText(profile.getStyle())) {
            return true;
        }
        return profile.getStyle().equals(script.getStyle());
    }

    /** 风格档 → 口播口吻描述（注入生成提示词） */
    private String styleDesc(String style) {
        switch (style == null ? "" : style) {
            case "土味":
                return "像村里老大哥说话，直白接地气不端着，爱用\"瞧/咱/说白了/讲究/得抠\"这类词，敢说得罪人的大实话";
            case "专业":
                return "像干了多年的工程监理，术语准确、条理清晰、给人专业信服感，但别太书面";
            case "唠嗑":
                return "像邻居串门唠家常，亲切口语化、有来有回，多用\"你想想/是不是这么回事\"";
            case "悬念":
                return "开头先抛钩子吊胃口，语气带\"你绝对想不到\"的神秘感，中段再揭答案";
            case "权威":
                return "像装修行业老法师，上来先给结论，语气笃定，末尾给专业判断";
            default:
                return "接地气、口语化、像说真话的老朋友";
        }
    }

    private String buildUserPrompt(VideoTask task, Template template, List<AssetTaggerService.AssetDesc> assets,
                                      StyleProfile profile, ScriptStructure structure) {
        StringBuilder sb = new StringBuilder();
        sb.append("请生成一条可直接发布到抖音的装修短视频文案，包含：口播脚本 + 发布文案。\n");
        if (template != null) {
            sb.append("模板类型：").append(template.getName()).append("\n");
        }
        // P2b 风格画像注入：风格档 + 叙事结构骨架
        if (profile != null && StringUtils.hasText(profile.getStyle())) {
            sb.append("口播风格（按业务员画像）：").append(styleDesc(profile.getStyle())).append("\n");
        }
        if (structure != null) {
            sb.append("叙事结构：").append(structure.getName()).append("——").append(structure.getDesc())
                    .append("。开头钩子套路：").append(structure.getHookTip()).append("\n");
        }
        if (StringUtils.hasText(task.getHook())) {
            sb.append("选定的标题钩子：").append(task.getHook()).append("\n");
        }
        int n = assets == null || assets.isEmpty() ? 1 : assets.size();
        if (assets != null && !assets.isEmpty()) {
            sb.append("以下是本次使用的实拍素材画面内容（按播放顺序）：\n");
            for (int i = 0; i < assets.size(); i++) {
                AssetTaggerService.AssetDesc a = assets.get(i);
                sb.append("素材").append(i + 1).append("：").append(a.description()).append("\n");
            }
            sb.append("要求：口播内容必须围绕上述素材画面展开，每句话都能对应到某张素材上的画面；"
                    + "严禁编造素材画面里没有的东西（如画面里没有飘窗就不要说采光）。");
        } else {
            sb.append("素材图片ID：").append(task.getAssetIds()).append("\n");
        }
        // 配音时长与 L3 I2V 总容量匹配：文案太长会导致 AI 动效段被强制慢放而失真
        int maxSec = Math.max(18, n * l3Duration - 8);
        int maxWords = (int) Math.round(maxSec * 4.5);
        sb.append("要求：口语化、接地气、像真话；口播正文控制在 ").append(maxWords)
                .append(" 字以内（约 ").append(maxSec)
                .append(" 秒，全片 ").append(n).append(" 段 AI 动效短片每段 ").append(l3Duration)
                .append(" 秒，文案再长就要被强制慢放、观感失真）。");
        sb.append("硬性要求：从第一个字起就是可直接口播的正文，严禁任何解释、前缀、寒暄、\"收到/好的\"或 Markdown 标记；"
                + "严禁出现\"版本/切入/角度/措辞/重写/画面/抓手/叙事\"等写作说明类字眼。");
        return sb.toString();
    }

    // ---------- C1 一致性校验（轻量关键词覆盖） ----------

    private static final String[] LEXICON = {
            "水电", "管道", "线管", "强弱电", "强电", "弱电", "防水", "贴砖", "瓷砖", "墙面", "墙面基层",
            "地面", "毛坯", "水泥", "飘窗", "落地窗", "窗户", "吊顶", "石膏板", "乳胶漆", "底漆", "腻子",
            "开槽", "插座", "开关", "柜子", "厨房", "卫生间", "阳台", "验收", "返工", "增项", "点位",
            "标识", "烟道", "地漏", "下水", "排水", "水管", "保温", "隔音", "门窗", "泥工", "木工",
            "漆工", "龙骨", "线管", "线盒", "焊点", "密封", "管线", "黄色", "绿色", "红色"
    };

    private boolean hasRealVision(List<AssetTaggerService.AssetDesc> assets) {
        // 视觉识别输出包含"可讲卖点"，据此判定是否为真实画面描述
        return visionService.isEnabled() && assets != null && assets.stream()
                .anyMatch(a -> a.description() != null && a.description().contains("可讲卖点"));
    }

    private List<String> extractKeywords(String desc) {
        List<String> out = new java.util.ArrayList<>();
        if (desc == null) {
            return out;
        }
        for (String w : LEXICON) {
            if (desc.contains(w)) {
                out.add(w);
            }
        }
        return out;
    }

    private java.util.List<String> keywords(List<AssetTaggerService.AssetDesc> assets) {
        java.util.LinkedHashSet<String> set = new java.util.LinkedHashSet<>();
        for (AssetTaggerService.AssetDesc a : assets) {
            set.addAll(extractKeywords(a.description()));
        }
        return new java.util.ArrayList<>(set);
    }

    private boolean consistencyPass(String content, List<AssetTaggerService.AssetDesc> assets) {
        java.util.List<String> keys = keywords(assets);
        if (keys.isEmpty()) {
            return true; // 无关键词可校验，视为通过
        }
        int hit = 0;
        for (String k : keys) {
            if (content.contains(k)) {
                hit++;
            }
        }
        int required = Math.max(2, Math.min(3, assets.size()));
        boolean pass = hit >= Math.min(required, keys.size());
        log.info("[Ai] 一致性校验: 命中 {}/{} 关键词(要求≥{}) -> {}", hit, keys.size(), required, pass ? "通过" : "重写");
        return pass;
    }

    private ScriptResult mockScript(VideoTask task, Template template, List<String> taglines, List<Long> pickedAssetIds) {
        String hook = StringUtils.hasText(task.getHook()) ? task.getHook() : "装修不踩坑，这3个细节一定要盯住";
        String templateName = template == null ? "通用模板" : template.getName();
        String content = "【Mock 文案 · 未配置 DEEPSEEK_API_KEY】\n"
                + "标题：" + hook + "\n\n"
                + "装修公司施工中，今天带大家看看「" + templateName + "」的真实现场。\n"
                + "水电改造横平竖直，强弱电分开，验收单一项一项打勾，业主看得明明白白。\n"
                + "装修最怕什么？怕返工、怕增项、怕说不清。我们每天把进度发群里，您随时看。\n"
                + "想了解您家户型怎么装？评论区留户型，我给您出个初步方案。";
        // Mock 路径同样经由 Agent 工具落盘，保证草稿产物一致
        try {
            saveVideoScriptTool.save(content, String.valueOf(task.getTaskId()));
        } catch (Exception e) {
            log.warn("[Ai] Mock 文案落盘失败: {}", e.getMessage());
        }
        return new ScriptResult(content, "#装修 #工地实拍 #合肥装修", "合肥", taglines, pickedAssetIds);
    }

    /** 文案生成结果 */
    public record ScriptResult(String content, String hashtags, String locationTip, List<String> taglines,
                               List<Long> pickedAssetIds) {
    }
}

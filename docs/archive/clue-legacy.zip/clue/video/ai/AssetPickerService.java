package com.th4.edge.decoboon.clue.video.ai;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.th4.edge.decoboon.clue.video.media.AssetTaggerService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * 素材自动筛选：用 DeepSeek 一次性审阅全部素材描述，按"出片价值"挑出值得做 I2V 的图并排序。
 * 目标：控 I2V 成本（不烧"没得讲"的图）、提升成片信息密度（只讲有价值的画面）。
 * 保底策略：素材过少 / LLM 失败 / 挑太少 → 回退全量，绝不阻断流水线。
 */
@Service
public class AssetPickerService {

    private static final Logger log = LoggerFactory.getLogger(AssetPickerService.class);

    private final boolean enabled;
    private final int topN;
    private final int min;
    private final long callTimeoutMs;
    private final String apiKey;
    private final String model;
    private final String baseUrl;
    private final HttpClient http;
    private final ObjectMapper mapper = new ObjectMapper();

    public AssetPickerService(
            @Value("${th4.edge.decoboon.video.l3.pick.enabled:false}") boolean enabled,
            @Value("${th4.edge.decoboon.video.l3.pick.top-n:5}") int topN,
            @Value("${th4.edge.decoboon.video.l3.pick.min:2}") int min,
            @Value("${th4.edge.decoboon.video.l3.pick.call-timeout-ms:30000}") long callTimeoutMs,
            @Value("${th4.edge.decoboon.ai.deepseek.api-key:}") String apiKey,
            @Value("${th4.edge.decoboon.ai.deepseek.model:deepseek-chat}") String model,
            @Value("${th4.edge.decoboon.ai.deepseek.base-url:https://api.deepseek.com}") String baseUrl) {
        this.enabled = enabled;
        this.topN = Math.max(1, topN);
        this.min = Math.max(1, min);
        this.callTimeoutMs = callTimeoutMs;
        this.apiKey = apiKey;
        this.model = model;
        this.baseUrl = baseUrl;
        this.http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10)).build();
    }

    /**
     * 从素材描述里挑出"值得出片"的子集，返回按出片价值排序的 assetId 列表。
     * 素材数 &lt;= min 时不筛选；LLM 失败或解析不出结果时回退全量。
     */
    public List<Long> pick(List<AssetTaggerService.AssetDesc> assets, Long taskId) {
        if (!enabled || assets == null || assets.size() <= min) {
            return allIds(assets);
        }
        if (!StringUtils.hasText(apiKey)) {
            log.warn("[Picker] 未配置 DEEPSEEK_API_KEY，任务{} 素材不筛选（全量出片）", taskId);
            return allIds(assets);
        }
        try {
            List<Long> picked = callDeepSeek(assets, taskId);
            // 保底：挑得太少 → 按描述信息量补足到 min 张
            Set<Long> set = new LinkedHashSet<>(picked);
            if (set.size() < min) {
                for (AssetTaggerService.AssetDesc a : assets) {
                    if (set.size() >= min) {
                        break;
                    }
                    set.add(a.assetId());
                }
            }
            // 上限：最多 topN 张
            List<Long> result = new ArrayList<>(set);
            if (result.size() > topN) {
                result = result.subList(0, topN);
            }
            log.info("[Picker] 任务{} 素材筛选 {}→{}：{}", taskId, assets.size(), result.size(), result);
            return result;
        } catch (Exception e) {
            log.warn("[Picker] 素材筛选失败，任务{} 回退全量：{}", taskId, e.getMessage());
            return allIds(assets);
        }
    }

    /** 调 DeepSeek：审阅每张图描述，输出出片价值排序的 assetId 数组 */
    private List<Long> callDeepSeek(List<AssetTaggerService.AssetDesc> assets, Long taskId) throws Exception {
        StringBuilder sb = new StringBuilder();
        sb.append("你是装修短视频选材师。下面是一批工地实拍照片的素材描述（每张含 id 与画面要点）。");
        sb.append("\n请按\"是否值得做成抖音短视频动态镜头\"打分排序：画面信息量足、有可讲的施工卖点、清晰不重复的优先；");
        sb.append("画面空洞、模糊、信息量低或与其他图重复的排后，可剔除。");
        sb.append("\n只输出 JSON 数组，如 [9,2,4]，按出片价值从高到低列出你选中的 id，最多").append(topN).append("个，至少").append(min).append("个。禁止任何解释。\n\n");
        for (AssetTaggerService.AssetDesc a : assets) {
            String d = a.description() == null ? "" : a.description().replace('\n', ' ').trim();
            if (d.length() > 120) {
                d = d.substring(0, 120);
            }
            sb.append("- id=").append(a.assetId()).append("：").append(d).append("\n");
        }

        Map<String, Object> body = Map.of(
                "model", model,
                "messages", List.of(Map.of("role", "user", "content", sb.toString())),
                "temperature", 0.2);
        HttpRequest req = HttpRequest.newBuilder()
                .uri(URI.create(baseUrl + "/chat/completions"))
                .header("Authorization", "Bearer " + apiKey)
                .header("Content-Type", "application/json")
                .timeout(Duration.ofMillis(callTimeoutMs))
                .POST(HttpRequest.BodyPublishers.ofString(mapper.writeValueAsString(body)))
                .build();
        HttpResponse<String> resp = http.send(req, HttpResponse.BodyHandlers.ofString());
        if (resp.statusCode() != 200) {
            throw new IllegalStateException("DeepSeek 筛选 HTTP " + resp.statusCode() + ": " + truncate(resp.body(), 200));
        }
        JsonNode root = mapper.readTree(resp.body());
        String text = root.path("choices").path(0).path("message").path("content").asText("");
        // 从返回文本里抓所有数字 id（兼容数组/纯数字列表/带标题）
        List<Long> picked = new ArrayList<>();
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("\\d+").matcher(text);
        Set<Long> seen = new LinkedHashSet<>();
        while (m.find()) {
            try {
                long id = Long.parseLong(m.group());
                if (seen.add(id)) {
                    picked.add(id);
                }
            } catch (NumberFormatException ignored) {
            }
        }
        // 只保留确实存在的素材 id
        Set<Long> valid = new LinkedHashSet<>();
        for (AssetTaggerService.AssetDesc a : assets) {
            valid.add(a.assetId());
        }
        picked.removeIf(id -> !valid.contains(id));
        return picked;
    }

    private static List<Long> allIds(List<AssetTaggerService.AssetDesc> assets) {
        List<Long> ids = new ArrayList<>();
        if (assets != null) {
            for (AssetTaggerService.AssetDesc a : assets) {
                ids.add(a.assetId());
            }
        }
        return ids;
    }

    private static String truncate(String s, int n) {
        if (s == null) {
            return "";
        }
        return s.length() <= n ? s : s.substring(0, n);
    }
}

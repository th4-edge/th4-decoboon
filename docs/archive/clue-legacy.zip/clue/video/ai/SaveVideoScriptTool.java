package com.th4.edge.decoboon.clue.video.ai;

import com.th4.edge.framework.core.annotation.Note;
import io.agentscope.core.tool.Tool;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Agent 可调用的「保存视频文案」工具。
 * AgentScope @Tool 机制：方法级注解，Toolkit.registerTool(this) 注册后，
 * HarnessAgent 会把它暴露给 DeepSeek 模型调用（入参自动生成 JSON Schema）。
 */
@Note("Agent 文案落盘工具")
@Component
public class SaveVideoScriptTool {

    private static final Logger log = LoggerFactory.getLogger(SaveVideoScriptTool.class);

    @Tool(name = "save_video_script",
            description = "把生成好的抖音发布文案保存为草稿文件，返回保存路径。参数：content 文案正文, taskId 任务ID。")
    public String save(String content, String taskId) {
        try {
            Path dir = Path.of("data", "agent-drafts");
            Files.createDirectories(dir);
            Path file = dir.resolve("task-" + taskId + ".md");
            Files.writeString(file, content);
            log.info("[AgentTool] 文案已落盘: {}", file.toAbsolutePath());
            return file.toAbsolutePath().toString();
        } catch (Exception e) {
            log.warn("[AgentTool] 文案落盘失败", e);
            return "保存失败: " + e.getMessage();
        }
    }
}

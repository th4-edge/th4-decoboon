package com.th4.edge.decoboon.clue.video.configure;

import com.th4.edge.framework.core.Attribute;
import com.th4.edge.framework.core.annotation.Note;

@Note("发布渠道")
public enum PublishChannel implements Attribute<String> {

    Douyin("抖音"),
    Xiaohongshu("小红书"),
    Kuaishou("快手"),
    Channels("视频号");

    private final String name;

    PublishChannel(String name) {
        this.name = name;
    }

    @Override
    public String getValue() {
        return toString();
    }

    @Override
    public String getName() {
        return name;
    }
}

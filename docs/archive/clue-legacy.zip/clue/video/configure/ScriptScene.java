package com.th4.edge.decoboon.clue.video.configure;

import com.th4.edge.framework.core.Attribute;
import com.th4.edge.framework.core.annotation.Note;

/**
 * 话术库场景：按施工阶段/内容主题归类口播话术，用于生成前"查库命中"（省 LLM 费用）与差异化轮换。
 */
@Note("话术场景")
public enum ScriptScene implements Attribute<String> {

    WaterElectric("水电验收", "水电改造/线管/防水/封口/接头"),
    Tiling("瓦工贴砖", "贴砖/瓷砖/空鼓/找平/留缝"),
    Waterproof("防水闭水", "刷防水/闭水试验/墙面返潮"),
    Cabinet("全屋定制", "衣柜/橱柜/柜体/板材"),
    General("通用引流", "门店通用/品牌/活动");

    private final String name;
    private final String desc;

    ScriptScene(String name, String desc) {
        this.name = name;
        this.desc = desc;
    }

    @Override
    public String getValue() {
        return toString();
    }

    @Override
    public String getName() {
        return name;
    }

    @Note("描述")
    public String getDesc() {
        return desc;
    }
}

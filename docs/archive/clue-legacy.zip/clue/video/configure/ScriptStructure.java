package com.th4.edge.decoboon.clue.video.configure;

import com.th4.edge.framework.core.Attribute;
import com.th4.edge.framework.core.annotation.Note;

/**
 * 叙事结构池（P2b）：多套口播叙事骨架。生成时按业务员画像首选结构命中，无画像则随机抽取，
 * 保证"同素材也能换着法子讲"，从源头对抗 100 条一个味。
 */
@Note("叙事结构")
public enum ScriptStructure implements Attribute<String> {

    Suspense("悬念式", "先用一个反常识的钩子抛悬念吊胃口，中段逐条揭答案，结尾引导互动。开头钩子套路：\"为什么……？\"\"装修最怕……\"", "悬念钩子"),
    Contrast("对比式", "先抛\"值不值/该不该\"的矛盾冲突，再用画面细节说服，结尾给出判断标准。开头钩子套路：\"……到底值不值？\"", "对比判断"),
    ListCheck("清单式", "直接列 3 个必查点，逐个对着画面展开讲，结尾汇总并引导。开头钩子套路：\"这 3 处低头看仔细……\"", "清单点名"),
    Story("故事式", "用亲身经历或真事开头，讲踩坑过程引出经验，结尾教训+引导。开头钩子套路：\"说个真事/我当年……\"", "真实故事"),
    PainPoint("痛点式", "先戳一个具体的返工/增项/踩坑痛点，讲清后果，再给解决方案，结尾引导。开头钩子套路：\"入住后返工花3万……\"", "痛点戳心"),
    Authority("权威式", "以专业经验背书开头，分点讲干货，结尾给专业判断并引导。开头钩子套路：\"干了10年装修，我劝你看这几点……\"", "专业背书");

    private final String name;
    private final String desc;
    private final String hookTip;

    ScriptStructure(String name, String desc, String hookTip) {
        this.name = name;
        this.desc = desc;
        this.hookTip = hookTip;
    }

    @Override
    public String getValue() {
        return toString();
    }

    @Override
    public String getName() {
        return name;
    }

    @Note("骨架描述（注入生成提示词）")
    public String getDesc() {
        return desc;
    }

    @Note("开头钩子套路")
    public String getHookTip() {
        return hookTip;
    }
}

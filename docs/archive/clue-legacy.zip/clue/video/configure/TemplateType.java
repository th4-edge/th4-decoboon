package com.th4.edge.decoboon.clue.video.configure;

import com.th4.edge.framework.core.Attribute;
import com.th4.edge.framework.core.annotation.Note;

@Note("模板类型")
public enum TemplateType implements Attribute<String> {

    SiteShoot("工地实拍", "适合发施工进度"),
    AvoidPit("避坑干货", "适合讲专业知识"),
    Price("价格透明", "适合报价类内容"),
    FinishedCase("完工案例", "适合晒成果"),
    CustomerProof("客户证言", "适合转介绍");

    private final String name;
    private final String desc;

    TemplateType(String name, String desc) {
        this.name = name;
        this.desc = desc;
    }

    @Override
    public String getValue() {
        return toString();
    }

    @Override
    public String getName() {
        return name;
    }

    @Note("描述")
    public String getDesc() {
        return desc;
    }
}

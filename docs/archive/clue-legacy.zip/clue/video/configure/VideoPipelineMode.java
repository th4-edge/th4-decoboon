package com.th4.edge.decoboon.clue.video.configure;

import com.th4.edge.framework.core.Attribute;
import com.th4.edge.framework.core.annotation.Note;

/**
 * 视频流水线模式：区分 AI 出片与确定性图片混剪两条流水线。
 * <p>
 * 以 detail JSON 中的 {@code "mode"} 标记落库（不新增数据库列，避免表结构变更），
 * {@code VideoRenderScheduler} 只认领 {@code Montage} 任务，AI 流水线继续由
 * {@code VideoPipelineService} 驱动。
 */
@Note("视频流水线模式")
public enum VideoPipelineMode implements Attribute<String> {

    Ai("AI 出片"),
    Montage("图片混剪");

    private final String name;

    VideoPipelineMode(String name) {
        this.name = name;
    }

    @Override
    public String getValue() {
        return toString();
    }

    @Override
    public String getName() {
        return name;
    }
}

package com.th4.edge.decoboon.clue.video.configure;

import com.th4.edge.framework.core.Attribute;
import com.th4.edge.framework.core.annotation.Note;

@Note("视频状态")
public enum VideoState implements Attribute<String> {

    Draft("草稿"),
    Generating("生成中"),
    Published("已发布");

    private final String name;

    VideoState(String name) {
        this.name = name;
    }

    @Override
    public String getValue() {
        return toString();
    }

    @Override
    public String getName() {
        return name;
    }
}

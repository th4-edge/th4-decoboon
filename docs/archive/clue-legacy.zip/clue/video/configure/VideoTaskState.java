package com.th4.edge.decoboon.clue.video.configure;

import com.th4.edge.framework.core.Attribute;
import com.th4.edge.framework.core.annotation.Note;

@Note("生成任务状态")
public enum VideoTaskState implements Attribute<String> {

    Created("已创建"),
    Writing("AI写文案"),
    Dubbing("AI配音"),
    Subtitling("生成字幕"),
    Rendering("合成视频"),
    EndCaring("生成尾卡"),
    Done("完成"),
    Failed("失败");

    private final String name;

    VideoTaskState(String name) {
        this.name = name;
    }

    @Override
    public String getValue() {
        return toString();
    }

    @Override
    public String getName() {
        return name;
    }
}

package com.th4.edge.decoboon.clue.video.media;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.th4.edge.framework.core.annotation.Note;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.time.Instant;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * 阿里云智能语音交互（NLS）语音合成 TTS。
 * <p>
 * 鉴权：appkey（管控台项目）+ token（阿里云 POP CreateToken 用 AccessKeyId+Secret 换得，HMAC-SHA1 签名，纯 JDK 实现，无额外 SDK 依赖）。
 * 合成：POST nls-gateway-{region}.aliyuncs.com/stream/v1/tts，JSON body，返回 audio/wav 二进制。
 * 文本超长（>250 字）自动分块逐条合成再 ffmpeg 拼接，避免 NLS 单次 300 字上限。
 */
@Note("阿里云 NLS 语音合成")
@Component
public class AliyunNlsTts implements TtsService {

    private static final Logger log = LoggerFactory.getLogger(AliyunNlsTts.class);
    private static final int MAX_TEXT_PER_REQUEST = 250;
    private static final DateTimeFormatter UTC_FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss'Z'")
            .withZone(java.time.ZoneOffset.UTC);

    private final ObjectMapper objectMapper = new ObjectMapper();
    private final HttpClient httpClient = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(10)).build();

    private final String appkey;
    private final String accessKeyId;
    private final String accessKeySecret;
    private final String presetToken;
    private final String voice;
    private final int sampleRate;
    private final String region;

    private volatile String cachedToken;
    private volatile long tokenExpireAt;

    public AliyunNlsTts(
            @Value("${th4.edge.decoboon.video.tts.aliyun.appkey:}") String appkey,
            @Value("${th4.edge.decoboon.video.tts.aliyun.access-key-id:}") String accessKeyId,
            @Value("${th4.edge.decoboon.video.tts.aliyun.access-key-secret:}") String accessKeySecret,
            @Value("${th4.edge.decoboon.video.tts.aliyun.token:}") String presetToken,
            @Value("${th4.edge.decoboon.video.tts.aliyun.voice:aixia}") String voice,
            @Value("${th4.edge.decoboon.video.tts.aliyun.sample-rate:16000}") int sampleRate,
            @Value("${th4.edge.decoboon.video.tts.aliyun.region:cn-shanghai}") String region) {
        this.appkey = appkey;
        this.accessKeyId = accessKeyId;
        this.accessKeySecret = accessKeySecret;
        this.presetToken = presetToken;
        this.voice = voice;
        this.sampleRate = sampleRate;
        this.region = region;
    }

    @Override
    public TtsResult generate(String text, Long taskId) {
        try {
            Path dir = Path.of("data", "media", "task-" + taskId);
            Files.createDirectories(dir);
            Path voiceMp3 = dir.resolve("voice.mp3");

            List<Path> wavs = new ArrayList<>();
            for (String chunk : chunkText(text)) {
                Path wav = synthesize(chunk, taskId);
                wavs.add(wav);
            }

            // 合并多段 wav（各段均为 NLS 同参 wav，用 concat demuxer 拼接，避免带头 wav 按字节拼接出错）并转 mp3
            Path mergedWav;
            if (wavs.size() == 1) {
                mergedWav = wavs.get(0);
            } else {
                mergedWav = dir.resolve("merged.wav");
                Path listFile = dir.resolve("concat.txt");
                String listContent = wavs.stream()
                        .map(p -> "file '" + p.toAbsolutePath().toString().replace("'", "'\\''") + "'")
                        .collect(java.util.stream.Collectors.joining("\n"));
                Files.writeString(listFile, listContent, StandardCharsets.UTF_8);
                run(List.of("ffmpeg", "-y", "-loglevel", "error", "-f", "concat", "-safe", "0",
                        "-i", listFile.toAbsolutePath().toString(),
                        "-ar", "44100", "-ac", "1",
                        "-y", mergedWav.toAbsolutePath().toString()), 120);
            }
            run(List.of("ffmpeg", "-y", "-loglevel", "error",
                    "-i", mergedWav.toAbsolutePath().toString(),
                    "-ar", "44100", "-ac", "1", "-b:a", "128k",
                    "-y", voiceMp3.toAbsolutePath().toString()), 120);

            double duration = MediaProbe.durationSec(voiceMp3.toAbsolutePath().toString());
            log.info("[TTS-ALIYUN] 任务{} 阿里云合成完成 voice={} 时长={}s -> {}", taskId, voice,
                    String.format("%.2f", duration), voiceMp3);
            return new TtsResult(voiceMp3.toAbsolutePath().toString(), duration);
        } catch (Exception e) {
            throw new IllegalStateException("阿里云 TTS 合成失败: " + e.getMessage(), e);
        }
    }

    /** 单次合成一段文本为 wav（NLS RESTful /stream/v1/tts） */
    private Path synthesize(String text, Long taskId) throws Exception {
        String token = resolveToken();
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("appkey", appkey);
        body.put("text", text);
        body.put("token", token);
        body.put("format", "wav");
        body.put("sample_rate", sampleRate);
        body.put("voice", voice);
        body.put("volume", 50);
        body.put("speech_rate", 0);
        body.put("pitch_rate", 0);

        HttpRequest req = HttpRequest.newBuilder(URI.create(
                        "https://nls-gateway-" + region + ".aliyuncs.com/stream/v1/tts"))
                .timeout(Duration.ofSeconds(60))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(objectMapper.writeValueAsString(body),
                        StandardCharsets.UTF_8))
                .build();
        HttpResponse<byte[]> resp = httpClient.send(req, HttpResponse.BodyHandlers.ofByteArray());
        String contentType = resp.headers().firstValue("Content-Type").orElse("");
        if (!contentType.startsWith("audio/")) {
            throw new IllegalStateException("NLS 合成失败(" + resp.statusCode() + "): "
                    + new String(resp.body(), StandardCharsets.UTF_8));
        }
        Path wav = Path.of("data", "media", "task-" + taskId, "voice-" + UUID.randomUUID().toString().substring(0, 8) + ".wav");
        Files.write(wav, resp.body());
        return wav;
    }

    /** 取 token：优先配置的临时 token，否则用 AccessKey 换（缓存至过期前 10 分钟） */
    private String resolveToken() throws Exception {
        if (StringUtils.hasText(presetToken)) {
            return presetToken;
        }
        if (!StringUtils.hasText(accessKeyId) || !StringUtils.hasText(accessKeySecret)) {
            throw new IllegalStateException("未配置阿里云 AccessKey Secret（或临时 token），无法完成鉴权");
        }
        if (cachedToken != null && System.currentTimeMillis() < tokenExpireAt - 600_000) {
            return cachedToken;
        }
        String token = fetchToken();
        cachedToken = token;
        return token;
    }

    /** 阿里云 POP CreateToken（HMAC-SHA1 签名，纯 JDK） */
    private String fetchToken() throws Exception {
        Map<String, String> params = new LinkedHashMap<>();
        params.put("AccessKeyId", accessKeyId);
        params.put("Action", "CreateToken");
        params.put("Format", "JSON");
        params.put("RegionId", region);
        params.put("SignatureMethod", "HMAC-SHA1");
        params.put("SignatureNonce", UUID.randomUUID().toString());
        params.put("SignatureVersion", "1.0");
        params.put("Timestamp", UTC_FMT.format(Instant.now()));
        params.put("Version", "2019-02-28");

        String canonical = params.entrySet().stream().sorted(Map.Entry.comparingByKey())
                .map(e -> pct(e.getKey()) + "=" + pct(e.getValue()))
                .reduce((a, b) -> a + "&" + b).orElse("");
        String stringToSign = "GET&" + pct("/") + "&" + pct(canonical);
        String signature = pct(signHmacSha1(stringToSign, accessKeySecret + "&"));

        String url = "https://nls-meta." + region + ".aliyuncs.com/?Signature=" + signature + "&" + canonical;
        HttpRequest req = HttpRequest.newBuilder(URI.create(url))
                .timeout(Duration.ofSeconds(20))
                .GET().build();
        HttpResponse<String> resp = httpClient.send(req, HttpResponse.BodyHandlers.ofString());
        JsonNode root = objectMapper.readTree(resp.body());
        if (root.has("Token") && root.get("Token").has("Id")) {
            long expire = root.get("Token").get("ExpireTime").asLong() * 1000L;
            tokenExpireAt = expire;
            String token = root.get("Token").get("Id").asText();
            log.info("[TTS-ALIYUN] token 获取成功，有效期至 {}", Instant.ofEpochMilli(expire));
            return token;
        }
        throw new IllegalStateException("CreateToken 失败(" + resp.statusCode() + "): " + resp.body());
    }

    private String signHmacSha1(String data, String key) throws Exception {
        Mac mac = Mac.getInstance("HmacSHA1");
        mac.init(new SecretKeySpec(key.getBytes(StandardCharsets.UTF_8), "HmacSHA1"));
        return Base64.getEncoder().encodeToString(mac.doFinal(data.getBytes(StandardCharsets.UTF_8)));
    }

    private String pct(String v) {
        try {
            return URLEncoder.encode(v, StandardCharsets.UTF_8)
                    .replace("+", "%20").replace("*", "%2A").replace("%7E", "~");
        } catch (Exception e) {
            return v;
        }
    }

    /** 按句切分为 ≤MAX_TEXT_PER_REQUEST 的分段（NLS 单次 300 字上限） */
    private List<String> chunkText(String text) {
        List<String> chunks = new ArrayList<>();
        StringBuilder buf = new StringBuilder();
        for (String seg : text.split("(?<=[。！？；])")) {
            if (seg.isBlank()) {
                continue;
            }
            if (buf.length() + seg.length() > MAX_TEXT_PER_REQUEST && buf.length() > 0) {
                chunks.add(buf.toString());
                buf.setLength(0);
            }
            buf.append(seg);
        }
        if (buf.length() > 0) {
            chunks.add(buf.toString());
        }
        if (chunks.isEmpty()) {
            chunks.add("装修不踩坑");
        }
        return chunks;
    }

    private void run(List<String> cmd, int timeoutSec) throws Exception {
        ProcessBuilder pb = new ProcessBuilder(cmd);
        pb.redirectErrorStream(true);
        Process p = pb.start();
        String out = new String(p.getInputStream().readAllBytes());
        boolean ok = p.waitFor(timeoutSec, java.util.concurrent.TimeUnit.SECONDS);
        if (!ok) {
            p.destroyForcibly();
            throw new IllegalStateException("命令超时: " + String.join(" ", cmd));
        }
        if (p.exitValue() != 0) {
            throw new IllegalStateException("命令失败(" + p.exitValue() + "): " + String.join(" ", cmd) + "\n" + out);
        }
    }
}

package com.th4.edge.decoboon.clue.video.media;

import com.th4.edge.framework.core.annotation.Note;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * L2 素材增强：让进入合片的素材图更"精"。
 * <p>
 * 1. 竖版画布统一：所有素材统一到 1080x1920（9:16）输出；
 *    - 原图接近 9:16 → cover 居中裁满；
 *    - 其他比例（如 3:4 横图/方图）→ 模糊背景补边：背景 = 原图铺满画布 + 高斯模糊 + 压暗，前景 = 原图完整缩放居中，主体不丢内容；
 * 2. 调色（工地实拍风格预设）：对比度/饱和度/亮度微调 + 暖色偏移 + 轻暗角；
 * 3. 锐化增强：unsharp 轻锐，弥补小图放大的发糊；
 * 4. 超分扩展点：`video.l2.super-resolution.provider=realesrgan` 且 binary 存在时，先外部 CLI 超分再竖版化（失败自动降级）。
 * <p>
 * 幂等：增强结果写 {@code data/media/task-{taskId}/enhanced/}，同名存在即跳过。
 */
@Note("L2素材增强")
@Component
public class AssetEnhancerService {

    private static final Logger log = LoggerFactory.getLogger(AssetEnhancerService.class);

    private final boolean l2Enabled;
    private final int canvasW;
    private final int canvasH;
    private final double contrast;
    private final double saturation;
    private final double brightness;
    private final double warm;
    private final double sharpen;
    private final boolean vignette;
    private final String srProvider;
    private final String srBinary;
    private final int srScale;

    public AssetEnhancerService(
            @Value("${th4.edge.decoboon.video.l2.enabled:true}") boolean l2Enabled,
            @Value("${th4.edge.decoboon.video.l2.canvas-width:1080}") int canvasW,
            @Value("${th4.edge.decoboon.video.l2.canvas-height:1920}") int canvasH,
            @Value("${th4.edge.decoboon.video.l2.contrast:1.10}") double contrast,
            @Value("${th4.edge.decoboon.video.l2.saturation:1.18}") double saturation,
            @Value("${th4.edge.decoboon.video.l2.brightness:0.02}") double brightness,
            @Value("${th4.edge.decoboon.video.l2.warm:0.02}") double warm,
            @Value("${th4.edge.decoboon.video.l2.sharpen:0.40}") double sharpen,
            @Value("${th4.edge.decoboon.video.l2.vignette:true}") boolean vignette,
            @Value("${th4.edge.decoboon.video.l2.super-resolution.provider:none}") String srProvider,
            @Value("${th4.edge.decoboon.video.l2.super-resolution.binary:}") String srBinary,
            @Value("${th4.edge.decoboon.video.l2.super-resolution.scale:2}") int srScale) {
        this.l2Enabled = l2Enabled;
        this.canvasW = canvasW;
        this.canvasH = canvasH;
        this.contrast = contrast;
        this.saturation = saturation;
        this.brightness = brightness;
        this.warm = warm;
        this.sharpen = sharpen;
        this.vignette = vignette;
        this.srProvider = srProvider;
        this.srBinary = srBinary;
        this.srScale = Math.max(srScale, 2);
    }

    public boolean isEnabled() {
        return l2Enabled;
    }

    /** 增强一批素材图，返回增强后路径列表（顺序与入参一致） */
    public List<String> enhance(List<String> images, Long taskId) {
        List<String> out = new ArrayList<>();
        try {
            Path dir = Path.of("data", "media", "task-" + taskId, "enhanced");
            Files.createDirectories(dir);
            for (String img : images) {
                try {
                    out.add(enhanceOne(img, taskId, dir));
                } catch (Exception e) {
                    log.warn("[L2] 素材增强失败，回退原图 {}: {}", img, e.getMessage());
                    out.add(img);
                }
            }
            log.info("[L2] 任务{} 素材增强 {} 张 -> {}", taskId, out.size(), dir);
        } catch (Exception e) {
            log.warn("[L2] 增强目录创建失败，全部回退原图: {}", e.getMessage());
            return images;
        }
        return out;
    }

    private String enhanceOne(String img, Long taskId, Path dir) throws Exception {
        Path in = Path.of(img);
        String name = in.getFileName().toString();
        String base = name.replaceFirst("(?i)\\.(jpg|jpeg|png)$", "");
        Path out = dir.resolve(base + ".jpg");
        if (Files.exists(out)) {
            return out.toAbsolutePath().toString();
        }

        // 超分扩展点：外部 CLI 先 2x（realesrgan-ncnn-vulkan）
        Path src = in;
        if (isSrEnabled()) {
            Path sr = dir.resolve(base + "_sr" + srScale + "x.png");
            try {
                if (runSr(in, sr) && Files.exists(sr) && Files.size(sr) > 0) {
                    src = sr;
                    log.info("[L2] {} 超分 {}{} 完成", name, srScale, "x");
                }
            } catch (Exception e) {
                log.warn("[L2] {} 超分失败，降级直接增强: {}", name, e.getMessage());
            }
        }

        // 探测原图比例
        BufferedImage bi = ImageIO.read(src.toFile());
        double aspect = (bi != null && bi.getHeight() > 0) ? (double) bi.getWidth() / bi.getHeight() : 0.5625;
        double target = (double) canvasW / canvasH;

        StringBuilder vf;
        if (Math.abs(aspect - target) < 0.04) {
            // 接近 9:16 → cover 裁满
            vf = new StringBuilder("scale=").append(canvasW).append(":").append(canvasH)
                    .append(":force_original_aspect_ratio=increase,crop=").append(canvasW).append(":").append(canvasH)
                    .append(",setsar=1");
        } else {
            // 模糊背景补边 + 主体全显
            String fgScale;
            if (aspect >= target) {
                fgScale = "scale=" + canvasW + ":-1";              // 较宽图：宽铺满，垂直居中
            } else {
                fgScale = "scale=-1:" + canvasH;                   // 较高图：高铺满，水平居中
            }
            vf = new StringBuilder("[0:v]split=2[bg][fg];")
                    .append("[bg]scale=").append(canvasW).append(":").append(canvasH)
                    .append(":force_original_aspect_ratio=increase,crop=").append(canvasW).append(":").append(canvasH)
                    .append(",gblur=sigma=25,eq=brightness=-0.15:saturation=1.1[bgbg];")
                    .append("[fg]").append(fgScale).append("[fg1];")
                    .append("[bgbg][fg1]overlay=x=(main_w-overlay_w)/2:y=(main_h-overlay_h)/2, setsar=1");
        }
        vf.append(gradeFilter());

        List<String> cmd = new ArrayList<>(List.of("ffmpeg", "-y", "-loglevel", "error", "-i", src.toAbsolutePath().toString()));
        if (vf.toString().contains("split")) {
            cmd.addAll(List.of("-filter_complex", vf.toString() + "[vout]", "-map", "[vout]"));
        } else {
            cmd.addAll(List.of("-vf", vf.toString()));
        }
        cmd.addAll(List.of("-q:v", "2", "-y", out.toAbsolutePath().toString()));
        run(cmd, 60);
        return out.toAbsolutePath().toString();
    }

    /** 工地实拍风格调色 + 锐化 + 轻暗角（追加到滤镜链尾） */
    private String gradeFilter() {
        StringBuilder g = new StringBuilder(",eq=contrast=")
                .append(contrast).append(":saturation=").append(saturation)
                .append(":brightness=").append(brightness);
        if (warm > 0) {
            g.append(",colorbalance=rs=").append(warm).append(":bs=").append(-warm);
        }
        if (sharpen > 0) {
            g.append(",unsharp=5:5:").append(sharpen);
        }
        if (vignette) {
            g.append(",vignette=PI/6");
        }
        return g.toString();
    }

    private boolean isSrEnabled() {
        return "realesrgan".equalsIgnoreCase(srProvider)
                && StringUtils.hasText(srBinary)
                && Files.exists(Path.of(srBinary));
    }

    private boolean runSr(Path in, Path out) throws Exception {
        List<String> cmd = List.of(srBinary, "-i", in.toAbsolutePath().toString(),
                "-o", out.toAbsolutePath().toString(), "-s", String.valueOf(srScale),
                "-n", "realesrgan-x4plus");
        run(cmd, 120);
        return true;
    }

    private void run(List<String> cmd, int timeoutSec) throws Exception {
        ProcessBuilder pb = new ProcessBuilder(cmd);
        pb.redirectErrorStream(false);
        Process p = pb.start();
        byte[] err = p.getErrorStream().readAllBytes();
        if (!p.waitFor(timeoutSec, TimeUnit.SECONDS)) {
            p.destroyForcibly();
            throw new IllegalStateException("命令超时: " + cmd.get(0));
        }
        if (p.exitValue() != 0) {
            throw new IllegalStateException("命令失败(" + p.exitValue() + "): " + new String(err, java.nio.charset.StandardCharsets.UTF_8));
        }
    }
}

package com.th4.edge.decoboon.clue.video.media;

import com.th4.edge.decoboon.clue.asset.configure.AssetType;
import com.th4.edge.decoboon.clue.asset.model.Asset;
import com.th4.edge.decoboon.clue.asset.repository.AssetRepository;
import com.th4.edge.framework.core.annotation.Note;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import javax.imageio.ImageIO;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/**
 * 素材解析：把任务引用的 assetIds 解析成本地图片文件路径供 FFmpeg 合片。
 * <p>
 * 素材行 url 为本地路径时直接复用；素材缺失/为空时生成 3 张占位工地图，
 * 保证出片流水线不因素材问题阻断。
 */
@Note("素材解析")
@Component
public class AssetImageResolver {

    private static final Logger log = LoggerFactory.getLogger(AssetImageResolver.class);

    private final AssetRepository assetRepository;

    public AssetImageResolver(AssetRepository assetRepository) {
        this.assetRepository = assetRepository;
    }

    public List<String> resolveImages(String assetIds, Long taskId) {
        List<String> images = new ArrayList<>();
        if (StringUtils.hasText(assetIds)) {
            // assetIds 可能为 "1,2,3" 或 JSON 数组 "[1, 2, 3]" 等格式，统一正则提取数字 ID
            java.util.regex.Matcher m = java.util.regex.Pattern.compile("\\d+").matcher(assetIds);
            while (m.find()) {
                Asset asset = assetRepository.findByAssetId(Long.parseLong(m.group()));
                if (asset == null || asset.getType() != AssetType.Image) {
                    continue;
                }
                Path f = Path.of(asset.getUrl());
                if (Files.exists(f)) {
                    images.add(f.toAbsolutePath().toString());
                }
            }
        }
        if (images.isEmpty()) {
            images = generatePlaceholders(taskId);
        }
        log.info("[AssetImage] 任务{} 素材图片 {} 张", taskId, images.size());
        return images;
    }

    /** 无素材时生成 3 张占位工地图（竖版 720x1280 JPG） */
    private List<String> generatePlaceholders(Long taskId) {
        List<String> out = new ArrayList<>();
        Color[] colors = {new Color(0x2b, 0x4c, 0x7e), new Color(0x4a, 0x6f, 0x4f), new Color(0x6f, 0x4a, 0x3a)};
        String[] labels = {"工地实拍 1", "工地实拍 2", "工地实拍 3"};
        try {
            Path dir = Path.of("data", "media", "task-" + taskId, "slots");
            Files.createDirectories(dir);
            for (int i = 0; i < labels.length; i++) {
                Path p = dir.resolve("slot-" + (i + 1) + ".jpg");
                BufferedImage img = new BufferedImage(720, 1280, BufferedImage.TYPE_INT_RGB);
                Graphics2D g = img.createGraphics();
                try {
                    g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
                    g.setColor(colors[i]);
                    g.fillRect(0, 0, 720, 1280);
                    g.setFont(new Font("PingFang SC", Font.BOLD, 72));
                    g.setColor(Color.WHITE);
                    FontMetrics fm = g.getFontMetrics();
                    g.drawString(labels[i], (720 - fm.stringWidth(labels[i])) / 2, 640);
                } finally {
                    g.dispose();
                }
                ImageIO.write(img, "jpg", p.toFile());
                out.add(p.toAbsolutePath().toString());
            }
        } catch (Exception e) {
            log.warn("[AssetImage] 占位图生成失败: {}", e.getMessage());
        }
        return out;
    }
}

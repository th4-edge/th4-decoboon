package com.th4.edge.decoboon.clue.video.media;

import com.th4.edge.decoboon.clue.asset.configure.AssetType;
import com.th4.edge.decoboon.clue.asset.model.Asset;
import com.th4.edge.decoboon.clue.asset.repository.AssetRepository;
import com.th4.edge.framework.core.annotation.Note;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/**
 * L2.5 素材语义化：用视觉模型（qwen-vl）为每张素材生成"画面内容 + 可讲卖点"描述，
 * 写回 {@code Asset.description} 供文案生成复用（A1 识别 + A2 入库）。
 * <p>
 * - 幂等：description 已非空即复用（可 force 重识别），避免重复消耗视觉额度；
 * - 降级：未配视觉 Key / 识别失败 → 用文件名/备注兜底，文案生成不阻断。
 */
@Note("素材语义化")
@Component
public class AssetTaggerService {

    private static final Logger log = LoggerFactory.getLogger(AssetTaggerService.class);
    private static final Pattern IDS = Pattern.compile("\\d+");

    private final AssetRepository assetRepository;
    private final DashScopeVisionService visionService;

    public AssetTaggerService(AssetRepository assetRepository, DashScopeVisionService visionService) {
        this.assetRepository = assetRepository;
        this.visionService = visionService;
    }

    /** 素材语义描述记录 */
    public record AssetDesc(Long assetId, String name, String description, String tagline) {
    }

    /**
     * 为任务引用的素材生成语义描述清单（按 assetIds 顺序）。
     *
     * @param assetIds 逗号或 JSON 数组形式的素材 ID 字符串
     * @param taskId   任务号（日志）
     * @param force    是否强制重新识别（忽略已入库描述）
     */
    public List<AssetDesc> describeAssets(String assetIds, Long taskId, boolean force) {
        List<AssetDesc> out = new ArrayList<>();
        java.util.regex.Matcher m = IDS.matcher(assetIds == null ? "" : assetIds);
        while (m.find()) {
            try {
                Long id = Long.parseLong(m.group());
                Asset asset = assetRepository.findByAssetId(id);
                if (asset == null || asset.getType() != AssetType.Image) {
                    continue;
                }
                String desc = asset.getDescription();
                String tagline = null;
                if (!force && StringUtils.hasText(desc)) {
                    tagline = parseTagline(desc);
                    out.add(new AssetDesc(id, asset.getRemark(), desc, tagline));
                    continue;
                }
                String fresh = null;
                if (StringUtils.hasText(asset.getUrl())) {
                    fresh = visionService.describeImage(asset.getUrl(), taskId);
                }
                if (StringUtils.hasText(fresh)) {
                    asset.setDescription(fresh);
                    assetRepository.save(asset);
                    desc = fresh;
                    tagline = parseTagline(fresh);
                } else {
                    // 降级：文件名 / 备注
                    desc = StringUtils.hasText(asset.getRemark())
                            ? "画面见素材（拍摄备注：" + asset.getRemark() + "）"
                            : "装修工地实拍素材";
                    tagline = null;
                }
                out.add(new AssetDesc(id, asset.getRemark(), desc, tagline));
            } catch (Exception e) {
                log.warn("[AssetTagger] 任务{} 素材语义化异常: {}", taskId, e.getMessage());
            }
        }
        log.info("[AssetTagger] 任务{} 素材语义化 {} 条 (视觉识别={})", taskId, out.size(), visionService.isEnabled());
        return out;
    }

    /** 从视觉识别文本中解析"花字：xxx"（≤8字分镜标题），找不到返回 null */
    private String parseTagline(String desc) {
        if (!StringUtils.hasText(desc)) {
            return null;
        }
        int i = desc.indexOf("花字：");
        if (i < 0) {
            i = desc.indexOf("花字:");
        }
        if (i < 0) {
            return null;
        }
        String rest = desc.substring(i + 3).trim();
        int nl = rest.indexOf('\n');
        String t = (nl >= 0 ? rest.substring(0, nl) : rest).trim();
        t = t.replaceAll("[。．.!！]+$", "").trim();
        t = t.replaceAll("[\"“”‘’「」『』「」]+", "").trim();
        if (t.length() > 8) {
            t = t.substring(0, 8);
        }
        return StringUtils.hasText(t) ? t : null;
    }
}

package com.th4.edge.decoboon.clue.video.media;

import com.th4.edge.framework.core.annotation.Note;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * BGM 节拍检测：用 ffmpeg 解码为 16k 单声道 PCM，按短时能量（RMS）包络做 onset 检测，
 * 返回节拍时间点（秒）。用于把图片切换"卡点"对齐到 BGM 拍子。
 * <p>
 * 纯确定性实现（无第三方音频库），对清晰鼓点 BGM 效果良好。
 */
@Note("BGM 节拍检测")
public final class BeatDetector {

    private static final Logger log = LoggerFactory.getLogger(BeatDetector.class);
    private static final int SAMPLE_RATE = 16000;
    private static final int WINDOW_MS = 40;          // 能量窗 40ms
    private static final double MIN_GAP_SEC = 0.28;   // 最小节拍间隔
    private static final double THRESHOLD_MULT = 1.7; // 能量阈值倍数
    private static final int LOCAL_RANGE = 2;         // 局部极大值窗口（±2 窗）

    private BeatDetector() {
    }

    /**
     * 检测音频节拍点。
     *
     * @param audioPath 音频文件（mp3/m4a/wav 均可）
     * @param maxDurSec 只看前 maxDurSec 秒（一般传配音时长）
     * @return 节拍时间点列表（秒，升序）
     */
    public static List<Double> detectBeats(String audioPath, double maxDurSec) {
        try {
            short[] samples = decodePcm(audioPath);
            if (samples.length < SAMPLE_RATE) {
                return new ArrayList<>();
            }
            int win = SAMPLE_RATE * WINDOW_MS / 1000;   // 640
            int winCount = samples.length / win;
            double[] energy = new double[winCount];
            for (int i = 0; i < winCount; i++) {
                long sum = 0;
                for (int j = 0; j < win; j++) {
                    int s = samples[i * win + j];
                    sum += (long) s * s;
                }
                energy[i] = Math.sqrt((double) sum / win);
            }
            // 平滑（3 窗滑动平均）
            double[] smooth = new double[winCount];
            for (int i = 0; i < winCount; i++) {
                double acc = 0;
                int cnt = 0;
                for (int k = Math.max(0, i - 1); k <= Math.min(winCount - 1, i + 1); k++) {
                    acc += energy[k];
                    cnt++;
                }
                smooth[i] = acc / cnt;
            }
            double mean = 0;
            for (double v : smooth) {
                mean += v;
            }
            mean = mean / winCount;
            double threshold = Math.max(mean * THRESHOLD_MULT, 200);

            int maxWin = (int) (maxDurSec * 1000 / WINDOW_MS);
            maxWin = Math.min(maxWin, winCount);

            List<Double> beats = new ArrayList<>();
            double lastBeat = -MIN_GAP_SEC;
            for (int i = 1; i < maxWin - 1; i++) {
                if (smooth[i] < threshold) {
                    continue;
                }
                // 局部极大值
                if (smooth[i] >= smooth[i - 1] && smooth[i] >= smooth[i + 1]
                        && smooth[i] >= smooth[i - LOCAL_RANGE] && smooth[i] >= smooth[i + LOCAL_RANGE]) {
                    double t = i * WINDOW_MS / 1000.0;
                    if (t - lastBeat >= MIN_GAP_SEC) {
                        beats.add(t);
                        lastBeat = t;
                    }
                }
            }
            log.info("[Beat] 检测到 {} 个节拍点 (首拍={}s 末拍={}s)", beats.size(),
                    beats.isEmpty() ? "-" : String.format("%.2f", beats.get(0)),
                    beats.isEmpty() ? "-" : String.format("%.2f", beats.get(beats.size() - 1)));
            return beats;
        } catch (Exception e) {
            log.warn("[Beat] 节拍检测失败，跳过卡点: {}", e.getMessage());
            return new ArrayList<>();
        }
    }

    private static short[] decodePcm(String audioPath) throws Exception {
        ProcessBuilder pb = new ProcessBuilder("ffmpeg", "-v", "error",
                "-i", audioPath, "-ac", "1", "-ar", String.valueOf(SAMPLE_RATE),
                "-f", "s16le", "pipe:1");
        pb.redirectErrorStream(false);
        Process p = pb.start();
        InputStream in = p.getInputStream();
        byte[] buf = in.readAllBytes();
        p.waitFor();
        short[] out = new short[buf.length / 2];
        for (int i = 0; i < out.length; i++) {
            out[i] = (short) ((buf[i * 2] & 0xff) | (buf[i * 2 + 1] << 8));
        }
        return out;
    }
}

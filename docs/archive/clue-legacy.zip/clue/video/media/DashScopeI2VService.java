package com.th4.edge.decoboon.clue.video.media;

import com.th4.edge.framework.core.annotation.Note;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.Duration;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * L3 AI 视频融合：调阿里云百炼通义万相图生视频（wan2.6-i2v-flash）为每张素材图
 * 生成一段实拍动态短片（异步任务：提交 -> 轮询 -> 下载）。
 * - 图片经 ffmpeg 缩至 720 宽后 base64 data URL 直传（wan2.6 检查器不接受 file://）
 * - 产物落 task-{id}/i2v/seg-{idx}.mp4，已存在即跳过（幂等，支持断点续跑）
 * - Key 缺失 / 提交或轮询失败 -> isEnabled=false / 抛异常，由上层降级回 zoompan 运镜
 */
@Note("L3 图生视频")
@Component
public class DashScopeI2VService {

    private static final Logger log = LoggerFactory.getLogger(DashScopeI2VService.class);
    private static final ObjectMapper MAPPER = new ObjectMapper();
    /** 按图缓存根目录：同图同 prompt 的 I2V 段跨任务复用（业务中同素材会被多次使用） */
    private static final Path CACHE_DIR = Path.of("data", "media", "i2v-cache");

    private final boolean enabled;
    private final String apiKey;
    private final String model;
    private final String resolution;
    private final int duration;
    private final String motion;
    private final long pollIntervalMs;
    private final long pollTimeoutMs;
    private final HttpClient http;

    public DashScopeI2VService(
            @Value("${th4.edge.decoboon.video.l3.enabled:false}") boolean enabled,
            @Value("${th4.edge.decoboon.video.l3.api-key:}") String l3ApiKey,
            @Value("${th4.edge.decoboon.ai.vision.api-key:}") String visionApiKey,
            @Value("${th4.edge.decoboon.video.l3.model:wan2.6-i2v-flash}") String model,
            @Value("${th4.edge.decoboon.video.l3.resolution:720P}") String resolution,
            @Value("${th4.edge.decoboon.video.l3.duration:5}") int duration,
            @Value("${th4.edge.decoboon.video.l3.motion:subtle}") String motion,
            @Value("${th4.edge.decoboon.video.l3.poll-interval-ms:5000}") long pollIntervalMs,
            @Value("${th4.edge.decoboon.video.l3.poll-timeout-ms:600000}") long pollTimeoutMs) {
        this.enabled = enabled;
        this.apiKey = StringUtils.hasText(l3ApiKey) ? l3ApiKey : visionApiKey;
        this.model = model;
        this.resolution = resolution;
        this.duration = duration;
        this.motion = StringUtils.hasText(motion) ? motion : "subtle";
        this.pollIntervalMs = pollIntervalMs;
        this.pollTimeoutMs = pollTimeoutMs;
        this.http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(15)).build();
    }

    public boolean isEnabled() {
        return enabled && StringUtils.hasText(apiKey);
    }

    /** 为第 idx 张素材图生成一段 I2V 短片。三级复用：任务内段 -> 按图缓存 -> 调 API（生成后入缓存） */
    public Path generateSegVideo(String imagePath, String prompt, Long taskId, int idx) throws Exception {
        Path out = Path.of("data", "media", "task-" + taskId, "i2v", "seg-" + idx + ".mp4");
        if (Files.exists(out) && Files.size(out) > 0) {
            log.info("[L3-I2V] 任务{} 第{}段复用已有 I2V 片 -> {}", taskId, idx, out);
            return out.toAbsolutePath();
        }
        Files.createDirectories(out.getParent());

        // ② 按图缓存：key = 图片内容 MD5 + prompt MD5（同图同 prompt 跨任务复用，杜绝重复烧钱）
        Path cached = cachePath(imagePath, prompt);
        if (Files.exists(cached) && Files.size(cached) > 0) {
            Files.copy(cached, out, StandardCopyOption.REPLACE_EXISTING);
            log.info("[L3-I2V] 任务{} 第{}段按图缓存命中 -> {} ({} bytes)", taskId, idx, cached, Files.size(out));
            return out.toAbsolutePath();
        }
        Files.createDirectories(cached.getParent());

        // ③ 未命中：调 API 生成 -> 先写缓存（沉淀复用资产），再复制到任务目录
        String dataUrl = toDataUrl(imagePath);
        String submitBody = submitBody(prompt, dataUrl);
        String taskIdStr = submit(submitBody, taskId, idx);
        String videoUrl = poll(taskIdStr, taskId, idx);
        download(videoUrl, cached, taskId, idx);
        Files.copy(cached, out, StandardCopyOption.REPLACE_EXISTING);
        log.info("[L3-I2V] 任务{} 第{}段生成并入缓存 {} -> {}", taskId, idx, cached, out);
        return out.toAbsolutePath();
    }

    /** 按图缓存路径：{cacheDir}/{图片MD5}/{promptMD5}.mp4 */
    private Path cachePath(String imagePath, String prompt) throws Exception {
        String imgMd5 = md5(Files.readAllBytes(Path.of(imagePath)));
        String promptMd5 = md5(prompt.getBytes(StandardCharsets.UTF_8));
        return CACHE_DIR.resolve(imgMd5).resolve(promptMd5 + ".mp4");
    }

    private static String md5(byte[] data) throws Exception {
        java.security.MessageDigest md = java.security.MessageDigest.getInstance("MD5");
        byte[] d = md.digest(data);
        StringBuilder sb = new StringBuilder();
        for (byte b : d) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }

    /** 生成 motion prompt：按运镜档位 + 素材画面要点（截短），控制 I2V 运动强度 */
    public String buildMotionPrompt(String description) {
        String base;
        switch (motion == null ? "subtle" : motion) {
            case "active" -> base = "镜头明显推近再缓慢环绕，画面主体和构图基本保持，光影自然，装修工地实拍感，画面稳定不过度抖动";
            case "normal" -> base = "镜头缓慢推近并轻微平移环绕，画面主体和构图保持原样，真实装修工地氛围，画面稳定";
            default -> base = "缓慢推近镜头，画面主体和构图保持原样，真实装修工地氛围，镜头稳定平滑";
        }
        if (StringUtils.hasText(description)) {
            String d = description;
            int cut = d.indexOf("可讲卖点");
            if (cut > 0) {
                d = d.substring(0, cut);
            }
            d = d.replace('\n', ' ').trim();
            if (d.length() > 60) {
                d = d.substring(0, 60);
            }
            if (!d.isEmpty()) {
                return base + "。画面内容：" + d;
            }
        }
        return base;
    }

    private String submitBody(String prompt, String dataUrl) throws Exception {
        Map<String, Object> input = new LinkedHashMap<>();
        input.put("prompt", prompt);
        input.put("img_url", dataUrl);
        Map<String, Object> params = new LinkedHashMap<>();
        params.put("resolution", resolution);
        params.put("duration", duration);
        params.put("prompt_extend", true);
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("model", model);
        body.put("input", input);
        body.put("parameters", params);
        return MAPPER.writeValueAsString(body);
    }

    private String toDataUrl(String imagePath) throws Exception {
        File tmp = File.createTempFile("i2v", ".jpg");
        ProcessBuilder pb = new ProcessBuilder("ffmpeg", "-y", "-loglevel", "error",
                "-i", imagePath, "-vf", "scale=720:-2", "-q:v", "4",
                "-frames:v", "1", tmp.getAbsolutePath());
        Process p = pb.start();
        p.getInputStream().readAllBytes();
        p.getErrorStream().readAllBytes();
        if (p.waitFor() != 0) {
            throw new IllegalStateException("I2V 素材缩图失败: " + imagePath);
        }
        byte[] bytes = Files.readAllBytes(tmp.toPath());
        tmp.delete();
        String b64 = Base64.getEncoder().encodeToString(bytes);
        return "data:image/jpeg;base64," + b64;
    }

    private String submit(String body, Long taskId, int idx) throws Exception {
        HttpRequest req = HttpRequest.newBuilder()
                .uri(URI.create("https://dashscope.aliyuncs.com/api/v1/services/aigc/video-generation/video-synthesis"))
                .header("Authorization", "Bearer " + apiKey)
                .header("Content-Type", "application/json")
                .header("X-DashScope-Async", "enable")
                .timeout(Duration.ofSeconds(60))
                .POST(HttpRequest.BodyPublishers.ofString(body, StandardCharsets.UTF_8))
                .build();
        HttpResponse<String> resp = http.send(req, HttpResponse.BodyHandlers.ofString());
        if (resp.statusCode() != 200) {
            throw new IllegalStateException("I2V 提交失败 HTTP " + resp.statusCode() + ": " + cut(resp.body()));
        }
        JsonNode node = MAPPER.readTree(resp.body());
        String t = node.path("output").path("task_id").asText(null);
        if (t == null) {
            throw new IllegalStateException("I2V 提交无 task_id: " + cut(resp.body()));
        }
        log.info("[L3-I2V] 任务{} 第{}段提交成功 task_id={} model={}", taskId, idx, t, model);
        return t;
    }

    private String poll(String taskIdStr, Long taskId, int idx) throws Exception {
        long deadline = System.currentTimeMillis() + pollTimeoutMs;
        while (System.currentTimeMillis() < deadline) {
            Thread.sleep(pollIntervalMs);
            HttpRequest req = HttpRequest.newBuilder()
                    .uri(URI.create("https://dashscope.aliyuncs.com/api/v1/tasks/" + taskIdStr))
                    .header("Authorization", "Bearer " + apiKey)
                    .timeout(Duration.ofSeconds(30))
                    .GET().build();
            HttpResponse<String> resp = http.send(req, HttpResponse.BodyHandlers.ofString());
            JsonNode node = MAPPER.readTree(resp.body());
            String status = node.path("output").path("task_status").asText("UNKNOWN");
            if ("SUCCEEDED".equals(status)) {
                String url = node.path("output").path("video_url").asText(null);
                if (url == null) {
                    throw new IllegalStateException("I2V 成功但无 video_url");
                }
                log.info("[L3-I2V] 任务{} 第{}段生成成功 task={}", taskId, idx, taskIdStr);
                return url;
            }
            if ("FAILED".equals(status) || "CANCELED".equals(status)) {
                throw new IllegalStateException("I2V 任务 " + status + ": " + cut(resp.body()));
            }
        }
        throw new IllegalStateException("I2V 轮询超时(" + pollTimeoutMs + "ms) task=" + taskIdStr);
    }

    private void download(String videoUrl, Path out, Long taskId, int idx) throws Exception {
        HttpRequest req = HttpRequest.newBuilder()
                .uri(URI.create(videoUrl))
                .timeout(Duration.ofSeconds(120))
                .GET().build();
        HttpResponse<InputStream> resp = http.send(req, HttpResponse.BodyHandlers.ofInputStream());
        try (InputStream in = resp.body(); ByteArrayOutputStream bos = new ByteArrayOutputStream()) {
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) != -1) {
                bos.write(buf, 0, n);
            }
            Files.write(out, bos.toByteArray());
        }
        log.info("[L3-I2V] 任务{} 第{}段下载完成 -> {} ({} bytes)", taskId, idx, out, Files.size(out));
    }

    private static String cut(String s) {
        if (s == null) {
            return "";
        }
        return s.length() > 300 ? s.substring(0, 300) : s;
    }
}

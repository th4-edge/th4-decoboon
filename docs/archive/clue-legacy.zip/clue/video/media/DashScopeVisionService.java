package com.th4.edge.decoboon.clue.video.media;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.th4.edge.framework.core.annotation.Note;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Base64;

/**
 * 视觉理解服务：调用阿里云百炼（DashScope）通义千问 VL（qwen-vl-plus）识别图片内容。
 * <p>
 * - OpenAI 兼容接口：POST {base-url}/chat/completions，图片以 base64 data URL 直传（无需 OSS）；
 * - 输出：2~3 句中文画面描述（地点/施工阶段/可见建材/结构/卖点）+ 一行"可讲卖点"营销话术；
 * - 纯 JDK HTTP（HttpURLConnection）+ Jackson，无额外 SDK 依赖；未配 Key/调用失败返回空并降级。
 */
@Note("DashScope 视觉识别")
@Component
public class DashScopeVisionService {

    private static final Logger log = LoggerFactory.getLogger(DashScopeVisionService.class);

    private final ObjectMapper objectMapper;
    private final String apiKey;
    private final String model;
    private final String baseUrl;

    public DashScopeVisionService(ObjectMapper objectMapper,
                                  @Value("${th4.edge.decoboon.ai.vision.api-key:}") String apiKey,
                                  @Value("${th4.edge.decoboon.ai.vision.model:qwen-vl-plus}") String model,
                                  @Value("${th4.edge.decoboon.ai.vision.base-url:https://dashscope.aliyuncs.com/compatible-mode/v1}") String baseUrl) {
        this.objectMapper = objectMapper;
        String resolvedKey = StringUtils.hasText(apiKey) ? apiKey : System.getenv("DASHSCOPE_API_KEY");
        this.apiKey = resolvedKey;
        this.model = model;
        this.baseUrl = baseUrl;
    }

    public boolean isEnabled() {
        return StringUtils.hasText(apiKey);
    }

    /**
     * 识别单张图片，返回结构化描述文本。
     *
     * @param imagePath 本地图片路径
     * @param taskId    任务号（仅日志）
     * @return 描述文本；未配置 Key / 失败时返回 null
     */
    public String describeImage(String imagePath, Long taskId) {
        if (!isEnabled()) {
            log.warn("[Vision] 任务{} 未配置视觉 API Key，跳过识别", taskId);
            return null;
        }
        try {
            Path p = Path.of(imagePath);
            byte[] bytes = Files.readAllBytes(p);
            String mime = mimeOf(p);
            String dataUrl = "data:" + mime + ";base64," + Base64.getEncoder().encodeToString(bytes);

            ObjectNode body = objectMapper.createObjectNode();
            body.put("model", model);
            ArrayNode messages = body.putArray("messages");
            ObjectNode user = messages.addObject();
            user.put("role", "user");
            ArrayNode content = user.putArray("content");
            ObjectNode text = content.addObject();
            text.put("type", "text");
            text.put("text", "这是装修工地的实拍照片。请用中文简洁描述：1)画面地点与施工阶段；2)画面中可见的具体物件（管道/线管/墙面/结构/建材等）；3)能体现施工质量或注意点的细节。再单独另起一行，以\"可讲卖点：\"开头写一句口语化、接地气的营销话术卖点。最后单独另起一行，以\"花字：\"开头写一个不超过8个字的短促有力的分镜标题关键词（如\"线管要齐\"\"封口要严\"\"接头要实\"）。总字数110字以内。");
            ObjectNode img = content.addObject();
            img.put("type", "image_url");
            img.putObject("image_url").put("url", dataUrl);
            body.put("temperature", 0.3);

            String resp = postJson(baseUrl + "/chat/completions", body.toString());
            JsonNode root = objectMapper.readTree(resp);
            JsonNode contentNode = root.path("choices").path(0).path("message").path("content");
            if (contentNode.isMissingNode() || contentNode.isNull()) {
                log.warn("[Vision] 任务{} 响应无内容字段: {}", taskId, truncate(resp, 200));
                return null;
            }
            String textOut = contentNode.isTextual() ? contentNode.asText() : contentNode.toString();
            log.info("[Vision] 任务{} 图片识别完成 ({}字节, {}字)", taskId, bytes.length, textOut.length());
            return textOut.trim();
        } catch (Exception e) {
            log.warn("[Vision] 任务{} 图片识别失败: {}", taskId, e.getMessage());
            return null;
        }
    }

    private String postJson(String url, String json) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) URI.create(url).toURL().openConnection();
        try {
            conn.setRequestMethod("POST");
            conn.setConnectTimeout(15000);
            conn.setReadTimeout(60000);
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("Authorization", "Bearer " + apiKey);
            byte[] body = json.getBytes(StandardCharsets.UTF_8);
            try (OutputStream os = conn.getOutputStream()) {
                os.write(body);
            }
            int code = conn.getResponseCode();
            InputStream is = code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream();
            String text = new String((is == null ? new byte[0] : is.readAllBytes()), StandardCharsets.UTF_8);
            if (code < 200 || code >= 300) {
                throw new IllegalStateException("HTTP " + code + ": " + truncate(text, 300));
            }
            return text;
        } finally {
            conn.disconnect();
        }
    }

    private String mimeOf(Path p) {
        String n = p.getFileName().toString().toLowerCase();
        if (n.endsWith(".png")) {
            return "image/png";
        }
        if (n.endsWith(".webp")) {
            return "image/webp";
        }
        return "image/jpeg";
    }

    private String truncate(String s, int max) {
        return s == null ? "" : (s.length() <= max ? s : s.substring(0, max) + "...");
    }
}

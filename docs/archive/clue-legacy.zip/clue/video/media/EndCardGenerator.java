package com.th4.edge.decoboon.clue.video.media;

import com.th4.edge.framework.core.annotation.Note;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.imageio.ImageIO;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * 尾卡生成：Java AWT 直接绘制 PNG（720x1280 竖版），无需 ffmpeg drawtext。
 * <p>
 * 深色底 + 公司名 + 咨询电话 + 品牌 slogan，作为成片结尾 3 秒画面。
 */
@Note("尾卡生成")
@Component
public class EndCardGenerator {

    private static final Logger log = LoggerFactory.getLogger(EndCardGenerator.class);
    private static final int W = 720;
    private static final int H = 1280;

    private final String companyName;
    private final String phone;

    public EndCardGenerator(@Value("${th4.edge.decoboon.video.endcard.name:装客宝}") String companyName,
                            @Value("${th4.edge.decoboon.video.endcard.phone:400-8888-9999}") String phone) {
        this.companyName = companyName;
        this.phone = phone;
    }

    public String generate(Long taskId) {
        try {
            BufferedImage img = new BufferedImage(W, H, BufferedImage.TYPE_INT_RGB);
            Graphics2D g = img.createGraphics();
            try {
                g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
                // 深色竖向渐变底
                for (int y = 0; y < H; y++) {
                    float r = 0.10f + 0.06f * (y / (float) H);
                    g.setColor(new Color(r, r * 1.08f, r * 1.22f));
                    g.drawLine(0, y, W, y);
                }
                // 品牌 slogan
                drawCentered(g, "装修 · 获客 · 出片", 420, 38, new Color(255, 255, 255, 160));
                // 公司名
                drawCentered(g, companyName, 600, 92, Color.WHITE);
                // 分隔线
                g.setColor(new Color(255, 255, 255, 120));
                g.fillRect(W / 2 - 120, 660, 240, 3);
                // 电话
                drawCentered(g, phone, 720, 48, new Color(255, 235, 160));
                // 底部提示
                drawCentered(g, "AI 自动出片 · 30 秒一条", 880, 30, new Color(255, 255, 255, 150));
            } finally {
                g.dispose();
            }

            Path dir = Path.of("data", "media", "task-" + taskId);
            Files.createDirectories(dir);
            Path png = dir.resolve("endcard.png");
            ImageIO.write(img, "png", png.toFile());
            log.info("[EndCard] 任务{} 尾卡生成 -> {}", taskId, png.toAbsolutePath());
            return png.toAbsolutePath().toString();
        } catch (Exception e) {
            throw new IllegalStateException("尾卡生成失败: " + e.getMessage(), e);
        }
    }

    private void drawCentered(Graphics2D g, String text, int y, int size, Color color) {
        Font font = new Font("PingFang SC", Font.BOLD, size);
        g.setFont(font);
        g.setColor(color);
        FontMetrics fm = g.getFontMetrics();
        int x = (W - fm.stringWidth(text)) / 2;
        g.drawString(text, x, y);
    }
}

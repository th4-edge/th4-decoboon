package com.th4.edge.decoboon.clue.video.media;

import com.th4.edge.decoboon.clue.video.planner.SegmentPlan;
import com.th4.edge.framework.core.annotation.Note;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * FFmpeg 剪辑执行器（确定性混剪管线的像素级执行层）：
 * <ul>
 *   <li>{@link #renderSegment}：单图 → 单段——超采样 2160x3840（消除 zoompan 整数取整抖动）
 *       → zoompan ease-in-out 运镜 → eq 逐段色彩归一 → 1080x1920@25 yuv420p 无音轨临时段；</li>
 *   <li>{@link #mergeSegments}：全段 xfade=transition=fade 交叉溶解合并（offset 累积公式
 *       offset_k = Σdᵢ − k·T），可选 BGM 混音（afade 收尾 + loudnorm 响度归一 −14 LUFS）；</li>
 * </ul>
 * 与既有 {@link FfmpegRenderService}（AI 出片链路）互不影响，本类服务于图片混剪流水线。
 */
@Note("FFmpeg 剪辑执行器")
@Component
public class FfmpegCli {

    private static final Logger log = LoggerFactory.getLogger(FfmpegCli.class);

    private static final int W = 1080;
    private static final int H = 1920;
    private static final int FPS = 25;

    /** 单图渲染为标准化分段（1080x1920@25 yuv420p 无音轨），-threads 2 让多任务共享 CPU */
    public Path renderSegment(SegmentPlan plan, Long taskId) {
        try {
            Path dir = Path.of("data", "media", "task-" + taskId, "segments");
            Files.createDirectories(dir);
            Path out = dir.resolve("seg-" + plan.index() + ".mp4");
            int frames = Math.max((int) Math.round(plan.durationSec() * FPS), 2);
            String vf = "scale=2160:3840:force_original_aspect_ratio=increase,crop=2160:3840,setsar=1,"
                    + "zoompan=z='" + plan.zoomExpr(frames) + "':x='" + plan.xExpr(frames) + "':y='" + plan.yExpr(frames)
                    + "':d=" + frames + ":s=" + W + "x" + H + ":fps=" + FPS + ","
                    + "eq=contrast=" + plan.contrast() + ":brightness=" + plan.brightness()
                    + ":saturation=" + plan.saturation()
                    + ",format=yuv420p";
            run(List.of("ffmpeg", "-y", "-loglevel", "error",
                    "-i", plan.imagePath(),
                    "-vf", vf,
                    "-r", String.valueOf(FPS), "-threads", "2",
                    "-c:v", "libx264", "-preset", "veryfast", "-crf", "19",
                    "-an", "-movflags", "+faststart",
                    "-y", out.toAbsolutePath().toString()), 180);
            return out;
        } catch (Exception e) {
            throw new IllegalStateException("第" + plan.index() + "段渲染失败: " + e.getMessage(), e);
        }
    }

    /**
     * 全段 xfade 交叉溶解合并（可选 BGM 混音 + loudnorm 归一）。
     * offset_k = Σ(d₁..d_k) − k·T，T 与分段 fade 一致。
     */
    public Path mergeSegments(List<Path> segments, double fadeSec, double totalDur,
                              String bgmPath, Long taskId) {
        try {
            Path dir = Path.of("data", "media", "task-" + taskId);
            Files.createDirectories(dir);
            Path out = dir.resolve("montage.mp4");
            int n = segments.size();
            if (n == 1) {
                // 单段：直接重编码收尾（无需 filter_complex）
                List<String> cmd = new ArrayList<>(List.of("ffmpeg", "-y", "-loglevel", "error",
                        "-i", segments.get(0).toAbsolutePath().toString()));
                boolean hasBgm = resolveBgm(bgmPath) != null;
                if (hasBgm) {
                    cmd.addAll(List.of("-stream_loop", "-1", "-i", resolveBgm(bgmPath)));
                    cmd.addAll(List.of("-filter_complex",
                            "[" + 1 + ":a]atrim=duration=" + String.format("%.3f", totalDur)
                                    + ",afade=t=out:st=" + String.format("%.3f", Math.max(totalDur - 1.0, 0))
                                    + ":d=1.0,loudnorm=I=-14:TP=-1.5:LRA=11[aout]",
                            "-map", "0:v", "-map", "[aout]"));
                } else {
                    cmd.addAll(List.of("-map", "0:v", "-an"));
                }
                cmd.addAll(List.of("-c:v", "libx264", "-preset", "veryfast", "-crf", "19",
                        "-pix_fmt", "yuv420p", "-r", String.valueOf(FPS),
                        "-c:a", "aac", "-b:a", "128k", "-ar", "44100",
                        "-movflags", "+faststart",
                        "-y", out.toAbsolutePath().toString()));
                run(cmd, 600);
                log.info("[FfmpegCli] 任务{} 单段收尾完成 -> {}", taskId, out);
                return out;
            }

            List<String> cmd = new ArrayList<>(List.of("ffmpeg", "-y", "-loglevel", "error"));
            for (Path s : segments) {
                cmd.addAll(List.of("-i", s.toAbsolutePath().toString()));
            }
            String bgm = resolveBgm(bgmPath);
            boolean hasBgm = bgm != null;
            if (hasBgm) {
                cmd.addAll(List.of("-stream_loop", "-1", "-i", bgm));
            }

            StringBuilder fc = new StringBuilder();
            String prev = "[0:v]";
            double cum = 0;
            for (int i = 0; i < n - 1; i++) {
                double durI = Math.max(MediaProbe.durationSec(segments.get(i).toString()), 0.5);
                double offset = Math.max(cum + durI - fadeSec, 0);
                String outLbl = (i == n - 2) ? "[vout]" : "[x" + i + "]";
                fc.append(prev).append('[').append(i + 1).append(":v]xfade=transition=fade:duration=")
                        .append(String.format("%.3f", fadeSec))
                        .append(":offset=").append(String.format("%.3f", offset))
                        .append(outLbl).append(';');
                prev = outLbl;
                cum += durI - fadeSec;
            }
            if (hasBgm) {
                fc.append('[').append(n).append(":a]atrim=duration=").append(String.format("%.3f", totalDur))
                        .append(",afade=t=out:st=").append(String.format("%.3f", Math.max(totalDur - 1.0, 0)))
                        .append(":d=1.0,loudnorm=I=-14:TP=-1.5:LRA=11[aout]");
                cmd.addAll(List.of("-filter_complex", fc.toString()));
                cmd.addAll(List.of("-map", "[vout]", "-map", "[aout]"));
            } else {
                fc.setLength(fc.length() - 1);
                cmd.addAll(List.of("-filter_complex", fc.toString()));
                cmd.addAll(List.of("-map", "[vout]", "-an"));
            }
            cmd.addAll(List.of("-c:v", "libx264", "-preset", "veryfast", "-crf", "19",
                    "-pix_fmt", "yuv420p", "-r", String.valueOf(FPS),
                    "-c:a", "aac", "-b:a", "128k", "-ar", "44100",
                    "-movflags", "+faststart",
                    "-y", out.toAbsolutePath().toString()));
            run(cmd, 600);
            log.info("[FfmpegCli] 任务{} 合并完成 {} 段 xfade={}s BGM={} -> {}",
                    taskId, n, String.format("%.3f", fadeSec), hasBgm ? "on" : "off", out);
            return out;
        } catch (Exception e) {
            throw new IllegalStateException("合并失败: " + e.getMessage(), e);
        }
    }

    /** BGM 路径有效性校验（路径为空或文件缺失则无背景乐） */
    private String resolveBgm(String bgmPath) {
        if (StringUtils.hasText(bgmPath) && Files.exists(Path.of(bgmPath.trim()))) {
            return bgmPath.trim();
        }
        return null;
    }

    /** 执行 ffmpeg 子进程：超时强杀、退出码检查、输出留档（报错几乎全在合并输出流） */
    public void run(List<String> cmd, int timeoutSec) {
        log.debug("[FfmpegCli] 执行: {}", String.join(" ", cmd));
        try {
            ProcessBuilder pb = new ProcessBuilder(cmd);
            pb.redirectErrorStream(true);
            Process p = pb.start();
            String out = new String(p.getInputStream().readAllBytes());
            boolean ok = p.waitFor(timeoutSec, TimeUnit.SECONDS);
            if (!ok) {
                p.destroyForcibly();
                throw new IllegalStateException("命令超时: " + String.join(" ", cmd));
            }
            if (p.exitValue() != 0) {
                throw new IllegalStateException("命令失败(" + p.exitValue() + "): "
                        + String.join(" ", cmd) + "\n" + out);
            }
        } catch (IllegalStateException e) {
            throw e;
        } catch (Exception e) {
            throw new IllegalStateException("命令执行异常: " + e.getMessage(), e);
        }
    }
}

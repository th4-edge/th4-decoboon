package com.th4.edge.decoboon.clue.video.media;

import com.th4.edge.framework.core.annotation.Note;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

/**
 * FFmpeg 真实合片服务：
 * <p>
 * 1. renderMain：素材图片轮播（720x1280 竖版）+ 配音音频 + 中文字幕轨(mov_text) → 主片草稿 mp4；
 *    <ul>
 *      <li>L1 电影感模式（{@code video.l1.enabled=true}）：zoompan 推拉运镜 + 逐段 fade 转场 +
 *          BGM 节拍检测卡点切镜 + 人声侧链压缩(ducking)混音 + 钩子/转场音效；</li>
 *      <li>旧模式（默认关闭时）：静态图按配音时长均分轮播。</li>
 *    </ul>
 * 2. appendEndCard：尾卡 PNG 追加为末尾 3 秒画面 → 最终成片 mp4。
 */
@Note("FFmpeg 合片")
@Component
public class FfmpegRenderService {

    private static final Logger log = LoggerFactory.getLogger(FfmpegRenderService.class);

    private static final int W = 720;
    private static final int H = 1280;
    /** I2V 并行生成并发数（服务端对并发任务有队列限制，3 并发稳妥） */
    private static final int I2V_PARALLEL = 3;
    /** 字幕条纵向位置：底部留白区域 */
    private static final int SUBTITLE_Y = 1120;

    private final SubtitleBannerGenerator subtitleBannerGenerator;
    private final TaglineBannerGenerator taglineBannerGenerator;
    private final DashScopeI2VService i2vService;

    private final boolean l1Enabled;
    private final boolean l3Enabled;
    private final boolean kenBurnsEnabled;
    private final double fadeSec;
    private final boolean bgmEnabled;
    private final String bgmPath;
    private final double bgmVolume;
    private final boolean sfxEnabled;
    private final int hookDelayMs;
    private final double hookVolume;
    private final double tickVolume;
    private final boolean taglineEnabled;
    private final int taglineY;

    public FfmpegRenderService(SubtitleBannerGenerator subtitleBannerGenerator,
                               TaglineBannerGenerator taglineBannerGenerator,
                               DashScopeI2VService i2vService,
                               @Value("${th4.edge.decoboon.video.l1.enabled:true}") boolean l1Enabled,
                               @Value("${th4.edge.decoboon.video.l3.enabled:false}") boolean l3Enabled,
                               @Value("${th4.edge.decoboon.video.l1.ken-burns:true}") boolean kenBurnsEnabled,
                               @Value("${th4.edge.decoboon.video.l1.fade:0.12}") double fadeSec,
                               @Value("${th4.edge.decoboon.video.l1.bgm.enabled:true}") boolean bgmEnabled,
                               @Value("${th4.edge.decoboon.video.l1.bgm.path:}") String bgmPath,
                               @Value("${th4.edge.decoboon.video.l1.bgm.volume:0.25}") double bgmVolume,
                               @Value("${th4.edge.decoboon.video.l1.sfx.enabled:true}") boolean sfxEnabled,
                               @Value("${th4.edge.decoboon.video.l1.sfx.hook-delay-ms:350}") int hookDelayMs,
                               @Value("${th4.edge.decoboon.video.l1.sfx.hook-volume:0.35}") double hookVolume,
                               @Value("${th4.edge.decoboon.video.l1.sfx.tick-volume:0.2}") double tickVolume,
                               @Value("${th4.edge.decoboon.video.tagline.enabled:true}") boolean taglineEnabled,
                               @Value("${th4.edge.decoboon.video.tagline.y:140}") int taglineY) {
        this.subtitleBannerGenerator = subtitleBannerGenerator;
        this.taglineBannerGenerator = taglineBannerGenerator;
        this.i2vService = i2vService;
        this.l1Enabled = l1Enabled;
        this.l3Enabled = l3Enabled;
        this.kenBurnsEnabled = kenBurnsEnabled;
        this.fadeSec = fadeSec;
        this.bgmEnabled = bgmEnabled;
        this.bgmPath = bgmPath;
        this.bgmVolume = bgmVolume;
        this.sfxEnabled = sfxEnabled;
        this.hookDelayMs = hookDelayMs;
        this.hookVolume = hookVolume;
        this.tickVolume = tickVolume;
        this.taglineEnabled = taglineEnabled;
        this.taglineY = taglineY;
    }

    /** 主片合成：图片轮播 + 音频 + 字幕轨（taglines 花字、descriptions 素材语义用于 L3 AI 图生视频） */
    public String renderMain(List<String> images, String audioPath, String srtPath, List<String> taglines,
                             List<String> descriptions, Long taskId) {
        if (l3Enabled && i2vService.isEnabled()) {
            return renderMainAi(images, descriptions, audioPath, srtPath, taglines, taskId);
        }
        if (l1Enabled) {
            return renderMainCinematic(images, audioPath, srtPath, taglines, taskId);
        }
        return renderMainLegacy(images, audioPath, srtPath, taskId);
    }

    /** L3 AI 视频融合主片：逐素材图生视频（I2V）→ 按卡点分段拼接 → 花字/音轨/字幕/尾卡链路不变 */
    private String renderMainAi(List<String> images, List<String> descriptions, String audioPath, String srtPath,
                                List<String> taglines, Long taskId) {
        try {
            Path dir = Path.of("data", "media", "task-" + taskId);
            Files.createDirectories(dir);
            int n = images.size();
            double audioDur = MediaProbe.durationSec(audioPath);

            String bgm = resolveBgm(audioDur);
            List<Double> beats = new ArrayList<>();
            if (StringUtils.hasText(bgm)) {
                beats = BeatDetector.detectBeats(bgm, audioDur);
            }
            double[] segs = snappedDurations(n, audioDur, beats);

            Path videoOnly = dir.resolve("render_v.mp4");
            buildAiVideo(images, descriptions, segs, taskId);

            Path videoTag = videoOnly;
            if (taglineEnabled && taglines != null && !taglines.isEmpty()) {
                videoTag = buildTaglines(videoOnly, taglines, segs, taskId);
            }

            Path mixedAudio = dir.resolve("render_a.m4a");
            buildMixedAudio(audioPath, bgm, segs, mixedAudio);

            Path draft = dir.resolve("render.mp4");
            run(List.of("ffmpeg", "-y", "-loglevel", "error",
                    "-i", videoTag.toAbsolutePath().toString(),
                    "-i", mixedAudio.toAbsolutePath().toString(),
                    "-i", srtPath,
                    "-map", "0:v", "-map", "1:a", "-map", "2:s",
                    "-c:v", "copy", "-c:a", "copy", "-c:s", "mov_text",
                    "-metadata:s:s:0", "language=chi",
                    "-movflags", "+faststart",
                    "-y", draft.toAbsolutePath().toString()), 60);

            log.info("[Render] 任务{} L3 AI视频融合主片 {} 图 时长={}s BGM={} 卡点切镜={} 花字={} -> {}",
                    taskId, n, String.format("%.1f", audioDur),
                    StringUtils.hasText(bgm) ? "on" : "off",
                    beats.isEmpty() ? "off" : "on",
                    videoTag != videoOnly ? "on(" + taglines.size() + ")" : "off", draft);
            return draft.toAbsolutePath().toString();
        } catch (Exception e) {
            throw new IllegalStateException("FFmpeg L3 AI视频融合主片合成失败: " + e.getMessage(), e);
        }
    }

    /**
     * 逐素材图生成 I2V 段视频并拼接成 render_v.mp4：
     * 每段统一重编码 720x1280/25fps/h264 无音轨，时长对齐 snappedDurations（不足慢放、超则截断），
     * 再 concat demuxer 无缝拼接。I2V 生成失败/超时会抛异常，由上层降级回 L1/Legacy。
     */
    private void buildAiVideo(List<String> images, List<String> descriptions, double[] segs, Long taskId) throws Exception {
        Path i2vDir = Path.of("data", "media", "task-" + taskId, "i2v");
        Files.createDirectories(i2vDir);
        // ① 并行提交全部 I2V 段生成（每段约 1-3 分钟，串行会拖到 N 倍；3 并发压到 ~1 段耗时）
        ExecutorService pool = Executors.newFixedThreadPool(Math.min(images.size(), I2V_PARALLEL));
        List<Future<Path>> futures = new ArrayList<>();
        try {
            for (int i = 0; i < images.size(); i++) {
                final int idx = i;
                final String prompt = i2vService.buildMotionPrompt(
                        descriptions != null && idx < descriptions.size() ? descriptions.get(idx) : null);
                futures.add(pool.submit(() -> {
                    try {
                        return i2vService.generateSegVideo(images.get(idx), prompt, taskId, idx);
                    } catch (Exception e) {
                        throw new RuntimeException("I2V 第" + idx + "段生成失败: " + e.getMessage(), e);
                    }
                }));
            }
            List<Path> segs2 = new ArrayList<>();
            for (Future<Path> f : futures) {
                segs2.add(f.get());
            }
        } finally {
            pool.shutdownNow();
        }
        // ② 逐段统一规格 + 时长对齐（本地 ffmpeg，快）
        List<String> listLines = new ArrayList<>();
        for (int i = 0; i < images.size(); i++) {
            Path seg = Path.of("data", "media", "task-" + taskId, "i2v", "seg-" + i + ".mp4");
            Path conv = i2vDir.resolve("seg-" + i + "-conv.mp4");
            double origDur = MediaProbe.durationSec(seg.toString());
            String vf;
            if (origDur > 0 && origDur < segs[i] - 0.1) {
                double ratio = segs[i] / origDur;
                vf = String.format("scale=720:1280:force_original_aspect_ratio=increase,crop=720:1280,setpts=%.4f*PTS", ratio);
            } else {
                vf = "scale=720:1280:force_original_aspect_ratio=increase,crop=720:1280";
            }
            run(List.of("ffmpeg", "-y", "-loglevel", "error",
                    "-i", seg.toAbsolutePath().toString(),
                    "-vf", vf, "-t", String.format("%.3f", segs[i]), "-r", "25", "-an",
                    "-c:v", "libx264", "-preset", "veryfast", "-crf", "23",
                    "-pix_fmt", "yuv420p", "-movflags", "+faststart",
                    "-y", conv.toAbsolutePath().toString()), 180);
            listLines.add("file '" + conv.toAbsolutePath() + "'");
        }
        // ③ concat 无缝拼接
        Path listFile = i2vDir.resolve("concat.txt");
        Files.writeString(listFile, String.join("\n", listLines) + "\n", StandardCharsets.UTF_8);
        Path out = Path.of("data", "media", "task-" + taskId, "render_v.mp4");
        run(List.of("ffmpeg", "-y", "-loglevel", "error", "-f", "concat", "-safe", "0",
                "-i", listFile.toAbsolutePath().toString(),
                "-c", "copy", "-y", out.toAbsolutePath().toString()), 60);
        log.info("[Render] 任务{} L3 I2V 段视频拼接完成 {} 段(并行{}) -> {}", taskId, images.size(), I2V_PARALLEL, out);
    }

    /** 旧模式：静态图按配音时长均分轮播 */
    private String renderMainLegacy(List<String> images, String audioPath, String srtPath, Long taskId) {
        try {
            Path dir = Path.of("data", "media", "task-" + taskId);
            Files.createDirectories(dir);
            Path draft = dir.resolve("render.mp4");
            Path subbed = dir.resolve("render_sub.mp4");

            List<String> cmd = new ArrayList<>(List.of(
                    "ffmpeg", "-y", "-loglevel", "error"));
            int n = images.size();
            double audioDur = MediaProbe.durationSec(audioPath);
            double perSec = Math.max(audioDur / n, 2.0);   // 每张图按配音时长均分，保证画面覆盖全片
            String per = String.format("%.2f", perSec);
            for (String img : images) {
                cmd.addAll(List.of("-loop", "1", "-t", per, "-i", img));
            }
            cmd.addAll(List.of("-i", audioPath));

            // 图片按均分时长拼接，覆盖整个配音
            StringBuilder fc = new StringBuilder();
            for (int i = 0; i < n; i++) {
                fc.append('[').append(i).append(":v]scale=").append(W).append(':').append(H)
                        .append(":force_original_aspect_ratio=increase,crop=").append(W).append(':').append(H)
                        .append(",setsar=1,format=yuv420p,trim=duration=").append(per).append(",setpts=PTS-STARTPTS[v")
                        .append(i).append("];");
            }
            for (int i = 0; i < n; i++) {
                fc.append("[v").append(i).append(']');
            }
            fc.append("concat=n=").append(n).append(":v=1:a=0[v]");
            cmd.addAll(List.of("-filter_complex", fc.toString()));
            cmd.addAll(List.of("-map", "[v]", "-map", n + ":a",
                    "-c:v", "libx264", "-preset", "veryfast", "-crf", "23",
                    "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "128k", "-ar", "44100",
                    "-shortest", "-movflags", "+faststart", "-y", draft.toAbsolutePath().toString()));
            run(cmd, 180);

            // 中文字幕轨 mux（mov_text 无需 libass）
            run(List.of("ffmpeg", "-y", "-loglevel", "error",
                    "-i", draft.toAbsolutePath().toString(),
                    "-i", srtPath,
                    "-map", "0", "-map", "1",
                    "-c:v", "copy", "-c:a", "copy", "-c:s", "mov_text",
                    "-metadata:s:s:0", "language=chi",
                    "-y", subbed.toAbsolutePath().toString()), 60);

            log.info("[Render] 任务{} 主片合成完成 {} -> {}", taskId, images.size() + "图", subbed);
            return subbed.toAbsolutePath().toString();
        } catch (Exception e) {
            throw new IllegalStateException("FFmpeg 主片合成失败: " + e.getMessage(), e);
        }
    }

    /**
     * 硬字幕烧录：把字幕条 PNG 按时间窗 overlay 进画面像素。
     * <p>
     * 本机 ffmpeg 无 libass（无 drawtext/subtitles filter），
     * 用透明字幕条 + overlay:enable='between(t,start,end)' 实现抖音式画面内字幕，
     * 任何播放器都直接可见。
     */
    public String burnSubtitles(String videoPath, List<SubtitleGenerator.Cue> cues, Long taskId) {
        try {
            Path dir = Path.of("data", "media", "task-" + taskId);
            Files.createDirectories(dir);
            List<Path> banners = subtitleBannerGenerator.generateAll(cues, taskId);
            if (banners.isEmpty()) {
                return videoPath;
            }
            Path burned = dir.resolve("render_burn.mp4");

            List<String> cmd = new ArrayList<>(List.of("ffmpeg", "-y", "-loglevel", "error"));
            cmd.addAll(List.of("-i", videoPath));
            // 每张字幕条只在自身时间窗内生成帧（-itsoffset/-t + 25fps），避免全片高频解码导致编码极慢
            for (int i = 0; i < banners.size(); i++) {
                SubtitleGenerator.Cue cue = cues.get(i);
                double start = cue.startMs() / 1000.0;
                double span = Math.max((cue.endMs() - cue.startMs()) / 1000.0, 0.8) + 0.3;
                cmd.addAll(List.of("-loop", "1", "-framerate", "25",
                        "-itsoffset", String.format("%.3f", start),
                        "-t", String.format("%.3f", span),
                        "-i", banners.get(i).toAbsolutePath().toString()));
            }

            StringBuilder fc = new StringBuilder();
            String prev = "[0:v]";
            for (int i = 0; i < banners.size(); i++) {
                String out = "[v" + i + "]";
                double s = cues.get(i).startMs() / 1000.0;
                double e = Math.max(cues.get(i).endMs() / 1000.0, s + 0.3);
                fc.append(prev).append('[').append(i + 1).append(":v]overlay=0:")
                        .append(SUBTITLE_Y).append(":enable='between(t,")
                        .append(String.format("%.3f", s)).append(',').append(String.format("%.3f", e))
                        .append(")'").append(out).append(';');
                prev = out;
            }
            fc.setLength(fc.length() - 1); // 去尾分号

            cmd.addAll(List.of("-filter_complex", fc.toString()));
            cmd.addAll(List.of("-map", prev, "-map", "0:a",
                    "-c:v", "libx264", "-preset", "veryfast", "-crf", "23",
                    "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "128k",
                    "-movflags", "+faststart", "-y", burned.toAbsolutePath().toString()));
            run(cmd, 180);

            log.info("[Render] 任务{} 硬字幕烧录完成 {} 条 -> {}", taskId, banners.size(), burned);
            return burned.toAbsolutePath().toString();
        } catch (Exception e) {
            throw new IllegalStateException("FFmpeg 硬字幕烧录失败: " + e.getMessage(), e);
        }
    }

    /** 尾卡追加：主片 + 3 秒尾卡画面 → 最终成片 */
    public String appendEndCard(String draftMp4, String endcardPng, Long taskId) {
        try {
            Path dir = Path.of("data", "media", "task-" + taskId);
            Files.createDirectories(dir);
            Path finalPath = dir.resolve("final.mp4");

            // 尾卡生成 3 秒片段（带静音音轨，保证 concat 拼接成功）
            run(List.of("ffmpeg", "-y", "-loglevel", "error",
                    "-loop", "1", "-t", "3", "-i", endcardPng,
                    "-f", "lavfi", "-i", "anullsrc=r=44100:cl=stereo",
                    "-c:v", "libx264", "-preset", "veryfast", "-crf", "23",
                    "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "128k", "-shortest",
                    "-y", dir.resolve("end.mp4").toAbsolutePath().toString()), 60);

            // concat filter 重编码拼接（容错不同流结构）；携带字幕轨(mov_text)
            run(List.of("ffmpeg", "-y", "-loglevel", "error",
                    "-i", draftMp4, "-i", dir.resolve("end.mp4").toAbsolutePath().toString(),
                    "-filter_complex", "[0:v][0:a][1:v][1:a]concat=n=2:v=1:a=1[v][a]",
                    "-map", "[v]", "-map", "[a]", "-map", "0:s?",
                    "-c:v", "libx264", "-preset", "veryfast", "-crf", "23",
                    "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "128k",
                    "-c:s", "mov_text",
                    "-movflags", "+faststart", "-y", finalPath.toAbsolutePath().toString()), 180);

            double duration = MediaProbe.durationSec(finalPath.toAbsolutePath().toString());
            log.info("[Render] 任务{} 尾卡合成完成 总时长={}s -> {}", taskId, String.format("%.1f", duration), finalPath);
            return finalPath.toAbsolutePath().toString();
        } catch (Exception e) {
            throw new IllegalStateException("FFmpeg 尾卡合成失败: " + e.getMessage(), e);
        }
    }

    /** L1 电影感主片：zoompan 运镜 + fade 转场 + BGM 卡点切镜 + 混音音效 + 花字 + 字幕轨 */
    private String renderMainCinematic(List<String> images, String audioPath, String srtPath, List<String> taglines, Long taskId) {
        try {
            Path dir = Path.of("data", "media", "task-" + taskId);
            Files.createDirectories(dir);
            int n = images.size();
            double audioDur = MediaProbe.durationSec(audioPath);

            String bgm = resolveBgm(audioDur);
            List<Double> beats = new ArrayList<>();
            if (StringUtils.hasText(bgm)) {
                beats = BeatDetector.detectBeats(bgm, audioDur);
            }
            double[] segs = snappedDurations(n, audioDur, beats);

            Path videoOnly = dir.resolve("render_v.mp4");
            buildVideoOnly(images, segs, videoOnly);

            // 花字：每段素材时间窗内叠加大号分镜标题（与画面对应）
            Path videoTag = videoOnly;
            if (taglineEnabled && taglines != null && !taglines.isEmpty()) {
                videoTag = buildTaglines(videoOnly, taglines, segs, taskId);
            }

            Path mixedAudio = dir.resolve("render_a.m4a");
            buildMixedAudio(audioPath, bgm, segs, mixedAudio);

            Path draft = dir.resolve("render.mp4");
            run(List.of("ffmpeg", "-y", "-loglevel", "error",
                    "-i", videoTag.toAbsolutePath().toString(),
                    "-i", mixedAudio.toAbsolutePath().toString(),
                    "-i", srtPath,
                    "-map", "0:v", "-map", "1:a", "-map", "2:s",
                    "-c:v", "copy", "-c:a", "copy", "-c:s", "mov_text",
                    "-metadata:s:s:0", "language=chi",
                    "-movflags", "+faststart",
                    "-y", draft.toAbsolutePath().toString()), 60);

            log.info("[Render] 任务{} L1电影感主片 {} 图 时长={}s BGM={} 卡点切镜={} 运镜={} 花字={} -> {}",
                    taskId, n, String.format("%.1f", audioDur),
                    StringUtils.hasText(bgm) ? "on" : "off",
                    beats.isEmpty() ? "off" : "on",
                    kenBurnsEnabled ? "on" : "off",
                    videoTag != videoOnly ? "on(" + taglines.size() + ")" : "off", draft);
            return draft.toAbsolutePath().toString();
        } catch (Exception e) {
            throw new IllegalStateException("FFmpeg L1 电影感主片合成失败: " + e.getMessage(), e);
        }
    }

    /** 花字烧录：按每段素材时间窗把大号标题条叠加到画面中上部 */
    private Path buildTaglines(Path video, List<String> taglines, double[] segs, Long taskId) throws Exception {
        List<Path> banners = taglineBannerGenerator.generateAll(taglines, taskId);
        if (banners.isEmpty()) {
            return video;
        }
        Path dir = Path.of("data", "media", "task-" + taskId);
        Path out = dir.resolve("render_tag.mp4");
        int n = Math.min(banners.size(), segs.length);

        List<String> cmd = new ArrayList<>(List.of("ffmpeg", "-y", "-loglevel", "error"));
        cmd.addAll(List.of("-i", video.toAbsolutePath().toString()));
        double acc = 0;
        for (int i = 0; i < n; i++) {
            double span = Math.max(segs[i] - 0.1, 0.4) + 0.2;
            cmd.addAll(List.of("-loop", "1", "-framerate", "25",
                    "-itsoffset", String.format("%.3f", acc),
                    "-t", String.format("%.3f", span),
                    "-i", banners.get(i).toAbsolutePath().toString()));
            acc += segs[i];
        }
        StringBuilder fc = new StringBuilder();
        String prev = "[0:v]";
        acc = 0;
        for (int i = 0; i < n; i++) {
            String lbl = "[t" + i + "]";
            double s = acc;
            double e = acc + segs[i];
            fc.append(prev).append('[').append(i + 1).append(":v]overlay=0:")
                    .append(taglineY).append(":enable='between(t,")
                    .append(String.format("%.3f", s)).append(',').append(String.format("%.3f", e))
                    .append(")'").append(lbl).append(';');
            prev = lbl;
            acc = e;
        }
        fc.setLength(fc.length() - 1);
        cmd.addAll(List.of("-filter_complex", fc.toString()));
        cmd.addAll(List.of("-map", prev,
                "-c:v", "libx264", "-preset", "veryfast", "-crf", "23",
                "-pix_fmt", "yuv420p",
                "-y", out.toAbsolutePath().toString()));
        run(cmd, 180);
        return out;
    }

    /** 图片各段时长：基础均分 + 若有 BGM 节拍则把段边界吸附到最近拍子（容差 0.7s） */
    private double[] snappedDurations(int n, double audioDur, List<Double> beats) {
        double perSec = Math.max(audioDur / n, 2.0);
        double[] snaps = new double[n + 1];
        for (int i = 1; i < n; i++) {
            double ideal = i * perSec;
            snaps[i] = ideal;
            if (!beats.isEmpty()) {
                double near = nearestBeat(beats, ideal, 0.7);
                if (near > 0) {
                    snaps[i] = near;
                }
            }
        }
        snaps[n] = audioDur;
        double minSeg = 0.8;
        for (int i = 1; i <= n; i++) {
            double minBound = snaps[i - 1] + minSeg;
            double maxBound = audioDur - (n - i) * minSeg;
            snaps[i] = Math.min(Math.max(snaps[i], minBound), maxBound);
        }
        double[] segs = new double[n];
        for (int i = 0; i < n; i++) {
            segs[i] = snaps[i + 1] - snaps[i];
        }
        return segs;
    }

    private double nearestBeat(List<Double> beats, double ideal, double tol) {
        double best = -1;
        for (double b : beats) {
            if (Math.abs(b - ideal) <= tol) {
                if (best < 0 || Math.abs(b - ideal) < Math.abs(best - ideal)) {
                    best = b;
                }
            }
        }
        return best;
    }

    /** 视频轨：每张图 zoompan 推拉运镜 + 渐入渐出转场，concat 成主视频（无音频） */
    private void buildVideoOnly(List<String> images, double[] segs, Path out) throws Exception {
        int n = images.size();
        List<String> cmd = new ArrayList<>(List.of("ffmpeg", "-y", "-loglevel", "error"));
        for (String img : images) {
            cmd.addAll(List.of("-i", img));
        }
        StringBuilder fc = new StringBuilder();
        for (int i = 0; i < n; i++) {
            double di = Math.max(segs[i], 1.0);
            int frames = Math.max((int) Math.round(di * 25), 2);
            String zoom;
            if (kenBurnsEnabled) {
                if (i % 2 == 0) {
                    // 推近
                    zoom = "zoompan=z='min(zoom+0.0006,1.15)':x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':d=" + frames
                            + ":s=" + W + "x" + H + ":fps=25";
                } else {
                    // 拉远
                    zoom = "zoompan=z='if(eq(on,1),1.15,max(zoom-0.0006,1.0))':x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':d="
                            + frames + ":s=" + W + "x" + H + ":fps=25";
                }
            } else {
                zoom = "scale=" + W + ":" + H + ":force_original_aspect_ratio=increase,crop=" + W + ":" + H
                        + ",setsar=1";
            }
            double fadeD = Math.min(fadeSec, di / 2);
            String fout = String.format("%.3f", Math.max(di - fadeD, 0));
            String fD = String.format("%.3f", fadeD);
            fc.append('[').append(i).append(":v]scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,setsar=1,")
                    .append(zoom)
                    .append(",settb=AVTB,setpts=PTS-STARTPTS,format=yuv420p")
                    .append(",fade=t=in:st=0:d=").append(fD)
                    .append(",fade=t=out:st=").append(fout).append(":d=").append(fD)
                    .append("[v").append(i).append("];");
        }
        for (int i = 0; i < n; i++) {
            fc.append("[v").append(i).append(']');
        }
        fc.append("concat=n=").append(n).append(":v=1:a=0[vout]");
        cmd.addAll(List.of("-filter_complex", fc.toString()));
        cmd.addAll(List.of("-map", "[vout]",
                "-c:v", "libx264", "-preset", "veryfast", "-crf", "23",
                "-pix_fmt", "yuv420p", "-r", "25",
                "-y", out.toAbsolutePath().toString()));
        run(cmd, 240);
    }

    /** 音轨：人声 + BGM（侧链压缩自动避让）+ 钩子音效 + 转场 tick 音效 混合 */
    private void buildMixedAudio(String voicePath, String bgm, double[] segs, Path out) throws Exception {
        List<String> cmd = new ArrayList<>(List.of("ffmpeg", "-y", "-loglevel", "error"));
        cmd.addAll(List.of("-i", voicePath));            // [0] 人声
        boolean hasBgm = StringUtils.hasText(bgm);
        if (hasBgm) {
            cmd.addAll(List.of("-stream_loop", "-1", "-i", bgm)); // [1] BGM（循环覆盖全片）
        }

        // 音效：钩子 ding（固定时间）+ 每个切点 tick
        List<Path> fx = new ArrayList<>();
        List<Double> fxTimes = new ArrayList<>();
        if (sfxEnabled) {
            try {
                Path ding = ensureFx("ding.wav", "0.7*exp(-3*t)*(sin(2*PI*880*t)+0.4*sin(2*PI*1320*t)):d=0.8:s=44100");
                fx.add(ding);
                fxTimes.add(hookDelayMs / 1000.0);
                Path tick = ensureFx("tick.wav", "0.9*exp(-35*t)*sin(2*PI*1800*t):d=0.06:s=44100");
                double acc = 0;
                for (int i = 1; i < segs.length; i++) {
                    acc += segs[i - 1];
                    if (acc > 0.3) {
                        fx.add(tick);
                        fxTimes.add(acc);
                    }
                }
            } catch (Exception e) {
                log.warn("[Render] 音效生成失败，跳过: {}", e.getMessage());
                fx.clear();
                fxTimes.clear();
            }
        }
        int fxStart = 1 + (hasBgm ? 1 : 0);
        for (Path p : fx) {
            cmd.addAll(List.of("-i", p.toAbsolutePath().toString()));
        }

        StringBuilder fc = new StringBuilder();
        fc.append("[0:a]aformat=sample_fmts=fltp:sample_rates=44100:channel_layouts=mono,asplit=2[vo][sc];");
        String cur;
        int curInputs;
        if (hasBgm) {
            fc.append("[1:a]aformat=sample_fmts=fltp:sample_rates=44100:channel_layouts=mono,volume=")
                    .append(bgmVolume).append("[bg];");
            fc.append("[bg][sc]sidechaincompress=threshold=0.05:ratio=6:attack=15:release=250[bgd];");
            cur = "[vo][bgd]";
            curInputs = 2;
        } else {
            cur = "[vo]";
            curInputs = 1;
        }
        if (!fx.isEmpty()) {
            for (int k = 0; k < fx.size(); k++) {
                long ms = Math.max(Math.round(fxTimes.get(k) * 1000), 0);
                double vol = (k == 0) ? hookVolume : tickVolume;
                fc.append('[').append(fxStart + k).append(":a]aformat=sample_fmts=fltp:sample_rates=44100:channel_layouts=mono,adelay=")
                        .append(ms).append(":all=1,volume=").append(vol)
                        .append("[f").append(k).append("];");
                int mixInputs = curInputs + 1;
                fc.append(cur).append("[f").append(k).append("]amix=inputs=").append(mixInputs)
                        .append(":duration=first:normalize=0[m").append(k).append("];");
                cur = "[m" + k + "]";
                curInputs = 1;
            }
        }
        fc.setLength(fc.length() - 1); // 去尾分号

        cmd.addAll(List.of("-filter_complex", fc.toString()));
        cmd.addAll(List.of("-map", cur, "-c:a", "aac", "-b:a", "128k", "-ar", "44100", "-ac", "1",
                "-y", out.toAbsolutePath().toString()));
        run(cmd, 120);
    }

    /** BGM 解析：配置路径存在则用；否则生成 100BPM 演示 BGM（用户可替换为自己的配乐） */
    private String resolveBgm(double audioDur) {
        if (!bgmEnabled) {
            return "";
        }
        if (StringUtils.hasText(bgmPath) && Files.exists(Path.of(bgmPath.trim()))) {
            return bgmPath.trim();
        }
        if (StringUtils.hasText(bgmPath)) {
            log.warn("[BGM] 配置路径不存在({})，自动使用演示 BGM", bgmPath);
        }
        return ensureDemoBgm();
    }

    private String ensureDemoBgm() {
        try {
            Path dir = Path.of("data", "media", "bgm");
            Files.createDirectories(dir);
            Path p = dir.resolve("demo-tension.m4a");
            if (Files.exists(p)) {
                return p.toAbsolutePath().toString();
            }
            // 100BPM 张力节奏：底鼓(每0.6s) + 弱拍嚓 + 低音铺底
            run(List.of("ffmpeg", "-y", "-loglevel", "error",
                    "-f", "lavfi", "-i", "aevalsrc=0.8*exp(-5*mod(t\\,0.6))*sin(2*PI*58*mod(t\\,0.6)):d=60:s=44100",
                    "-f", "lavfi", "-i", "aevalsrc=0.22*exp(-12*mod(t+0.3\\,0.6))*(2*random(0)-1):d=60:s=44100",
                    "-f", "lavfi", "-i", "sine=frequency=110:duration=60",
                    "-filter_complex", "[2]volume=0.12[b];[0][1][b]amix=inputs=3:normalize=0[a]",
                    "-map", "[a]", "-ac", "1", "-ar", "44100", "-c:a", "aac",
                    "-y", p.toAbsolutePath().toString()), 60);
            log.info("[BGM] 演示配乐已生成: {}", p);
            return p.toAbsolutePath().toString();
        } catch (Exception e) {
            log.warn("[BGM] 演示配乐生成失败，本片无 BGM: {}", e.getMessage());
            return "";
        }
    }

    /** 预生成音效 wav（缓存复用） */
    private Path ensureFx(String name, String expr) throws Exception {
        Path dir = Path.of("data", "media", "fx");
        Files.createDirectories(dir);
        Path p = dir.resolve(name);
        if (Files.exists(p)) {
            return p;
        }
        run(List.of("ffmpeg", "-y", "-loglevel", "error",
                "-f", "lavfi", "-i", "aevalsrc=" + expr,
                "-ac", "1", "-ar", "44100", "-c:a", "pcm_s16le",
                "-y", p.toAbsolutePath().toString()), 30);
        return p;
    }

    private void run(List<String> cmd, int timeoutSec) throws Exception {
        log.debug("[Render] 执行: {}", String.join(" ", cmd));
        ProcessBuilder pb = new ProcessBuilder(cmd);
        pb.redirectErrorStream(true);
        Process p = pb.start();
        String out = new String(p.getInputStream().readAllBytes());
        boolean ok = p.waitFor(timeoutSec, TimeUnit.SECONDS);
        if (!ok) {
            p.destroyForcibly();
            throw new IllegalStateException("命令超时: " + String.join(" ", cmd));
        }
        if (p.exitValue() != 0) {
            throw new IllegalStateException("命令失败(" + p.exitValue() + "): " + String.join(" ", cmd) + "\n" + out);
        }
    }
}

package com.th4.edge.decoboon.clue.video.media;

import com.th4.edge.framework.core.annotation.Note;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * macOS 系统语音合成 TTS（真实音频，免云端凭证）。
 * <p>
 * 流程：say -v Tingting 生成 aiff → ffmpeg 转 mp3(44.1k 单声道) → ffprobe 取时长。
 * 语速可通过 voice 配置调整（如 Tingting/婷婷，或自带 rate 参数）。
 */
@Note("系统语音合成")
@Component
public class MacSystemTts implements TtsService {

    private static final Logger log = LoggerFactory.getLogger(MacSystemTts.class);

    private final String voice;

    public MacSystemTts(@Value("${th4.edge.decoboon.video.tts.voice:Tingting}") String voice) {
        this.voice = voice;
    }

    @Override
    public TtsResult generate(String text, Long taskId) {
        try {
            Path dir = Path.of("data", "media", "task-" + taskId);
            Files.createDirectories(dir);
            Path aiff = dir.resolve("voice.aiff");
            Path mp3 = dir.resolve("voice.mp3");

            // 1) macOS say 生成 aiff（真实中文语音）
            run(List.of("say", "-v", voice, "-o", aiff.toAbsolutePath().toString(), text), 60);

            // 2) ffmpeg 转 mp3
            run(List.of("ffmpeg", "-y", "-loglevel", "error",
                    "-i", aiff.toAbsolutePath().toString(),
                    "-ar", "44100", "-ac", "1", "-b:a", "128k",
                    "-y", mp3.toAbsolutePath().toString()), 60);

            // 3) ffprobe 取时长
            double duration = MediaProbe.durationSec(mp3.toAbsolutePath().toString());
            log.info("[TTS] 任务{} 配音完成 voice={} 时长={}s -> {}", taskId, voice, String.format("%.2f", duration), mp3);
            return new TtsResult(mp3.toAbsolutePath().toString(), duration);
        } catch (Exception e) {
            throw new IllegalStateException("TTS 生成失败: " + e.getMessage(), e);
        }
    }

    private void run(List<String> cmd, int timeoutSec) throws Exception {
        log.debug("[TTS] 执行: {}", String.join(" ", cmd));
        ProcessBuilder pb = new ProcessBuilder(cmd);
        pb.redirectErrorStream(true);
        Process p = pb.start();
        String out = new String(p.getInputStream().readAllBytes());
        boolean ok = p.waitFor(timeoutSec, TimeUnit.SECONDS);
        if (!ok) {
            p.destroyForcibly();
            throw new IllegalStateException("命令超时: " + String.join(" ", cmd));
        }
        if (p.exitValue() != 0) {
            throw new IllegalStateException("命令失败(" + p.exitValue() + "): " + String.join(" ", cmd) + "\n" + StringUtils.trimWhitespace(out));
        }
    }
}

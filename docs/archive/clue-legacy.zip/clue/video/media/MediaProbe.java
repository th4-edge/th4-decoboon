package com.th4.edge.decoboon.clue.video.media;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.TimeUnit;

/**
 * 媒体探测工具：基于 ffprobe 获取音视频时长（秒）。
 */
public final class MediaProbe {

    private static final Logger log = LoggerFactory.getLogger(MediaProbe.class);

    private MediaProbe() {
    }

    /** 返回媒体时长（秒），失败返回 -1 */
    public static double durationSec(String mediaPath) {
        try {
            ProcessBuilder pb = new ProcessBuilder("ffprobe", "-v", "error",
                    "-show_entries", "format=duration", "-of", "default=noprint_wrappers=1:nokey=1",
                    mediaPath);
            pb.redirectErrorStream(true);
            Process p = pb.start();
            String out = new String(p.getInputStream().readAllBytes()).trim();
            if (!p.waitFor(20, TimeUnit.SECONDS)) {
                p.destroyForcibly();
                return -1;
            }
            return Double.parseDouble(out);
        } catch (Exception e) {
            log.warn("[Probe] 时长探测失败 {}: {}", mediaPath, e.getMessage());
            return -1;
        }
    }
}

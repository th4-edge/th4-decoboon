package com.th4.edge.decoboon.clue.video.media;

import com.th4.edge.framework.core.annotation.Note;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

/**
 * 配音 TTS 路由：按配置 {@code th4.edge.decoboon.video.tts.provider} 选择主实现。
 * <ul>
 *   <li>provider=aliyun：优先阿里云 NLS 语音合成；鉴权缺失或调用失败自动降级 macOS 系统 TTS（不阻断流水线）。</li>
 *   <li>provider=system：使用 macOS 系统语音合成（默认兜底）。</li>
 * </ul>
 * 流水线统一注入本路由，无需感知具体实现。
 */
@Note("TTS 路由")
@Primary
@Component
public class RoutingTtsService implements TtsService {

    private static final Logger log = LoggerFactory.getLogger(RoutingTtsService.class);

    private final MacSystemTts systemTts;
    private final AliyunNlsTts aliyunTts;
    private final String provider;

    public RoutingTtsService(MacSystemTts systemTts, AliyunNlsTts aliyunTts,
                             @Value("${th4.edge.decoboon.video.tts.provider:system}") String provider) {
        this.systemTts = systemTts;
        this.aliyunTts = aliyunTts;
        this.provider = provider;
        log.info("[TTS] 路由初始化 provider={}", provider);
    }

    @Override
    public TtsResult generate(String text, Long taskId) {
        if ("aliyun".equalsIgnoreCase(provider)) {
            try {
                return aliyunTts.generate(text, taskId);
            } catch (Exception e) {
                log.warn("[TTS] 阿里云合成失败，降级系统 TTS: {}", e.getMessage());
            }
        }
        return systemTts.generate(text, taskId);
    }
}

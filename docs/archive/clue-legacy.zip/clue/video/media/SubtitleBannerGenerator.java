package com.th4.edge.decoboon.clue.video.media;

import com.th4.edge.framework.core.annotation.Note;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.imageio.ImageIO;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/**
 * 硬字幕条生成：为每条字幕生成一张透明 PNG（白字 + 黑色描边），
 * 由 FFmpeg overlay 按时间窗叠加到画面像素，任何播放器都直接可见（无需 libass）。
 */
@Note("硬字幕条生成")
@Component
public class SubtitleBannerGenerator {

    private static final Logger log = LoggerFactory.getLogger(SubtitleBannerGenerator.class);
    private static final int W = 720;
    private static final int H = 110;

    public List<Path> generateAll(List<SubtitleGenerator.Cue> cues, Long taskId) {
        List<Path> out = new ArrayList<>();
        try {
            Path dir = Path.of("data", "media", "task-" + taskId, "subs");
            Files.createDirectories(dir);
            for (int i = 0; i < cues.size(); i++) {
                Path p = dir.resolve("cue-" + (i + 1) + ".png");
                draw(cues.get(i).text(), p.toFile());
                out.add(p.toAbsolutePath());
            }
            log.info("[SubBanner] 任务{} 硬字幕条 {} 张 -> {}", taskId, cues.size(), dir);
        } catch (Exception e) {
            throw new IllegalStateException("硬字幕条生成失败: " + e.getMessage(), e);
        }
        return out;
    }

    private void draw(String text, File target) throws Exception {
        BufferedImage img = new BufferedImage(W, H, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = img.createGraphics();
        try {
            g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
            Font font = new Font("PingFang SC", Font.BOLD, 46);
            g.setFont(font);
            FontMetrics fm = g.getFontMetrics();
            int x = (W - fm.stringWidth(text)) / 2;
            int y = (H - fm.getHeight()) / 2 + fm.getAscent();
            // 黑色描边（8 方向偏移），保证任何背景下可读
            g.setColor(new Color(0, 0, 0, 200));
            for (int dx = -3; dx <= 3; dx++) {
                for (int dy = -3; dy <= 3; dy++) {
                    if (dx != 0 || dy != 0) {
                        g.drawString(text, x + dx, y + dy);
                    }
                }
            }
            // 白字
            g.setColor(Color.WHITE);
            g.drawString(text, x, y);
        } finally {
            g.dispose();
        }
        ImageIO.write(img, "png", target);
    }
}

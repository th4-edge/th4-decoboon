package com.th4.edge.decoboon.clue.video.media;

import com.th4.edge.framework.core.annotation.Note;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/**
 * 字幕生成：把发布文案切成字幕条，按配音时长均分时间轴，输出标准 SRT。
 * <p>
 * 规则：按句/行拆分后按约 3 秒/条合并（保证可读），时间轴与音频时长等比分配；
 * 提供 parseSrt 把 SRT 解析回 cue 列表，供硬字幕烧录复用同一时间轴。
 */
@Note("字幕生成")
@Component
public class SubtitleGenerator {

    private static final Logger log = LoggerFactory.getLogger(SubtitleGenerator.class);
    private static final int MAX_CUE_CHARS = 18;
    private static final double TARGET_SECONDS_PER_CUE = 3.0;

    /** 一条字幕：毫秒时间窗 + 文本 */
    public record Cue(long startMs, long endMs, String text) {
    }

    public String generate(String content, double durationSec, Long taskId) {
        try {
            List<String> texts = buildCueTexts(content, durationSec);
            if (texts.isEmpty()) {
                texts.add("装修不踩坑");
            }
            Path dir = Path.of("data", "media", "task-" + taskId);
            Files.createDirectories(dir);
            Path srt = dir.resolve("subtitle.srt");

            StringBuilder sb = new StringBuilder();
            double per = Math.max(durationSec / texts.size(), 1.2);
            double t = 0;
            for (int i = 0; i < texts.size(); i++) {
                sb.append(i + 1).append('\n');
                sb.append(fmt(t)).append(" --> ").append(fmt(Math.min(t + per, durationSec))).append('\n');
                sb.append(texts.get(i)).append("\n\n");
                t += per;
            }
            Files.writeString(srt, sb.toString(), StandardCharsets.UTF_8);
            log.info("[Subtitle] 任务{} 字幕{}条 时长{}s -> {}", taskId, texts.size(), String.format("%.1f", durationSec), srt);
            return srt.toAbsolutePath().toString();
        } catch (IOException e) {
            throw new IllegalStateException("字幕生成失败: " + e.getMessage(), e);
        }
    }

    /** 解析 SRT 文件为 cue 列表（毫秒时间窗），供硬字幕 overlay 使用 */
    public List<Cue> parseSrt(String srtPath) {
        List<Cue> cues = new ArrayList<>();
        try {
            List<String> lines = Files.readAllLines(Path.of(srtPath), StandardCharsets.UTF_8);
            int i = 0;
            while (i < lines.size()) {
                String line = lines.get(i).trim();
                if (line.isEmpty()) {
                    i++;
                    continue;
                }
                // 序号行
                if (line.matches("\\d+")) {
                    i++;
                    // 时间行
                    if (i < lines.size() && lines.get(i).contains("-->")) {
                        long[] range = parseTimeRange(lines.get(i));
                        i++;
                        StringBuilder text = new StringBuilder();
                        while (i < lines.size() && !lines.get(i).trim().isEmpty()) {
                            text.append(lines.get(i).trim());
                            i++;
                        }
                        if (text.length() > 0) {
                            cues.add(new Cue(range[0], range[1], text.toString()));
                        }
                    }
                } else {
                    i++;
                }
            }
        } catch (IOException e) {
            log.warn("[Subtitle] SRT 解析失败: {}", e.getMessage());
        }
        return cues;
    }

    private long[] parseTimeRange(String timeLine) {
        long[] range = new long[2];
        String[] parts = timeLine.split("-->");
        if (parts.length == 2) {
            range[0] = toMs(parts[0].trim());
            range[1] = toMs(parts[1].trim());
        }
        return range;
    }

    private long toMs(String t) {
        try {
            String[] hms = t.split(":");
            int h = Integer.parseInt(hms[0]);
            int m = Integer.parseInt(hms[1]);
            String[] sms = hms[2].split(",");
            int s = Integer.parseInt(sms[0]);
            int ms = Integer.parseInt(sms[1]);
            return ((long) h * 3600 + m * 60 + s) * 1000L + ms;
        } catch (Exception e) {
            return 0;
        }
    }

    /** 切条并按约 3 秒/条合并，目标条数 ≈ duration/3 */
    private List<String> buildCueTexts(String content, double durationSec) {
        List<String> raw = new ArrayList<>();
        for (String line : content.split("\r?\n")) {
            if (line.isBlank()) {
                continue;
            }
            if (line.contains("标题：")) {
                raw.add(line.replace("标题：", "").trim());
                continue;
            }
            String[] parts = line.split("(?<=[，。！？、；])");
            for (String p : parts) {
                if (!p.isBlank()) {
                    raw.add(p.trim());
                }
            }
        }
        int target = Math.max(1, (int) Math.ceil(durationSec / TARGET_SECONDS_PER_CUE));
        List<String> merged = new ArrayList<>();
        StringBuilder buf = new StringBuilder();
        for (String cue : raw) {
            if (buf.length() + cue.length() > MAX_CUE_CHARS && buf.length() > 0) {
                merged.add(buf.toString());
                buf.setLength(0);
            }
            buf.append(cue);
        }
        if (buf.length() > 0) {
            merged.add(buf.toString());
        }
        // 仍过多则再按目标条数合并（保证每条约 3s 可读）
        while (merged.size() > target && target > 0) {
            List<String> next = new ArrayList<>();
            int per = (int) Math.ceil(merged.size() / (double) target);
            for (int i = 0; i < merged.size(); i += per) {
                next.add(String.join("", merged.subList(i, Math.min(i + per, merged.size()))));
            }
            merged = next;
        }
        return merged;
    }

    private String fmt(double sec) {
        int h = (int) (sec / 3600);
        int m = (int) (sec % 3600 / 60);
        int s = (int) (sec % 60);
        int ms = (int) ((sec - (int) sec) * 1000);
        return String.format("%02d:%02d:%02d,%03d", h, m, s, ms);
    }
}

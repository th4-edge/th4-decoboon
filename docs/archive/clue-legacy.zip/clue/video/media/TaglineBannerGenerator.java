package com.th4.edge.decoboon.clue.video.media;

import com.th4.edge.framework.core.annotation.Note;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.imageio.ImageIO;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/**
 * 分镜标题（花字）条生成：为每张素材生成一张大号关键词 PNG
 * （白字 + 黑色粗描边 + 半透明深色圆角底块），由 FFmpeg overlay 按每段素材时间窗
 * 叠加到画面中上部，让屏幕上的大字与当前画面内容对应。
 */
@Note("花字条生成")
@Component
public class TaglineBannerGenerator {

    private static final Logger log = LoggerFactory.getLogger(TaglineBannerGenerator.class);
    private static final int W = 720;
    private static final int H = 220;

    public List<Path> generateAll(List<String> taglines, Long taskId) {
        List<Path> out = new ArrayList<>();
        try {
            Path dir = Path.of("data", "media", "task-" + taskId, "taglines");
            Files.createDirectories(dir);
            for (int i = 0; i < taglines.size(); i++) {
                Path p = dir.resolve("tag-" + (i + 1) + ".png");
                draw(taglines.get(i), p.toFile());
                out.add(p.toAbsolutePath());
            }
            log.info("[TagBanner] 任务{} 花字条 {} 张 -> {}", taskId, taglines.size(), dir);
        } catch (Exception e) {
            throw new IllegalStateException("花字条生成失败: " + e.getMessage(), e);
        }
        return out;
    }

    private void draw(String text, File target) throws Exception {
        BufferedImage img = new BufferedImage(W, H, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = img.createGraphics();
        try {
            g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
            Font font = new Font("PingFang SC", Font.BOLD, 92);
            g.setFont(font);
            FontMetrics fm = g.getFontMetrics();
            int textW = fm.stringWidth(text);
            int textH = fm.getHeight();
            int x = (W - textW) / 2;
            int y = (H - textH) / 2 + fm.getAscent();

            // 半透明深色圆角底块（两侧留白），保证任何背景下可读
            int padX = 36;
            int padY = 22;
            int bw = textW + padX * 2;
            int bh = textH + padY * 2;
            int bx = x - padX;
            int by = y - fm.getAscent() - padY;
            g.setColor(new Color(0, 0, 0, 120));
            g.fill(new RoundRectangle2D.Float(bx, by, bw, bh, 36, 36));

            // 黑色粗描边（8 方向偏移更大，突出"土味大标题"感）
            g.setColor(new Color(0, 0, 0, 235));
            for (int dx = -5; dx <= 5; dx += 2) {
                for (int dy = -5; dy <= 5; dy += 2) {
                    if (dx != 0 || dy != 0) {
                        g.drawString(text, x + dx, y + dy);
                    }
                }
            }
            // 白字
            g.setColor(Color.WHITE);
            g.drawString(text, x, y);
        } finally {
            g.dispose();
        }
        ImageIO.write(img, "png", target);
    }
}

package com.th4.edge.decoboon.clue.video.media;

/**
 * 配音（TTS）服务抽象：把发布文案转成可合片的配音音频。
 * <p>
 * 当前实现：macOS 系统语音合成（say + Apple 中文语音 Tingting），真实生成音频文件、免凭证；
 * 生产环境（Linux 服务器）可替换为火山引擎/阿里云 TTS 实现，接口不变。
 */
public interface TtsService {

    /**
     * 生成配音音频。
     *
     * @param text   配音文本（口播文案）
     * @param taskId 生成任务 ID（用于产物目录）
     * @return 音频路径 + 时长
     */
    TtsResult generate(String text, Long taskId);

    /** 配音产物 */
    record TtsResult(String audioPath, double durationSec) {
    }
}

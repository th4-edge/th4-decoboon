package com.th4.edge.decoboon.clue.video.model;

import com.th4.edge.decoboon.clue.company.model.Employee;
import com.th4.edge.framework.core.annotation.Description;
import com.th4.edge.framework.core.annotation.Note;
import com.th4.edge.framework.data.date.model.DateTime;
import com.th4.edge.framework.data.jpa.annotation.Model;
import com.th4.edge.framework.data.jpa.preset.annotation.DataItem;
import com.th4.edge.framework.data.jpa.preset.annotation.DataPreset;
import com.th4.edge.framework.data.model.AbstractModel;
import com.th4.edge.framework.data.model.prepare.annotation.CreateTime;
import com.th4.edge.framework.data.model.prepare.annotation.UpdateTime;
import jakarta.persistence.AttributeOverride;
import jakarta.persistence.AttributeOverrides;
import jakarta.persistence.Column;
import jakarta.persistence.Embedded;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

/**
 * 业务员/门店风格画像（P2b）：把"个性化"从话术轮换推进到"按人生成"。
 * 每个业务员一套风格档 + 叙事结构偏好 + 常做场景，生成文案时注入，
 * 话术库命中与 LLM 生成均按画像适配；未配置时随机抽结构保差异化。
 */
@Note("风格画像")
@Description("业务员/门店的内容风格画像：风格档、叙事结构偏好、常做场景")
@Model
@Entity
@Table(name = "db_clue_style_profile")
@DataPreset({
        @DataItem({"1", "土味", "Suspense", "水电验收", "TRUE"})
})
public class StyleProfile extends AbstractModel {

    @Note("画像索引")
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long profileId;

    @Note("业务员")
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "emp_id", nullable = false)
    private Employee emp;

    @Note("风格档（土味/专业/唠嗑/悬念/权威）")
    @Column(nullable = false, length = 32)
    private String style;

    @Note("首选叙事结构（ScriptStructure 枚举名）")
    @Column(length = 32)
    private String structurePref;

    @Note("常做场景（逗号分隔，如 水电验收,瓦工贴砖）")
    @Column(length = 128)
    private String sceneFocus;

    @Note("启用")
    @Column(nullable = false)
    private Boolean enabled = Boolean.TRUE;

    @Note("创建时间")
    @CreateTime
    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "dateTime", column = @Column(name = "create_dateTime")),
            @AttributeOverride(name = "date", column = @Column(name = "create_date")),
            @AttributeOverride(name = "time", column = @Column(name = "create_time")),
            @AttributeOverride(name = "year", column = @Column(name = "create_year")),
            @AttributeOverride(name = "month", column = @Column(name = "create_month")),
            @AttributeOverride(name = "day", column = @Column(name = "create_day")),
            @AttributeOverride(name = "hour", column = @Column(name = "create_hour")),
            @AttributeOverride(name = "minute", column = @Column(name = "create_minute")),
            @AttributeOverride(name = "second", column = @Column(name = "create_second")),
            @AttributeOverride(name = "week", column = @Column(name = "create_week")),
    })
    private DateTime createTime;

    @Note("更新时间")
    @UpdateTime
    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "dateTime", column = @Column(name = "update_dateTime")),
            @AttributeOverride(name = "date", column = @Column(name = "update_date")),
            @AttributeOverride(name = "time", column = @Column(name = "update_time")),
            @AttributeOverride(name = "year", column = @Column(name = "update_year")),
            @AttributeOverride(name = "month", column = @Column(name = "update_month")),
            @AttributeOverride(name = "day", column = @Column(name = "update_day")),
            @AttributeOverride(name = "hour", column = @Column(name = "update_hour")),
            @AttributeOverride(name = "minute", column = @Column(name = "update_minute")),
            @AttributeOverride(name = "second", column = @Column(name = "update_second")),
            @AttributeOverride(name = "week", column = @Column(name = "update_week")),
    })
    private DateTime updateTime;

    public Long getProfileId() {
        return profileId;
    }

    public void setProfileId(Long profileId) {
        this.profileId = profileId;
    }

    public Employee getEmp() {
        return emp;
    }

    public void setEmp(Employee emp) {
        this.emp = emp;
    }

    public String getStyle() {
        return style;
    }

    public void setStyle(String style) {
        this.style = style;
    }

    public String getStructurePref() {
        return structurePref;
    }

    public void setStructurePref(String structurePref) {
        this.structurePref = structurePref;
    }

    public String getSceneFocus() {
        return sceneFocus;
    }

    public void setSceneFocus(String sceneFocus) {
        this.sceneFocus = sceneFocus;
    }

    public Boolean getEnabled() {
        return enabled;
    }

    public void setEnabled(Boolean enabled) {
        this.enabled = enabled;
    }

    public DateTime getCreateTime() {
        return createTime;
    }

    public void setCreateTime(DateTime createTime) {
        this.createTime = createTime;
    }

    public DateTime getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(DateTime updateTime) {
        this.updateTime = updateTime;
    }
}

package com.th4.edge.decoboon.clue.video.model;
import jakarta.persistence.*;

import com.th4.edge.decoboon.clue.video.configure.TemplateType;
import com.th4.edge.framework.core.annotation.Description;
import com.th4.edge.framework.core.annotation.Note;
import com.th4.edge.framework.data.date.model.DateTime;
import com.th4.edge.framework.data.jpa.annotation.Model;
import com.th4.edge.framework.data.jpa.preset.annotation.DataItem;
import com.th4.edge.framework.data.jpa.preset.annotation.DataPreset;
import com.th4.edge.framework.data.model.AbstractModel;
import com.th4.edge.framework.data.model.prepare.annotation.CreateTime;
import com.th4.edge.framework.data.model.prepare.annotation.UpdateTime;

@Note("模版")
@Description("业务员选用的内容模板：工地实拍/避坑干货/价格透明/完工案例/客户证言")
@Model
@Entity
@Table(name = "db_clue_template")
@DataPreset({
        @DataItem({"SiteShoot", "工地实拍",
                "[\"水电验收不注意这3点，入住后返工花3万\",\"装修水电改造，90%的人都被坑在这\",\"我家水电这样验收，师傅说遇到懂行的了\"]",
                "你是装修工地口播写手，围绕工地实拍图片，用直接、接地气的口吻讲施工进度与细节，末尾引导评论咨询。",
                "大字幕+黄色高亮关键词", "tension_drum", "公司Logo+电话", "5", "TRUE"}),
        @DataItem({"AvoidPit", "避坑干货",
                "[\"装修不踩坑，这3个细节一定要盯住\",\"老师傅不会主动告诉你的装修坑\",\"我家踩过的坑，希望你绕开\"]",
                "你是装修避坑专家，结合实拍图讲 3 个关键避坑点，语气像说真话的老朋友，敢说得罪人的话。",
                "大字幕+黄色高亮关键词", "tension_drum", "公司Logo+电话", "5", "TRUE"}),
        @DataItem({"Price", "价格透明",
                "[\"100平硬装真实要花多少？我帮你算笔账\",\"装修报价单里的猫腻，一篇讲透\",\"你家装修预算到底该给多少\"]",
                "你是装修造价师，结合实拍图把价格讲透明，给出真实区间，结尾留电话引导量房。",
                "大字幕+黄色高亮关键词", "tension_drum", "公司Logo+电话", "5", "TRUE"}),
        @DataItem({"FinishedCase", "完工案例",
                "[\"89平完工实拍，全屋细节一次看够\",\"这套完工案例，业主说很满意\",\"同户型照着装，少花冤枉钱\"]",
                "你是装修案例讲解员，用完工实拍图讲户型亮点与造价，语气像晒成果的邻居。",
                "大字幕+黄色高亮关键词", "relax_bgm", "公司Logo+电话", "5", "TRUE"}),
        @DataItem({"CustomerProof", "客户证言",
                "[\"客户怎么说我们？听听真实评价\",\"从量房到入住，客户的一句话很关键\",\"转介绍靠什么？靠口碑\"]",
                "你是口碑记录者，用客户证言素材转述真实评价，语气真诚，引导转介绍。",
                "大字幕+黄色高亮关键词", "relax_bgm", "公司Logo+电话", "5", "TRUE"})
})
public class Template extends AbstractModel {

    @Note("模版索引")
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long tempId;

    @Note("模板类型")
    @Column(nullable = false, length = 32)
    private TemplateType type;

    @Note("模板名称")
    @Column(nullable = false, length = 64)
    private String name;

    @Note("话题钩子（候选文案，供业务员勾选）")
    @Column(length = 1024)
    private String hooks;

    @Note("文案提示词（喂给 Agent 的生成指令模板）")
    @Lob
    private String scriptPrompt;

    @Note("字幕样式")
    @Column(length = 128)
    private String subtitleStyle;

    @Note("BGM 标识")
    @Column(length = 64)
    private String bgmCode;

    @Note("尾卡模板")
    @Column(length = 256)
    private String endCard;

    @Note("上传图片数量限制")
    @Column(nullable = false)
    private Integer imageLimit = 5;

    @Note("启用")
    @Column(nullable = false)
    private Boolean enabled = Boolean.TRUE;

    @Note("创建时间")
    @CreateTime
    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name="dateTime", column=@Column(name="create_dateTime")),
            @AttributeOverride(name="date", column=@Column(name="create_date")),
            @AttributeOverride(name="time", column=@Column(name="create_time")),
            @AttributeOverride(name="year", column=@Column(name="create_year")),
            @AttributeOverride(name="month", column=@Column(name="create_month")),
            @AttributeOverride(name="day", column=@Column(name="create_day")),
            @AttributeOverride(name="hour", column=@Column(name="create_hour")),
            @AttributeOverride(name="minute", column=@Column(name="create_minute")),
            @AttributeOverride(name="second", column=@Column(name="create_second")),
            @AttributeOverride(name="week", column=@Column(name="create_week")),
        })
    private DateTime createTime;

    @Note("更新时间")
    @UpdateTime
    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name="dateTime", column=@Column(name="update_dateTime")),
            @AttributeOverride(name="date", column=@Column(name="update_date")),
            @AttributeOverride(name="time", column=@Column(name="update_time")),
            @AttributeOverride(name="year", column=@Column(name="update_year")),
            @AttributeOverride(name="month", column=@Column(name="update_month")),
            @AttributeOverride(name="day", column=@Column(name="update_day")),
            @AttributeOverride(name="hour", column=@Column(name="update_hour")),
            @AttributeOverride(name="minute", column=@Column(name="update_minute")),
            @AttributeOverride(name="second", column=@Column(name="update_second")),
            @AttributeOverride(name="week", column=@Column(name="update_week")),
        })
    private DateTime updateTime;

    public Long getTempId() {
        return tempId;
    }

    public void setTempId(Long tempId) {
        this.tempId = tempId;
    }

    public TemplateType getType() {
        return type;
    }

    public void setType(TemplateType type) {
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getHooks() {
        return hooks;
    }

    public void setHooks(String hooks) {
        this.hooks = hooks;
    }

    public String getScriptPrompt() {
        return scriptPrompt;
    }

    public void setScriptPrompt(String scriptPrompt) {
        this.scriptPrompt = scriptPrompt;
    }

    public String getSubtitleStyle() {
        return subtitleStyle;
    }

    public void setSubtitleStyle(String subtitleStyle) {
        this.subtitleStyle = subtitleStyle;
    }

    public String getBgmCode() {
        return bgmCode;
    }

    public void setBgmCode(String bgmCode) {
        this.bgmCode = bgmCode;
    }

    public String getEndCard() {
        return endCard;
    }

    public void setEndCard(String endCard) {
        this.endCard = endCard;
    }

    public Integer getImageLimit() {
        return imageLimit;
    }

    public void setImageLimit(Integer imageLimit) {
        this.imageLimit = imageLimit;
    }

    public Boolean getEnabled() {
        return enabled;
    }

    public void setEnabled(Boolean enabled) {
        this.enabled = enabled;
    }

    public DateTime getCreateTime() {
        return createTime;
    }

    public void setCreateTime(DateTime createTime) {
        this.createTime = createTime;
    }

    public DateTime getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(DateTime updateTime) {
        this.updateTime = updateTime;
    }
}

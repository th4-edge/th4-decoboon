package com.th4.edge.decoboon.clue.video.model;
import jakarta.persistence.AttributeOverride;
import jakarta.persistence.AttributeOverrides;
import jakarta.persistence.Embedded;

import com.th4.edge.decoboon.clue.company.model.Employee;
import com.th4.edge.decoboon.clue.video.configure.PublishChannel;
import com.th4.edge.decoboon.clue.video.configure.VideoState;
import com.th4.edge.framework.core.annotation.Description;
import com.th4.edge.framework.core.annotation.Note;
import com.th4.edge.framework.core.annotation.Unit;
import com.th4.edge.framework.data.date.model.DateTime;
import com.th4.edge.framework.data.jpa.annotation.Model;
import com.th4.edge.framework.data.jpa.keyword.annotation.Keyword;
import com.th4.edge.framework.data.model.AbstractModel;
import com.th4.edge.framework.data.model.prepare.annotation.CreateTime;
import com.th4.edge.framework.data.model.prepare.annotation.UpdateTime;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Note("短视频")
@Description("用于发布抖音引流的种草视频")
@Model
@Entity
@Table(name = "db_clue_video")
public class Video extends AbstractModel {

    @Note("视频索引")
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long videoId;

    @Note("所属业务员")
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "emp_id", nullable = false)
    private Employee emp;

    @Note("所属模板")
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "temp_id")
    private Template template;

    @Note("封面图")
    @Column(length = 512)
    private String cover;

    @Note("视频文件地址")
    @Column(length = 512)
    private String url;

    @Note("大小")
    @Unit("MB")
    @Column
    private Long size;

    @Note("时长")
    @Unit("秒")
    @Column
    private Long duration;

    @Note("标题")
    @Keyword
    @Column(length = 128)
    private String title;

    @Note("状态")
    @Column(nullable = false, length = 16)
    private VideoState state = VideoState.Draft;

    @Note("发布渠道")
    @Column(length = 16)
    private PublishChannel channel;

    @Note("是否已上架抖音平台（独立于 VideoState.Published 渲染完成状态，表示实际已发布到抖音）")
    @Column(nullable = false)
    private Boolean published = Boolean.FALSE;

    @Note("创建时间")
    @CreateTime
    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name="dateTime", column=@Column(name="create_dateTime")),
            @AttributeOverride(name="date", column=@Column(name="create_date")),
            @AttributeOverride(name="time", column=@Column(name="create_time")),
            @AttributeOverride(name="year", column=@Column(name="create_year")),
            @AttributeOverride(name="month", column=@Column(name="create_month")),
            @AttributeOverride(name="day", column=@Column(name="create_day")),
            @AttributeOverride(name="hour", column=@Column(name="create_hour")),
            @AttributeOverride(name="minute", column=@Column(name="create_minute")),
            @AttributeOverride(name="second", column=@Column(name="create_second")),
            @AttributeOverride(name="week", column=@Column(name="create_week")),
        })
    private DateTime createTime;

    @Note("更新时间")
    @UpdateTime
    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name="dateTime", column=@Column(name="update_dateTime")),
            @AttributeOverride(name="date", column=@Column(name="update_date")),
            @AttributeOverride(name="time", column=@Column(name="update_time")),
            @AttributeOverride(name="year", column=@Column(name="update_year")),
            @AttributeOverride(name="month", column=@Column(name="update_month")),
            @AttributeOverride(name="day", column=@Column(name="update_day")),
            @AttributeOverride(name="hour", column=@Column(name="update_hour")),
            @AttributeOverride(name="minute", column=@Column(name="update_minute")),
            @AttributeOverride(name="second", column=@Column(name="update_second")),
            @AttributeOverride(name="week", column=@Column(name="update_week")),
        })
    private DateTime updateTime;

    public Long getVideoId() {
        return videoId;
    }

    public void setVideoId(Long videoId) {
        this.videoId = videoId;
    }

    public Employee getEmp() {
        return emp;
    }

    public void setEmp(Employee emp) {
        this.emp = emp;
    }

    public Template getTemplate() {
        return template;
    }

    public void setTemplate(Template template) {
        this.template = template;
    }

    public String getCover() {
        return cover;
    }

    public void setCover(String cover) {
        this.cover = cover;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public Long getSize() {
        return size;
    }

    public void setSize(Long size) {
        this.size = size;
    }

    public Long getDuration() {
        return duration;
    }

    public void setDuration(Long duration) {
        this.duration = duration;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public VideoState getState() {
        return state;
    }

    public void setState(VideoState state) {
        this.state = state;
    }

    public PublishChannel getChannel() {
        return channel;
    }

    public void setChannel(PublishChannel channel) {
        this.channel = channel;
    }

    public Boolean getPublished() {
        return published;
    }

    public void setPublished(Boolean published) {
        this.published = published;
    }

    public DateTime getCreateTime() {
        return createTime;
    }

    public void setCreateTime(DateTime createTime) {
        this.createTime = createTime;
    }

    public DateTime getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(DateTime updateTime) {
        this.updateTime = updateTime;
    }
}

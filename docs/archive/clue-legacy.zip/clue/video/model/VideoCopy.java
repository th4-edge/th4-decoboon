package com.th4.edge.decoboon.clue.video.model;
import jakarta.persistence.AttributeOverride;
import jakarta.persistence.AttributeOverrides;
import jakarta.persistence.Embedded;

import com.th4.edge.framework.core.annotation.Description;
import com.th4.edge.framework.core.annotation.Note;
import com.th4.edge.framework.data.date.model.DateTime;
import com.th4.edge.framework.data.jpa.annotation.Model;
import com.th4.edge.framework.data.model.AbstractModel;
import com.th4.edge.framework.data.model.prepare.annotation.CreateTime;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Note("视频文案")
@Description("一条视频对应一段可复制发布的抖音文案")
@Model
@Entity
@Table(name = "db_clue_video_copy")
public class VideoCopy extends AbstractModel {

    @Note("文案索引")
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long copyId;

    @Note("视频")
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "video_id", nullable = false)
    private Video video;

    @Note("发布文案（业务员复制到抖音）")
    @Column(nullable = false, length = 2048)
    private String content;

    @Note("话题标签")
    @Column(length = 512)
    private String hashtags;

    @Note("定位建议")
    @Column(length = 128)
    private String locationTip;

    @Note("创建时间")
    @CreateTime
    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name="dateTime", column=@Column(name="create_dateTime")),
            @AttributeOverride(name="date", column=@Column(name="create_date")),
            @AttributeOverride(name="time", column=@Column(name="create_time")),
            @AttributeOverride(name="year", column=@Column(name="create_year")),
            @AttributeOverride(name="month", column=@Column(name="create_month")),
            @AttributeOverride(name="day", column=@Column(name="create_day")),
            @AttributeOverride(name="hour", column=@Column(name="create_hour")),
            @AttributeOverride(name="minute", column=@Column(name="create_minute")),
            @AttributeOverride(name="second", column=@Column(name="create_second")),
            @AttributeOverride(name="week", column=@Column(name="create_week")),
        })
    private DateTime createTime;

    public Long getCopyId() {
        return copyId;
    }

    public void setCopyId(Long copyId) {
        this.copyId = copyId;
    }

    public Video getVideo() {
        return video;
    }

    public void setVideo(Video video) {
        this.video = video;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getHashtags() {
        return hashtags;
    }

    public void setHashtags(String hashtags) {
        this.hashtags = hashtags;
    }

    public String getLocationTip() {
        return locationTip;
    }

    public void setLocationTip(String locationTip) {
        this.locationTip = locationTip;
    }

    public DateTime getCreateTime() {
        return createTime;
    }

    public void setCreateTime(DateTime createTime) {
        this.createTime = createTime;
    }
}

package com.th4.edge.decoboon.clue.video.model;

import com.th4.edge.decoboon.clue.video.configure.ScriptScene;
import com.th4.edge.framework.core.annotation.Description;
import com.th4.edge.framework.core.annotation.Note;
import com.th4.edge.framework.data.date.model.DateTime;
import com.th4.edge.framework.data.jpa.annotation.Model;
import com.th4.edge.framework.data.jpa.keyword.annotation.Keyword;
import com.th4.edge.framework.data.jpa.preset.annotation.DataItem;
import com.th4.edge.framework.data.jpa.preset.annotation.DataPreset;
import com.th4.edge.framework.data.model.AbstractModel;
import com.th4.edge.framework.data.model.prepare.annotation.CreateTime;
import com.th4.edge.framework.data.model.prepare.annotation.UpdateTime;
import jakarta.persistence.AttributeOverride;
import jakarta.persistence.AttributeOverrides;
import jakarta.persistence.Column;
import jakarta.persistence.Embedded;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/**
 * 话术库（P2a）：沉淀"已验证/可复用"的口播话术，生成前按场景命中直出（0 LLM 费、稳定、可轮换防同质化），
 * 未命中时 LLM 新生成的话术也会自动入库，库随使用持续增长。
 */
@Note("话术库")
@Description("按场景沉淀的可复用口播话术，命中即直出，未命中生成后自动入库")
@Model
@Entity
@Table(name = "db_clue_video_script")
@DataPreset({
        // ① 对比式：先问值不值
        @DataItem({"WaterElectric", "土味",
                "水电验收不注意这3点，入住后返工花3万",
                "水电这活到底值不值那个工钱，验收光看干得漂不漂亮没用，得抠细节。头一拨，进屋先看线管走得整不整，强弱电分开走没，墙根那道绿防水是不是从头刷到尾，这才是少返工的关键。再蹲到地上看水管，竖着那根，封口拿绿胶带压住、水泥满浆糊死，才算堵住了渗漏的缝。绕墙角再扫一圈，红管白管靠边排得顺顺当当，不来回穿插打架，出了毛病才找得着。你家水电验收够这个标吗？评论区留户型，我免费帮你过一遍。",
                "线管,防水,封口,接头,水管", "0", "0", "TRUE"}),
        // ② 故事式：我当年踩坑
        @DataItem({"WaterElectric", "土味",
                "我家水电验收吃过大亏，这3处你千万别漏",
                "说个真事，我当年装第一套房，水电验收站那看了五分钟水表就签字了。住进去第二年，墙角渗水把木地板泡了，一查是管子封口没做严实，返工花了小两万。从那以后我盯工地就三处：一管线管走得齐不齐，二看防水刷没刷到位，三蹲下来看水管封口是不是水泥咬死。这三处盯着了，后期省的是大钱。你家装修到水电没？评论区发张现场照，我帮你看看有没有要返工的地方。",
                "线管,防水,封口,水管,渗水", "0", "0", "TRUE"}),
        // ③ 清单喊话式：师傅收工别急着走
        @DataItem({"WaterElectric", "土味",
                "装修师傅最怕你盯的3个地方，水电验收必看",
                "师傅收工别急着走人，这三处低头看仔细了。第一处，线管，横平竖直不交叠，墙根防水刷满刷透；第二处，水管封口，绿胶带压住只是卡口，水泥满浆糊死才算数；第三处，接头，水泥咬瓷实、不漏一丝的，往后用水才踏实。这三处盯住了，水电基本不会出大幺蛾子。要是拿不准，评论区发图，我免费给你过一遍。",
                "线管,防水,封口,接头", "0", "0", "TRUE"}),
        // ④ 悬念式：为什么怕你蹲下来
        @DataItem({"WaterElectric", "土味",
                "为什么装修公司最怕你验收时蹲下来？",
                "装修公司最怕你蹲下来看水管，为什么？因为上半截贴得再漂亮，返工隐患全藏在你蹲下去才看得到的地方。线管走得好不好、防水刷没刷透、封口有没有水泥糊死，全都在这。今天这套工地，业主就蹲着把这三处看完才签字，师傅一点不敢糊弄。你家水电验收，别光站着看水表，蹲下来看这三处，能省三万返工钱。评论区留户型，我帮你把关。",
                "线管,防水,封口,水管", "0", "0", "TRUE"}),
        // ⑤ 通用引流（其他场景兜底）
        @DataItem({"General", "土味",
                "装修公司每天都在工地拍什么？给你看看真现场",
                "总有人问，装修公司发那些工地视频有啥用？今天就带你看真现场。水电管线走得整整齐齐，墙根防水刷得满满当当，每个细节都敢放大给你看。我们拍的不是摆拍，是每天的真实进度。装修这事儿，眼见为实，你盯着我们干，我们心里也踏实。想看你家户型怎么装？评论区留面积，我帮你先出个思路。",
                "工地,现场,进度,装修", "0", "0", "TRUE"})
})
public class VideoScript extends AbstractModel {

    @Note("话术索引")
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long scriptId;

    @Note("场景")
    @Column(nullable = false, length = 32)
    private ScriptScene scene;

    @Note("风格档")
    @Column(nullable = false, length = 32)
    private String style;

    @Note("标题钩子")
    @Keyword
    @Column(length = 128)
    private String hook;

    @Note("口播正文")
    @Keyword
    @Column(nullable = false, length = 2048)
    private String content;

    @Note("覆盖素材关键词（逗号分隔）")
    @Keyword
    @Column(length = 256)
    private String tags;

    @Note("效果分（学习回灌用，默认0）")
    @Column(nullable = false)
    private Integer score = 0;

    @Note("已直出次数（达到上限后轮换退休防同质化）")
    @Column(nullable = false)
    private Integer useCount = 0;

    @Note("启用")
    @Column(nullable = false)
    private Boolean enabled = Boolean.TRUE;

    @Note("创建时间")
    @CreateTime
    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "dateTime", column = @Column(name = "create_dateTime")),
            @AttributeOverride(name = "date", column = @Column(name = "create_date")),
            @AttributeOverride(name = "time", column = @Column(name = "create_time")),
            @AttributeOverride(name = "year", column = @Column(name = "create_year")),
            @AttributeOverride(name = "month", column = @Column(name = "create_month")),
            @AttributeOverride(name = "day", column = @Column(name = "create_day")),
            @AttributeOverride(name = "hour", column = @Column(name = "create_hour")),
            @AttributeOverride(name = "minute", column = @Column(name = "create_minute")),
            @AttributeOverride(name = "second", column = @Column(name = "create_second")),
            @AttributeOverride(name = "week", column = @Column(name = "create_week")),
    })
    private DateTime createTime;

    @Note("更新时间")
    @UpdateTime
    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "dateTime", column = @Column(name = "update_dateTime")),
            @AttributeOverride(name = "date", column = @Column(name = "update_date")),
            @AttributeOverride(name = "time", column = @Column(name = "update_time")),
            @AttributeOverride(name = "year", column = @Column(name = "update_year")),
            @AttributeOverride(name = "month", column = @Column(name = "update_month")),
            @AttributeOverride(name = "day", column = @Column(name = "update_day")),
            @AttributeOverride(name = "hour", column = @Column(name = "update_hour")),
            @AttributeOverride(name = "minute", column = @Column(name = "update_minute")),
            @AttributeOverride(name = "second", column = @Column(name = "update_second")),
            @AttributeOverride(name = "week", column = @Column(name = "update_week")),
    })
    private DateTime updateTime;

    public Long getScriptId() {
        return scriptId;
    }

    public void setScriptId(Long scriptId) {
        this.scriptId = scriptId;
    }

    public ScriptScene getScene() {
        return scene;
    }

    public void setScene(ScriptScene scene) {
        this.scene = scene;
    }

    public String getStyle() {
        return style;
    }

    public void setStyle(String style) {
        this.style = style;
    }

    public String getHook() {
        return hook;
    }

    public void setHook(String hook) {
        this.hook = hook;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getTags() {
        return tags;
    }

    public void setTags(String tags) {
        this.tags = tags;
    }

    public Integer getScore() {
        return score;
    }

    public void setScore(Integer score) {
        this.score = score;
    }

    public Integer getUseCount() {
        return useCount;
    }

    public void setUseCount(Integer useCount) {
        this.useCount = useCount;
    }

    public Boolean getEnabled() {
        return enabled;
    }

    public void setEnabled(Boolean enabled) {
        this.enabled = enabled;
    }

    public DateTime getCreateTime() {
        return createTime;
    }

    public void setCreateTime(DateTime createTime) {
        this.createTime = createTime;
    }

    public DateTime getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(DateTime updateTime) {
        this.updateTime = updateTime;
    }
}

package com.th4.edge.decoboon.clue.video.model;

import com.th4.edge.framework.core.annotation.Description;
import com.th4.edge.framework.core.annotation.Note;
import com.th4.edge.framework.data.jpa.annotation.Model;
import com.th4.edge.framework.data.model.AbstractModel;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Note("视频数据")
@Description("播放/评论/线索归因统计")
@Model
@Entity
@Table(name = "db_clue_video_stat")
public class VideoStat extends AbstractModel {

    @Note("统计索引")
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long statId;

    @Note("视频")
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "video_id", nullable = false)
    private Video video;

    @Note("播放量")
    @Column(nullable = false)
    private Long viewCount = 0L;

    @Note("评论数")
    @Column(nullable = false)
    private Long commentCount = 0L;

    @Note("点赞数")
    @Column(nullable = false)
    private Long likeCount = 0L;

    @Note("由该视频带来的线索数")
    @Column(nullable = false)
    private Long leadCount = 0L;

    @Note("转发数")
    @Column(nullable = false)
    private Long forwardCount = 0L;

    @Note("统计日期")
    @Column(nullable = false, length = 16)
    private String statDate;

    public Long getStatId() {
        return statId;
    }

    public void setStatId(Long statId) {
        this.statId = statId;
    }

    public Video getVideo() {
        return video;
    }

    public void setVideo(Video video) {
        this.video = video;
    }

    public Long getViewCount() {
        return viewCount;
    }

    public void setViewCount(Long viewCount) {
        this.viewCount = viewCount;
    }

    public Long getCommentCount() {
        return commentCount;
    }

    public void setCommentCount(Long commentCount) {
        this.commentCount = commentCount;
    }

    public Long getLikeCount() {
        return likeCount;
    }

    public void setLikeCount(Long likeCount) {
        this.likeCount = likeCount;
    }

    public Long getLeadCount() {
        return leadCount;
    }

    public void setLeadCount(Long leadCount) {
        this.leadCount = leadCount;
    }

    public Long getForwardCount() {
        return forwardCount;
    }

    public void setForwardCount(Long forwardCount) {
        this.forwardCount = forwardCount;
    }

    public String getStatDate() {
        return statDate;
    }

    public void setStatDate(String statDate) {
        this.statDate = statDate;
    }
}

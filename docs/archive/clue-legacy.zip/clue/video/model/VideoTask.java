package com.th4.edge.decoboon.clue.video.model;
import jakarta.persistence.AttributeOverride;
import jakarta.persistence.AttributeOverrides;
import jakarta.persistence.Embedded;

import com.th4.edge.decoboon.clue.company.model.Employee;
import com.th4.edge.decoboon.clue.video.configure.VideoTaskState;
import com.th4.edge.framework.core.annotation.Description;
import com.th4.edge.framework.core.annotation.Note;
import com.th4.edge.framework.data.date.model.DateTime;
import com.th4.edge.framework.data.jpa.annotation.Model;
import com.th4.edge.framework.data.model.AbstractModel;
import com.th4.edge.framework.data.model.prepare.annotation.CreateTime;
import com.th4.edge.framework.data.model.prepare.annotation.UpdateTime;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Note("视频生成任务")
@Description("AI 出片流水线状态机：文案→配音→字幕→合成→尾卡")
@Model
@Entity
@Table(name = "db_clue_video_task")
public class VideoTask extends AbstractModel {

    @Note("任务索引")
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long taskId;

    @Note("所属业务员")
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "emp_id", nullable = false)
    private Employee emp;

    @Note("所属视频")
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "video_id")
    private Video video;

    @Note("模板")
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "temp_id", nullable = false)
    private Template template;

    @Note("选中的话题钩子")
    @Column(length = 512)
    private String hook;

    @Note("素材图片ID列表")
    @Column(length = 512)
    private String assetIds;

    @Note("当前阶段")
    @Column(nullable = false, length = 16)
    private VideoTaskState state = VideoTaskState.Created;

    @Note("阶段明细 JSON（文案/配音地址/字幕/合片地址）")
    @Column(length = 4096)
    private String detail;

    @Note("失败原因")
    @Column(length = 512)
    private String failReason;

    @Note("重试次数（上限 3）")
    @Column(nullable = false)
    private Integer retryCount = 0;

    @Note("创建时间")
    @CreateTime
    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name="dateTime", column=@Column(name="create_dateTime")),
            @AttributeOverride(name="date", column=@Column(name="create_date")),
            @AttributeOverride(name="time", column=@Column(name="create_time")),
            @AttributeOverride(name="year", column=@Column(name="create_year")),
            @AttributeOverride(name="month", column=@Column(name="create_month")),
            @AttributeOverride(name="day", column=@Column(name="create_day")),
            @AttributeOverride(name="hour", column=@Column(name="create_hour")),
            @AttributeOverride(name="minute", column=@Column(name="create_minute")),
            @AttributeOverride(name="second", column=@Column(name="create_second")),
            @AttributeOverride(name="week", column=@Column(name="create_week")),
        })
    private DateTime createTime;

    @Note("更新时间")
    @UpdateTime
    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name="dateTime", column=@Column(name="update_dateTime")),
            @AttributeOverride(name="date", column=@Column(name="update_date")),
            @AttributeOverride(name="time", column=@Column(name="update_time")),
            @AttributeOverride(name="year", column=@Column(name="update_year")),
            @AttributeOverride(name="month", column=@Column(name="update_month")),
            @AttributeOverride(name="day", column=@Column(name="update_day")),
            @AttributeOverride(name="hour", column=@Column(name="update_hour")),
            @AttributeOverride(name="minute", column=@Column(name="update_minute")),
            @AttributeOverride(name="second", column=@Column(name="update_second")),
            @AttributeOverride(name="week", column=@Column(name="update_week")),
        })
    private DateTime updateTime;

    public Long getTaskId() {
        return taskId;
    }

    public void setTaskId(Long taskId) {
        this.taskId = taskId;
    }

    public Employee getEmp() {
        return emp;
    }

    public void setEmp(Employee emp) {
        this.emp = emp;
    }

    public Video getVideo() {
        return video;
    }

    public void setVideo(Video video) {
        this.video = video;
    }

    public Template getTemplate() {
        return template;
    }

    public void setTemplate(Template template) {
        this.template = template;
    }

    public String getHook() {
        return hook;
    }

    public void setHook(String hook) {
        this.hook = hook;
    }

    public String getAssetIds() {
        return assetIds;
    }

    public void setAssetIds(String assetIds) {
        this.assetIds = assetIds;
    }

    public VideoTaskState getState() {
        return state;
    }

    public void setState(VideoTaskState state) {
        this.state = state;
    }

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }

    public String getFailReason() {
        return failReason;
    }

    public void setFailReason(String failReason) {
        this.failReason = failReason;
    }

    public Integer getRetryCount() {
        return retryCount;
    }

    public void setRetryCount(Integer retryCount) {
        this.retryCount = retryCount;
    }

    public DateTime getCreateTime() {
        return createTime;
    }

    public void setCreateTime(DateTime createTime) {
        this.createTime = createTime;
    }

    public DateTime getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(DateTime updateTime) {
        this.updateTime = updateTime;
    }
}

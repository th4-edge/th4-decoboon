package com.th4.edge.decoboon.clue.video.pipeline;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.th4.edge.decoboon.clue.video.ai.AiScriptWriter;
import com.th4.edge.decoboon.clue.video.configure.VideoState;
import com.th4.edge.decoboon.clue.video.configure.VideoTaskState;
import com.th4.edge.decoboon.clue.video.media.AssetEnhancerService;
import com.th4.edge.decoboon.clue.video.media.AssetImageResolver;
import com.th4.edge.decoboon.clue.video.media.AssetTaggerService;
import com.th4.edge.decoboon.clue.video.media.EndCardGenerator;
import com.th4.edge.decoboon.clue.video.media.FfmpegRenderService;
import com.th4.edge.decoboon.clue.video.media.MediaProbe;
import com.th4.edge.decoboon.clue.video.media.SubtitleGenerator;
import com.th4.edge.decoboon.clue.video.media.TtsService;
import com.th4.edge.decoboon.clue.video.model.Video;
import com.th4.edge.decoboon.clue.video.model.VideoCopy;
import com.th4.edge.decoboon.clue.video.model.VideoTask;
import com.th4.edge.decoboon.clue.video.repository.VideoCopyRepository;
import com.th4.edge.decoboon.clue.video.repository.VideoRepository;
import com.th4.edge.decoboon.clue.video.repository.VideoTaskRepository;
import com.th4.edge.framework.core.annotation.Note;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 视频生成流水线状态机（异步驱动）。
 * <p>
 * Created → Writing(DeepSeek 文案) → Dubbing(系统 TTS 配音) → Subtitling(SRT 字幕)
 * → Rendering(FFmpeg 素材轮播+配音+字幕轨) → EndCaring(尾卡 PNG 追加成片) → Done。
 * 任一步骤失败 → Failed + retryCount++，由 @Scheduled 调度从失败阶段断点续跑（上限 3 次）。
 * 阶段产物写入 task.detail（JSON 字符串）与 data/media/task-{taskId}/，可断点、可追踪。
 */
@Note("视频生成流水线")
@Service
public class VideoPipelineService {

    private static final Logger log = LoggerFactory.getLogger(VideoPipelineService.class);

    private final VideoTaskRepository taskRepository;
    private final VideoRepository videoRepository;
    private final VideoCopyRepository copyRepository;
    private final AiScriptWriter aiScriptWriter;
    private final TtsService ttsService;
    private final SubtitleGenerator subtitleGenerator;
    private final FfmpegRenderService renderService;
    private final EndCardGenerator endCardGenerator;
    private final AssetImageResolver assetImageResolver;
    private final AssetEnhancerService assetEnhancerService;
    private final AssetTaggerService assetTaggerService;
    private final ObjectMapper objectMapper;

    public VideoPipelineService(VideoTaskRepository taskRepository,
                                VideoRepository videoRepository,
                                VideoCopyRepository copyRepository,
                                AiScriptWriter aiScriptWriter,
                                TtsService ttsService,
                                SubtitleGenerator subtitleGenerator,
                                FfmpegRenderService renderService,
                                EndCardGenerator endCardGenerator,
                                AssetImageResolver assetImageResolver,
                                AssetEnhancerService assetEnhancerService,
                                AssetTaggerService assetTaggerService,
                                ObjectMapper objectMapper) {
        this.taskRepository = taskRepository;
        this.videoRepository = videoRepository;
        this.copyRepository = copyRepository;
        this.aiScriptWriter = aiScriptWriter;
        this.ttsService = ttsService;
        this.subtitleGenerator = subtitleGenerator;
        this.renderService = renderService;
        this.endCardGenerator = endCardGenerator;
        this.assetImageResolver = assetImageResolver;
        this.assetEnhancerService = assetEnhancerService;
        this.assetTaggerService = assetTaggerService;
        this.objectMapper = objectMapper;
    }

    /**
     * 异步驱动任务走完状态机。入口由 VideoGenerateProvider 触发；调度续跑时亦可复用。
     */
    @Async
    public void run(VideoTask task) {
        VideoTask current = taskRepository.findByTaskId(task.getTaskId());
        if (current == null) {
            log.warn("[Pipeline] 任务{} 不存在，跳过", task.getTaskId());
            return;
        }
        Map<String, Object> detail = readJson(current.getDetail());
        try {
            while (true) {
                VideoTaskState st = current.getState();
                if (st == VideoTaskState.Done || st == VideoTaskState.Failed) {
                    return;
                }
                switch (st) {
                    case Created -> transition(current, VideoTaskState.Writing, detail);
                    case Writing -> {
                        writeScript(current, detail);
                        transition(current, VideoTaskState.Dubbing, detail);
                    }
                    case Dubbing -> {
                        dubbing(current, detail);
                        transition(current, VideoTaskState.Subtitling, detail);
                    }
                    case Subtitling -> {
                        subtitling(current, detail);
                        transition(current, VideoTaskState.Rendering, detail);
                    }
                    case Rendering -> {
                        rendering(current, detail);
                        transition(current, VideoTaskState.EndCaring, detail);
                    }
                    case EndCaring -> {
                        endCaring(current, detail);
                        transition(current, VideoTaskState.Done, detail);
                    }
                }
                sleepQuiet(200);
            }
        } catch (Exception e) {
            fail(current, e, detail);
        }
    }

    /** Writing：DeepSeek 在线文案（未配置 Key 时 Mock），写 VideoCopy 与草稿 */
    private void writeScript(VideoTask task, Map<String, Object> detail) {
        AiScriptWriter.ScriptResult result = aiScriptWriter.writeScript(task);
        if (task.getVideo() != null && copyRepository.findByVideo_VideoId(task.getVideo().getVideoId()) == null) {
            VideoCopy copy = new VideoCopy();
            copy.setVideo(task.getVideo());
            copy.setContent(result.content());
            copy.setHashtags(result.hashtags());
            copy.setLocationTip(result.locationTip());
            copyRepository.save(copy);
        }
        Map<String, Object> script = new LinkedHashMap<>();
        script.put("content", result.content());
        script.put("hashtags", result.hashtags());
        script.put("locationTip", result.locationTip());
        detail.put("script", script);
        if (result.taglines() != null && !result.taglines().isEmpty()) {
            detail.put("taglines", result.taglines());
        }
        if (result.pickedAssetIds() != null && !result.pickedAssetIds().isEmpty()) {
            detail.put("pickedAssetIds", result.pickedAssetIds());
        }
    }

    /** Dubbing：系统 TTS 生成真实配音 mp3 */
    private void dubbing(VideoTask task, Map<String, Object> detail) {
        String content = scriptContent(detail);
        TtsService.TtsResult tts = ttsService.generate(content, task.getTaskId());
        detail.put("audio", tts.audioPath());
        detail.put("audioDuration", tts.durationSec());
        log.info("[Pipeline] 任务{} 配音完成: {} ({}s)", task.getTaskId(), tts.audioPath(),
                String.format("%.2f", tts.durationSec()));
    }

    /** Subtitling：按配音时长生成真实 SRT 字幕 */
    private void subtitling(VideoTask task, Map<String, Object> detail) {
        String content = scriptContent(detail);
        double dur = 30;
        Object audio = detail.get("audio");
        if (audio != null) {
            double d = MediaProbe.durationSec(audio.toString());
            if (d > 0) {
                dur = d;
            }
        }
        String srt = subtitleGenerator.generate(content, dur, task.getTaskId());
        detail.put("subtitle", srt);
        log.info("[Pipeline] 任务{} 字幕完成: {}", task.getTaskId(), srt);
    }

    /** Rendering：FFmpeg 素材轮播 + 配音 + 字幕轨 → 硬字幕烧录 → 主片 */
    private void rendering(VideoTask task, Map<String, Object> detail) {
        // ③ 素材自动筛选：文案阶段已定"出片子集"，渲染只用子集（控 I2V 成本 + 画面与文案一致）
        String assetIds = task.getAssetIds();
        List<Long> picked = toLongList(detail.get("pickedAssetIds"));
        if (picked != null && !picked.isEmpty()) {
            assetIds = "[" + picked.stream().map(String::valueOf).collect(Collectors.joining(",")) + "]";
        }
        List<String> images = assetImageResolver.resolveImages(assetIds, task.getTaskId());
        if (assetEnhancerService.isEnabled()) {
            images = assetEnhancerService.enhance(images, task.getTaskId());
        }
        @SuppressWarnings("unchecked")
        List<String> taglines = (List<String>) detail.get("taglines");
        // L3 AI 图生视频：取素材语义描述（幂等复用，不额外识别）作为运镜 prompt 参考
        List<String> descriptions = new ArrayList<>();
        for (AssetTaggerService.AssetDesc a : assetTaggerService.describeAssets(assetIds, task.getTaskId(), false)) {
            descriptions.add(a.description());
        }
        Object audio = detail.get("audio");
        Object srt = detail.get("subtitle");
        if (audio == null || srt == null) {
            throw new IllegalStateException("缺少配音/字幕产物，无法合片");
        }
        String draft = renderService.renderMain(images, audio.toString(), srt.toString(), taglines, descriptions, task.getTaskId());
        // mov_text 软字幕轨多数播放器默认不显示，烧录进画面像素保证直接可见
        List<SubtitleGenerator.Cue> cues = subtitleGenerator.parseSrt(srt.toString());
        String renderFile = renderService.burnSubtitles(draft, cues, task.getTaskId());
        Map<String, Object> render = new LinkedHashMap<>();
        render.put("video", renderFile);
        render.put("images", images.size());
        render.put("subtitleCues", cues.size());
        render.put("duration", String.format("%.1f", MediaProbe.durationSec(renderFile)));
        detail.put("render", render);
        detail.put("draft", renderFile);
        log.info("[Pipeline] 任务{} 主片合成+硬字幕完成: {}", task.getTaskId(), renderFile);
    }

    /** EndCaring：尾卡 PNG + 追加成片，写回 Video（url/时长/Published） */
    private void endCaring(VideoTask task, Map<String, Object> detail) {
        Object draft = detail.get("draft");
        if (draft == null) {
            throw new IllegalStateException("缺少主片，无法追加尾卡");
        }
        String endcard = endCardGenerator.generate(task.getTaskId());
        String finalVideo = renderService.appendEndCard(draft.toString(), endcard, task.getTaskId());
        detail.put("endcard", endcard);
        detail.put("final", finalVideo);
        detail.put("finalDuration", MediaProbe.durationSec(finalVideo));

        if (task.getVideo() != null) {
            Video video = task.getVideo();
            if (video != null) {
                video.setUrl(finalVideo);
                video.setDuration((long) MediaProbe.durationSec(finalVideo));
                video.setState(VideoState.Published);
                videoRepository.save(video);
            }
        }
        log.info("[Pipeline] 任务{} 尾卡追加完成，成片就绪: {}", task.getTaskId(), finalVideo);
    }

    private String scriptContent(Map<String, Object> detail) {
        Object script = detail.get("script");
        if (script instanceof Map<?, ?> m && m.get("content") != null) {
            return m.get("content").toString();
        }
        return "装修不踩坑，这3个细节一定要盯住。";
    }

    /** detail 经 JSON 落库再读回后数字统一变 Integer，兼容转换回 Long */
    private static List<Long> toLongList(Object o) {
        if (!(o instanceof List<?> l)) {
            return null;
        }
        List<Long> r = new ArrayList<>();
        for (Object x : l) {
            if (x instanceof Number n) {
                r.add(n.longValue());
            } else if (x != null) {
                r.add(Long.parseLong(String.valueOf(x).trim()));
            }
        }
        return r;
    }

    private void transition(VideoTask task, VideoTaskState next, Map<String, Object> detail) {
        task.setState(next);
        task.setDetail(writeJson(detail));
        taskRepository.save(task);
        log.info("[Pipeline] 任务{} 状态 → {}", task.getTaskId(), next.getValue());
    }

    private void fail(VideoTask task, Exception e, Map<String, Object> detail) {
        detail.put("lastState", task.getState().getValue());
        task.setDetail(writeJson(detail));
        task.setState(VideoTaskState.Failed);
        task.setFailReason(e.getMessage() == null ? "未知错误" : e.getMessage().substring(0, Math.min(e.getMessage().length(), 500)));
        task.setRetryCount((task.getRetryCount() == null ? 0 : task.getRetryCount()) + 1);
        taskRepository.save(task);
        log.error("[Pipeline] 任务{} 失败（第{}次）: {}", task.getTaskId(), task.getRetryCount(), e.getMessage(), e);
    }

    /**
     * 断点续跑：定时扫描 Failed 任务（retryCount&lt;3），从失败阶段恢复并重新驱动。
     */
    @Scheduled(fixedDelay = 30000, initialDelay = 30000)
    public void resumeBrokenTasks() {
        List<VideoTask> failed = taskRepository.findByStateOrderByCreateTimeAsc(VideoTaskState.Failed);
        for (VideoTask t : failed) {
            // 混剪任务由 VideoRenderScheduler 负责配额与重试，AI 流水线不认领
            if (t.getDetail() != null && t.getDetail().contains("Montage")) {
                continue;
            }
            int rc = t.getRetryCount() == null ? 0 : t.getRetryCount();
            if (rc >= 3) {
                continue;
            }
            String lastState = lastStateOf(t.getDetail());
            t.setState(lastState == null ? VideoTaskState.Writing : VideoTaskState.valueOf(lastState));
            t.setFailReason(null);
            taskRepository.save(t);
            log.info("[Pipeline] 调度续跑任务{}（第{}次）从 {} 恢复", t.getTaskId(), rc + 1, t.getState().getValue());
            run(t);
        }
    }

    private String lastStateOf(String detail) {
        Map<String, Object> map = readJson(detail);
        Object v = map == null ? null : map.get("lastState");
        return v == null ? null : v.toString();
    }

    private Map<String, Object> readJson(String json) {
        if (json == null || json.isBlank()) {
            return new LinkedHashMap<>();
        }
        try {
            return objectMapper.readValue(json, new TypeReference<LinkedHashMap<String, Object>>() {
            });
        } catch (Exception e) {
            log.warn("[Pipeline] detail 解析失败，重置: {}", e.getMessage());
            return new LinkedHashMap<>();
        }
    }

    private String writeJson(Map<String, Object> detail) {
        try {
            return objectMapper.writeValueAsString(detail);
        } catch (Exception e) {
            log.warn("[Pipeline] detail 序列化失败", e);
            return "{}";
        }
    }

    private void sleepQuiet(long millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}

package com.th4.edge.decoboon.clue.video.planner;

/**
 * 单段剪辑计划（确定性渲染决策的最小单元，可 JSON 落库到 task.detail 以便断点续跑）。
 * <p>
 * 由 {@link VideoPlanner} 生成、{@code VideoRenderScheduler} 消费、
 * {@code FfmpegCli} 执行。zoompan 表达式统一用 ease-in-out 缓动，全程运动不提前封顶。
 *
 * @param imagePath   图片绝对路径
 * @param durationSec 镜头时长（秒，按内容复杂度 2.0~4.5s）
 * @param zoomFrom    起始缩放倍率（1.0 = 原始）
 * @param zoomTo      结束缩放倍率（总放大 ≤ 1.08，全程缓动）
 * @param move        运镜类型：push 推近 / pull 拉远 / panL 左→右 / panR 右→左
 * @param brightness  亮度补偿（由图片平均亮度反推，消除段间明暗跳变）
 * @param saturation  饱和度（统一基准 1.1）
 * @param contrast    对比度（统一基准 1.05）
 * @param fadeSec     入出淡入淡出时长（与合并 xfade 保持一致）
 */
public record SegmentPlan(
        int index,
        String imagePath,
        double durationSec,
        double zoomFrom,
        double zoomTo,
        String move,
        double brightness,
        double saturation,
        double contrast,
        double fadeSec) {

    /** zoompan z 表达式：推/拉用 ease-in-out 全程缓动；平移保持恒定倍率 */
    public String zoomExpr(int frames) {
        double span = frames > 1 ? frames - 1 : 1;
        return switch (move) {
            case "panL", "panR" -> String.format("%.3f", zoomTo);
            default -> String.format("%.3f+(%.3f)*(0.5-0.5*cos(PI*on/%.0f))",
                    zoomFrom, zoomTo - zoomFrom, span);
        };
    }

    /** zoompan x 表达式：平移跨全程（frames-1 为总帧数，zoompan 表达式无 d 变量），推/拉居中 */
    public String xExpr(int frames) {
        double span = frames > 1 ? frames - 1 : 1;
        return switch (move) {
            case "panL" -> String.format("(iw-iw/zoom)*on/%.0f", span);
            case "panR" -> String.format("(iw-iw/zoom)*(1-on/%.0f)", span);
            default -> "iw/2-(iw/zoom/2)";
        };
    }

    /** zoompan y 表达式：默认垂直居中 */
    public String yExpr(int frames) {
        return "ih/2-(ih/zoom/2)";
    }
}

package com.th4.edge.decoboon.clue.video.planner;

import com.th4.edge.framework.core.annotation.Note;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.imageio.ImageIO;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * 剪辑计划器（纯 Java 决策层，不调用 ffmpeg）：
 * <ul>
 *   <li>素材复杂度分析：ImageIO 缩略图亮度均值/方差 → 信息量代理指标；</li>
 *   <li>镜头时长策略：复杂度 → 2.0~4.5s，有 BGM 节拍时量化到节拍整数倍；</li>
 *   <li>KenBurns 运镜分配：推/拉/平移池 + 避免连续重复 + ease-in-out 缓动表达式；</li>
 *   <li>逐段色彩归一：按平均亮度反推 eq.brightness，消除段间明暗跳变。</li>
 * </ul>
 */
@Note("剪辑计划器")
@Component
public class VideoPlanner {

    private static final Logger log = LoggerFactory.getLogger(VideoPlanner.class);

    private static final int SAMPLE = 64;

    /** 计划选项（可扩展：总时长目标、禁止运镜等） */
    public record Options(double minDuration, double maxDuration, double fadeSec,
                          List<Double> beats, boolean kenBurns) {

        public static Options defaults() {
            return new Options(2.0, 4.5, 0.4, List.of(), true);
        }
    }

    /** 生成全片分段计划 */
    public List<SegmentPlan> plan(List<String> images, Options opts) {
        if (images == null || images.isEmpty()) {
            return new ArrayList<>();
        }
        List<SegmentPlan> plans = new ArrayList<>(images.size());
        String prevMove = "";
        for (int i = 0; i < images.size(); i++) {
            double[] stats = analyze(images.get(i));          // [meanLum 0~1, variance]
            double complexity = clamp(stats[1] / 2500.0, 0.0, 1.0);
            double dur = opts.minDuration()
                    + (opts.maxDuration() - opts.minDuration()) * complexity;
            if (opts.kenBurns() && opts.beats() != null && !opts.beats().isEmpty()) {
                dur = snapToBeats(dur, opts.beats(), opts.minDuration(), opts.maxDuration());
            }
            String move = pickMotion(prevMove, i);
            prevMove = move;
            double zoomFrom = 1.0;
            double zoomTo = 1.08;
            if ("pull".equals(move)) {
                zoomFrom = 1.08;
                zoomTo = 1.0;
            } else if ("panL".equals(move) || "panR".equals(move)) {
                zoomFrom = 1.06;
                zoomTo = 1.06;
            }
            double brightness = clamp((0.5 - stats[0]) * 0.6, -0.06, 0.06);
            plans.add(new SegmentPlan(i, images.get(i), Math.max(dur, 1.0),
                    zoomFrom, zoomTo, move, round4(brightness), 1.1, 1.05, opts.fadeSec()));
        }
        log.info("[Planner] {} 张图规划完成，总时长={}s", images.size(),
                String.format("%.1f", totalDuration(plans)));
        return plans;
    }

    /** 合并后成片总时长 = Σ段时长 − (段数−1)×转场时长 */
    public double totalDuration(List<SegmentPlan> plans) {
        if (plans == null || plans.isEmpty()) {
            return 0;
        }
        double sum = 0;
        for (SegmentPlan p : plans) {
            sum += p.durationSec();
        }
        double fade = plans.get(0).fadeSec();
        return Math.max(sum - (plans.size() - 1) * fade, 1.0);
    }

    /** 素材复杂度分析：64x64 缩略图亮度均值与方差（方差≈细节/信息量） */
    private double[] analyze(String imagePath) {
        try {
            BufferedImage src = ImageIO.read(new File(imagePath));
            if (src == null) {
                return new double[]{0.5, 1000.0};
            }
            Image scaled = src.getScaledInstance(SAMPLE, SAMPLE, Image.SCALE_AREA_AVERAGING);
            BufferedImage small = new BufferedImage(SAMPLE, SAMPLE, BufferedImage.TYPE_INT_RGB);
            Graphics2D g = small.createGraphics();
            try {
                g.drawImage(scaled, 0, 0, null);
            } finally {
                g.dispose();
            }
            double sum = 0;
            double sumSq = 0;
            for (int y = 0; y < SAMPLE; y++) {
                for (int x = 0; x < SAMPLE; x++) {
                    int rgb = small.getRGB(x, y);
                    int r = (rgb >> 16) & 0xff;
                    int gr = (rgb >> 8) & 0xff;
                    int b = rgb & 0xff;
                    double lum = 0.299 * r + 0.587 * gr + 0.114 * b;
                    sum += lum;
                    sumSq += lum * lum;
                }
            }
            int cnt = SAMPLE * SAMPLE;
            double mean = sum / cnt;
            double variance = Math.max(sumSq / cnt - mean * mean, 0);
            return new double[]{mean / 255.0, variance};
        } catch (Exception e) {
            log.warn("[Planner] 素材分析失败（按中等复杂度处理）: {}", e.getMessage());
            return new double[]{0.5, 1000.0};
        }
    }

    /** 把时长量化到节拍周期的整数倍（如 120BPM → 0.5s 粒度），避免机械固定时长 */
    private double snapToBeats(double dur, List<Double> beats, double minDur, double maxDur) {
        double interval = medianInterval(beats);
        if (interval <= 0) {
            return dur;
        }
        double snapped = Math.ceil(dur / interval) * interval;
        return clamp(snapped, minDur, maxDur);
    }

    private double medianInterval(List<Double> beats) {
        List<Double> gaps = new ArrayList<>();
        for (int i = 1; i < beats.size(); i++) {
            double gap = beats.get(i) - beats.get(i - 1);
            if (gap > 0.2) {
                gaps.add(gap);
            }
        }
        if (gaps.isEmpty()) {
            return 0;
        }
        Collections.sort(gaps);
        return gaps.get(gaps.size() / 2);
    }

    /** 运镜分配：按池轮转 + 跳过与上一段重复的类型 */
    private String pickMotion(String prevMove, int index) {
        String[] pool = {"push", "pull", "panL", "push", "pull", "panR"};
        String move = pool[index % pool.length];
        if (move.equals(prevMove)) {
            move = "push".equals(prevMove) ? "pull" : "push";
        }
        return move;
    }

    private static double clamp(double v, double min, double max) {
        return Math.max(min, Math.min(max, v));
    }

    private static double round4(double v) {
        return Math.round(v * 10000.0) / 10000.0;
    }
}

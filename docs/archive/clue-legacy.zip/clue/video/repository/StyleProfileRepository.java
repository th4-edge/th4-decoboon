package com.th4.edge.decoboon.clue.video.repository;

import com.th4.edge.decoboon.clue.video.model.StyleProfile;
import com.th4.edge.framework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface StyleProfileRepository extends JpaRepository<StyleProfile, Long> {

    StyleProfile findByEmp_EmpIdAndEnabledTrue(Long empId);

    List<StyleProfile> findByEnabledTrue();
}

package com.th4.edge.decoboon.clue.video.repository;

import com.th4.edge.decoboon.clue.video.configure.TemplateType;
import com.th4.edge.decoboon.clue.video.model.Template;
import com.th4.edge.framework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface TemplateRepository extends JpaRepository<Template, Long> {

    List<Template> findByType(TemplateType type);

    List<Template> findByTypeAndEnabledTrue(TemplateType type);

    List<Template> findByEnabledTrueOrderByTempIdAsc();

    Template findByTempId(Long tempId);
}

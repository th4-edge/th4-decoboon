package com.th4.edge.decoboon.clue.video.repository;

import com.th4.edge.decoboon.clue.video.model.VideoCopy;
import com.th4.edge.framework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface VideoCopyRepository extends JpaRepository<VideoCopy, Long> {

    VideoCopy findByVideo_VideoId(Long videoId);

    List<VideoCopy> findByVideo_VideoIdIn(java.util.Collection<Long> videoIds);
}

package com.th4.edge.decoboon.clue.video.repository;

import com.th4.edge.decoboon.clue.video.configure.VideoState;
import com.th4.edge.decoboon.clue.video.model.Video;
import com.th4.edge.framework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface VideoRepository extends JpaRepository<Video, Long> {

    List<Video> findByEmp_EmpIdOrderByCreateTimeDesc(Long empId);

    List<Video> findByEmp_EmpIdAndState(Long empId, VideoState state);

    List<Video> findByTemplate_TempId(Long tempId);

    long countByEmp_EmpId(Long empId);

    Video findByVideoId(Long videoId);
}

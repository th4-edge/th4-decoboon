package com.th4.edge.decoboon.clue.video.repository;

import com.th4.edge.decoboon.clue.video.configure.ScriptScene;
import com.th4.edge.decoboon.clue.video.model.VideoScript;
import com.th4.edge.framework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface VideoScriptRepository extends JpaRepository<VideoScript, Long> {

    /** 某场景下启用的话术，按效果分高、使用次数少优先（差异化轮换） */
    List<VideoScript> findBySceneAndEnabledTrueOrderByScoreDescUseCountAsc(ScriptScene scene);

    List<VideoScript> findByEnabledTrueOrderByScoreDesc();

    VideoScript findByScriptId(Long scriptId);

    long countByScene(ScriptScene scene);
}

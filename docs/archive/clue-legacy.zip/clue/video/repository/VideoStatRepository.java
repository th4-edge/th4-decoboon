package com.th4.edge.decoboon.clue.video.repository;

import com.th4.edge.decoboon.clue.video.model.VideoStat;
import com.th4.edge.framework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface VideoStatRepository extends JpaRepository<VideoStat, Long> {

    List<VideoStat> findByVideo_VideoId(Long videoId);

    VideoStat findByVideo_VideoIdAndStatDate(Long videoId, String statDate);

    List<VideoStat> findByStatDate(String statDate);
}

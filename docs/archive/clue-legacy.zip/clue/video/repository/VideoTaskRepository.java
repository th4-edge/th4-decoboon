package com.th4.edge.decoboon.clue.video.repository;

import com.th4.edge.decoboon.clue.video.configure.VideoTaskState;
import com.th4.edge.decoboon.clue.video.model.VideoTask;
import com.th4.edge.framework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface VideoTaskRepository extends JpaRepository<VideoTask, Long> {

    List<VideoTask> findByStateOrderByCreateTimeAsc(VideoTaskState state);

    List<VideoTask> findByEmp_EmpIdOrderByCreateTimeDesc(Long empId);

    List<VideoTask> findByEmp_EmpIdAndState(Long empId, VideoTaskState state);

    VideoTask findByTaskId(Long taskId);

    long countByState(VideoTaskState state);
}

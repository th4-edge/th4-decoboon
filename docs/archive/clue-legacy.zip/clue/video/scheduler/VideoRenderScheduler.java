package com.th4.edge.decoboon.clue.video.scheduler;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.th4.edge.decoboon.clue.video.configure.VideoPipelineMode;
import com.th4.edge.decoboon.clue.video.configure.VideoState;
import com.th4.edge.decoboon.clue.video.configure.VideoTaskState;
import com.th4.edge.decoboon.clue.video.media.AssetImageResolver;
import com.th4.edge.decoboon.clue.video.media.BeatDetector;
import com.th4.edge.decoboon.clue.video.media.FfmpegCli;
import com.th4.edge.decoboon.clue.video.model.Video;
import com.th4.edge.decoboon.clue.video.model.VideoTask;
import com.th4.edge.decoboon.clue.video.planner.SegmentPlan;
import com.th4.edge.decoboon.clue.video.planner.VideoPlanner;
import com.th4.edge.decoboon.clue.video.repository.VideoRepository;
import com.th4.edge.decoboon.clue.video.repository.VideoTaskRepository;
import com.th4.edge.framework.core.annotation.Note;
import jakarta.annotation.PreDestroy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.Semaphore;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * 视频渲染调度器（多用户多并发核心）：
 * <ul>
 *   <li><b>全局并发预算</b>：Semaphore(核数−1 或配置值) 限制同时渲染任务数，避免 ffmpeg 线程争抢；</li>
 *   <li><b>业务员级配额</b>：每业务员并发上限（默认 2），一个业务员/公司不会挤占全部算力；</li>
 *   <li><b>状态机</b>：Created(排队) → Rendering(计划+分段渲染+合并) → Done/Failed；</li>
 *   <li><b>超时重投</b>：Rendering 超时（无心跳，默认 30 分钟）→ 回 Created 重排，超上限置 Failed；
 *       Failed 且未达上限 → 回 Created 断点重试；</li>
 *   <li><b>段级并行 + 合并单飞</b>：任务内分段渲染并行（segment-parallel），合并阶段全局单飞。</li>
 * </ul>
 * 只认领 detail 带 {@code "mode":"Montage"} 标记的任务（AI 任务仍由 VideoPipelineService 驱动）。
 */
@Note("视频渲染调度器")
@Component
public class VideoRenderScheduler {

    private static final Logger log = LoggerFactory.getLogger(VideoRenderScheduler.class);
    private static final String MODE_MARKER = VideoPipelineMode.Montage.name();

    private final VideoTaskRepository taskRepository;
    private final VideoRepository videoRepository;
    private final VideoPlanner planner;
    private final FfmpegCli ffmpegCli;
    private final AssetImageResolver assetImageResolver;
    private final ObjectMapper objectMapper;

    private final boolean enabled;
    private final int maxConcurrent;
    private final int perEmpQuota;
    private final int timeoutMinutes;
    private final int maxRetry;
    private final int segmentParallel;
    private final String bgmPath;

    private final ExecutorService executor;
    private final Semaphore globalQuota;
    private final Map<Long, Semaphore> empQuotas = new ConcurrentHashMap<>();
    private final Set<Long> running = ConcurrentHashMap.newKeySet();
    /** 合并阶段全局单飞：避免多个整片编码同时抢占全部核 */
    private final Semaphore mergeLock = new Semaphore(1);
    private final AtomicInteger threadSeq = new AtomicInteger();

    public VideoRenderScheduler(VideoTaskRepository taskRepository,
                                VideoRepository videoRepository,
                                VideoPlanner planner,
                                FfmpegCli ffmpegCli,
                                AssetImageResolver assetImageResolver,
                                ObjectMapper objectMapper,
                                @Value("${th4.edge.decoboon.video.scheduler.enabled:true}") boolean enabled,
                                @Value("${th4.edge.decoboon.video.scheduler.max-concurrent:0}") int maxConcurrent,
                                @Value("${th4.edge.decoboon.video.scheduler.per-emp-quota:2}") int perEmpQuota,
                                @Value("${th4.edge.decoboon.video.scheduler.timeout-minutes:30}") int timeoutMinutes,
                                @Value("${th4.edge.decoboon.video.scheduler.max-retry:3}") int maxRetry,
                                @Value("${th4.edge.decoboon.video.scheduler.segment-parallel:2}") int segmentParallel,
                                @Value("${th4.edge.decoboon.video.montage.bgm.path:}") String bgmPath) {
        this.taskRepository = taskRepository;
        this.videoRepository = videoRepository;
        this.planner = planner;
        this.ffmpegCli = ffmpegCli;
        this.assetImageResolver = assetImageResolver;
        this.objectMapper = objectMapper;
        this.enabled = enabled;
        int cores = Runtime.getRuntime().availableProcessors();
        this.maxConcurrent = maxConcurrent > 0 ? maxConcurrent : Math.max(1, cores - 1);
        this.perEmpQuota = perEmpQuota;
        this.timeoutMinutes = timeoutMinutes;
        this.maxRetry = maxRetry;
        this.segmentParallel = segmentParallel;
        this.bgmPath = bgmPath;
        this.executor = Executors.newFixedThreadPool(this.maxConcurrent,
                r -> new Thread(r, "video-render-" + threadSeq.incrementAndGet()));
        this.globalQuota = new Semaphore(this.maxConcurrent);
        log.info("[Scheduler] 初始化：并发预算={}（{}核），每业务员配额={}，超时={}min，段并行={}",
                this.maxConcurrent, cores, perEmpQuota, timeoutMinutes, segmentParallel);
    }

    /** 混剪任务入队（Provider 调用，须在事务内）：打心跳，等待轮询调度 */
    public void submit(Long taskId) {
        if (!enabled) {
            return;
        }
        VideoTask task = taskRepository.findByTaskId(taskId);
        if (task == null || !isMontage(task)) {
            return;
        }
        touch(task);
        log.info("[Scheduler] 任务{} 入队（混剪）", taskId);
    }

    /** 定时轮询：超时重投 → 失败重试 → 配额派发 */
    @Scheduled(fixedDelay = 10000, initialDelay = 5000)
    public void poll() {
        if (!enabled) {
            return;
        }
        requeueStuck();
        requeueFailed();
        dispatchAll();
    }

    /** 按 Created 顺序派发（FIFO 公平：全局配额满即停，不跳队） */
    private void dispatchAll() {
        List<VideoTask> created = taskRepository.findByStateOrderByCreateTimeAsc(VideoTaskState.Created);
        for (VideoTask t : created) {
            if (!isMontage(t) || running.contains(t.getTaskId())) {
                continue;
            }
            if (!tryDispatch(t)) {
                break;
            }
        }
    }

    /** 配额双重校验后提交执行；返回 false 表示全局算力已满（调用方停止扫描） */
    private boolean tryDispatch(VideoTask t) {
        if (!globalQuota.tryAcquire()) {
            return false;
        }
        Long empId = empIdOf(t);
        Semaphore eq = empQuotas.computeIfAbsent(empId, k -> new Semaphore(perEmpQuota));
        if (!eq.tryAcquire()) {
            globalQuota.release();
            return true; // 本业务员配额满，继续派发其他业务员的任务
        }
        running.add(t.getTaskId());
        executor.submit(() -> {
            try {
                runMontage(t.getTaskId());
            } finally {
                running.remove(t.getTaskId());
                eq.release();
                globalQuota.release();
            }
        });
        log.info("[Scheduler] 任务{} 获得配额（全局{} 业务员{}）开始渲染", t.getTaskId(),
                globalQuota.availablePermits(), eq.availablePermits());
        return true;
    }

    /** 混剪状态机执行：Created →（计划）→ Rendering →（分段渲染+合并）→ Done */
    private void runMontage(Long taskId) {
        try {
            VideoTask task = taskRepository.findByTaskId(taskId);
            if (task == null) {
                return;
            }
            if (task.getState() == VideoTaskState.Created) {
                phasePlan(task);
                task = taskRepository.findByTaskId(taskId);
            }
            if (task != null && task.getState() == VideoTaskState.Rendering) {
                phaseRender(task);
            }
        } catch (Exception e) {
            fail(taskId, e);
        }
    }

    /** 计划阶段：素材解析 → Planner 决策（时长/运镜/节拍/色彩）→ 落 detail 并进入 Rendering */
    private void phasePlan(VideoTask task) {
        List<String> images = assetImageResolver.resolveImages(task.getAssetIds(), task.getTaskId());
        List<Double> beats = beatsOf();
        VideoPlanner.Options opts = new VideoPlanner.Options(2.0, 4.5, 0.4, beats, true);
        List<SegmentPlan> plan = planner.plan(images, opts);

        Map<String, Object> detail = detailOf(task);
        detail.put("plan", plan);
        detail.put("segmentCount", plan.size());
        detail.put("heartbeat", System.currentTimeMillis());
        task.setDetail(writeJson(detail));
        task.setState(VideoTaskState.Rendering);
        taskRepository.save(task);
        log.info("[Scheduler] 任务{} 计划完成（{} 段），进入渲染阶段", task.getTaskId(), plan.size());
    }

    /** 渲染阶段：段级并行渲染 → 合并单飞 → 成片写回 Video → Done */
    private void phaseRender(VideoTask task) {
        Map<String, Object> detail = detailOf(task);
        Object planObj = detail.get("plan");
        if (!(planObj instanceof List<?> raw) || raw.isEmpty()) {
            throw new IllegalStateException("缺少剪辑计划");
        }
        List<SegmentPlan> plan = new ArrayList<>(raw.size());
        for (Object o : raw) {
            plan.add(objectMapper.convertValue(o, SegmentPlan.class));
        }
        double totalDur = planner.totalDuration(plan);

        Map<Integer, Path> segments = new ConcurrentHashMap<>();
        AtomicInteger done = new AtomicInteger();
        int parallel = Math.max(1, Math.min(segmentParallel, plan.size()));
        ExecutorService pool = Executors.newFixedThreadPool(parallel,
                r -> new Thread(r, "video-seg-" + task.getTaskId()));
        try {
            List<Future<?>> futures = new ArrayList<>(plan.size());
            for (SegmentPlan p : plan) {
                futures.add(pool.submit(() -> {
                    Path seg = ffmpegCli.renderSegment(p, task.getTaskId());
                    segments.put(p.index(), seg);
                    int d = done.incrementAndGet();
                    int step = Math.max(1, plan.size() / 10);
                    if (d % step == 0 || d == plan.size()) {
                        progress(task.getTaskId(), Math.min((int) Math.round(d * 80.0 / plan.size()), 80));
                    }
                }));
            }
            for (Future<?> f : futures) {
                f.get();
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IllegalStateException("分段渲染被中断", e);
        } catch (java.util.concurrent.ExecutionException e) {
            throw new IllegalStateException("分段渲染失败: "
                    + (e.getCause() == null ? e.getMessage() : e.getCause().getMessage()), e);
        } finally {
            pool.shutdownNow();
        }
        List<Path> ordered = new ArrayList<>(segments.size());
        segments.entrySet().stream()
                .sorted(Comparator.comparingInt(Map.Entry::getKey))
                .forEach(e -> ordered.add(e.getValue()));
        progress(task.getTaskId(), 85);

        mergeLock.acquireUninterruptibly();
        try {
            Path finalVideo = ffmpegCli.mergeSegments(ordered, plan.get(0).fadeSec(), totalDur, bgmPath, task.getTaskId());
            complete(task, finalVideo, totalDur);
        } finally {
            mergeLock.release();
        }
    }

    /** 成片写回 Video（url/时长/Published）并置任务 Done */
    private void complete(VideoTask task, Path finalVideo, double totalDur) {
        Map<String, Object> detail = detailOf(task);
        detail.put("final", finalVideo.toAbsolutePath().toString());
        detail.put("progress", 100);
        detail.put("heartbeat", System.currentTimeMillis());
        task.setDetail(writeJson(detail));
        task.setState(VideoTaskState.Done);
        taskRepository.save(task);

        Object vid = detail.get("videoId");
        if (vid instanceof Number n) {
            Video video = videoRepository.findByVideoId(n.longValue());
            if (video != null) {
                video.setUrl(finalVideo.toAbsolutePath().toString());
                video.setDuration((long) Math.round(totalDur));
                video.setState(VideoState.Published);
                videoRepository.save(video);
            }
        }
        log.info("[Scheduler] 任务{} 渲染完成，成片: {} ({}s)", task.getTaskId(), finalVideo,
                String.format("%.1f", totalDur));
    }

    private void fail(Long taskId, Exception e) {
        try {
            VideoTask t = taskRepository.findByTaskId(taskId);
            if (t == null) {
                return;
            }
            Map<String, Object> detail = detailOf(t);
            detail.put("lastState", t.getState().getValue());
            detail.put("heartbeat", System.currentTimeMillis());
            t.setDetail(writeJson(detail));
            t.setState(VideoTaskState.Failed);
            String msg = e.getMessage() == null ? "未知错误" : e.getMessage();
            t.setFailReason(msg.substring(0, Math.min(msg.length(), 500)));
            t.setRetryCount((t.getRetryCount() == null ? 0 : t.getRetryCount()) + 1);
            taskRepository.save(t);
            log.error("[Scheduler] 任务{} 失败（第{}次）: {}", taskId, t.getRetryCount(), msg, e);
        } catch (Exception ex) {
            log.error("[Scheduler] 任务{} 失败记录写入异常", taskId, ex);
        }
    }

    /** 超时重投：Rendering 超过 timeout 无心跳 → 回 Created 重排；超上限置 Failed */
    private void requeueStuck() {
        long now = System.currentTimeMillis();
        long timeoutMs = timeoutMinutes * 60_000L;
        for (VideoTask t : taskRepository.findByStateOrderByCreateTimeAsc(VideoTaskState.Rendering)) {
            if (!isMontage(t)) {
                continue;
            }
            Long hb = heartbeatOf(t);
            if (hb == null || now - hb <= timeoutMs) {
                continue;
            }
            int rc = (t.getRetryCount() == null ? 0 : t.getRetryCount()) + 1;
            t.setRetryCount(rc);
            if (rc > maxRetry) {
                t.setState(VideoTaskState.Failed);
                t.setFailReason("渲染超时（" + timeoutMinutes + " 分钟无心跳）");
                log.warn("[Scheduler] 任务{} 渲染超时，已达重试上限，置为失败", t.getTaskId());
            } else {
                t.setState(VideoTaskState.Created);
                t.setFailReason(null);
                log.warn("[Scheduler] 任务{} 渲染超时，重新入队（第{}次）", t.getTaskId(), rc);
            }
            taskRepository.save(t);
        }
    }

    /** 失败重试：Failed 且未达上限 → 回 Created 断点重投（由下轮 poll 派发） */
    private void requeueFailed() {
        for (VideoTask t : taskRepository.findByStateOrderByCreateTimeAsc(VideoTaskState.Failed)) {
            if (!isMontage(t)) {
                continue;
            }
            int rc = t.getRetryCount() == null ? 0 : t.getRetryCount();
            if (rc >= maxRetry) {
                continue;
            }
            t.setState(VideoTaskState.Created);
            t.setFailReason(null);
            taskRepository.save(t);
            log.info("[Scheduler] 任务{} 失败重试入队（第{}次）", t.getTaskId(), rc + 1);
        }
    }

    /** 进度落库（5% 粒度节流，同时刷新心跳） */
    private void progress(Long taskId, int pct) {
        VideoTask t = taskRepository.findByTaskId(taskId);
        if (t == null) {
            return;
        }
        Map<String, Object> detail = detailOf(t);
        Object prev = detail.get("progress");
        int old = prev instanceof Number n ? n.intValue() : 0;
        if (pct < 100 && pct - old < 5) {
            return;
        }
        detail.put("progress", pct);
        detail.put("heartbeat", System.currentTimeMillis());
        t.setDetail(writeJson(detail));
        taskRepository.save(t);
    }

    private void touch(VideoTask task) {
        Map<String, Object> detail = detailOf(task);
        detail.put("heartbeat", System.currentTimeMillis());
        task.setDetail(writeJson(detail));
        taskRepository.save(task);
    }

    private List<Double> beatsOf() {
        if (!StringUtils.hasText(bgmPath) || !Files.exists(Path.of(bgmPath.trim()))) {
            return List.of();
        }
        return BeatDetector.detectBeats(bgmPath.trim(), 60);
    }

    /** 实时运行任务数（报表用） */
    public int runningCount() {
        return running.size();
    }

    /** 排队任务数（混剪 Created 且未在运行，报表用） */
    public int queueCount() {
        int c = 0;
        for (VideoTask t : taskRepository.findByStateOrderByCreateTimeAsc(VideoTaskState.Created)) {
            if (isMontage(t) && !running.contains(t.getTaskId())) {
                c++;
            }
        }
        return c;
    }

    private boolean isMontage(VideoTask t) {
        String d = t.getDetail();
        return d != null && d.contains(MODE_MARKER);
    }

    private Long empIdOf(VideoTask t) {
        Object o = detailOf(t).get("empId");
        return o instanceof Number n ? n.longValue() : 0L;
    }

    private Long heartbeatOf(VideoTask t) {
        Object o = detailOf(t).get("heartbeat");
        return o instanceof Number n ? n.longValue() : null;
    }

    private Map<String, Object> detailOf(VideoTask t) {
        if (t.getDetail() == null || t.getDetail().isBlank()) {
            return new LinkedHashMap<>();
        }
        try {
            return objectMapper.readValue(t.getDetail(), new TypeReference<LinkedHashMap<String, Object>>() {
            });
        } catch (Exception e) {
            log.warn("[Scheduler] 任务{} detail 解析失败: {}", t.getTaskId(), e.getMessage());
            return new LinkedHashMap<>();
        }
    }

    private String writeJson(Map<String, Object> detail) {
        try {
            return objectMapper.writeValueAsString(detail);
        } catch (Exception e) {
            log.warn("[Scheduler] detail 序列化失败", e);
            return "{}";
        }
    }

    @PreDestroy
    public void shutdown() {
        executor.shutdownNow();
    }
}

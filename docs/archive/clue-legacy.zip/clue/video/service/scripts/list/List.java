package com.th4.edge.decoboon.clue.video.service.scripts.list;

import com.th4.edge.decoboon.clue.video.model.VideoScript;
import com.th4.edge.framework.service.ModelService;

/**
 * 话术库列表服务：按场景列出可用话术，供业务员/运营挑选与学习回灌验证。
 * 入参 = 话术实体，响应 = 话术列表。
 */
public interface List extends ModelService<VideoScript, java.util.List<VideoScript>> {
}

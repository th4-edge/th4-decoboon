package com.th4.edge.decoboon.clue.video.service.scripts.list.support;

import com.th4.edge.decoboon.clue.video.configure.ScriptScene;
import com.th4.edge.decoboon.clue.video.model.VideoScript;
import com.th4.edge.decoboon.clue.video.repository.VideoScriptRepository;
import com.th4.edge.decoboon.clue.video.service.scripts.list.List;
import com.th4.edge.framework.core.annotation.Description;
import com.th4.edge.framework.core.annotation.Note;
import com.th4.edge.framework.provider.inject.annotation.AutoInject;
import com.th4.edge.framework.service.annotation.ServiceName;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

/**
 * 话术库列表实现：场景枚举名经 @AutoInject 注入（可选，不传返回全部启用话术）。
 */
@Note("话术库列表")
@Description("按场景列出可用话术（效果分高/使用次数少优先）")
@Service("decoboon/clue/video/script/list")
@ServiceName("list")
public class ListImpl implements List {

    /** 前端传入：场景枚举名（可选，如 WaterElectric） */
    @AutoInject
    private String scene;

    private final VideoScriptRepository scriptRepository;

    public ListImpl(VideoScriptRepository scriptRepository) {
        this.scriptRepository = scriptRepository;
    }

    @Override
    public java.util.List<VideoScript> call(VideoScript script) {
        if (StringUtils.hasText(scene)) {
            try {
                ScriptScene s = ScriptScene.valueOf(scene);
                return scriptRepository.findBySceneAndEnabledTrueOrderByScoreDescUseCountAsc(s);
            } catch (IllegalArgumentException e) {
                return java.util.List.of();
            }
        }
        return scriptRepository.findByEnabledTrueOrderByScoreDesc();
    }
}

package com.th4.edge.decoboon.clue.video.service.tasks.generate;

import com.th4.edge.decoboon.clue.video.model.VideoTask;
import com.th4.edge.framework.service.ModelService;

/**
 * 视频生成服务：业务员选模板+钩子+素材 → 创建 VideoTask → 异步驱动出片流水线。
 * 入参 = 生成任务实体（为 VideoTask 服务），响应 = 创建后的任务。
 */
public interface Generate extends ModelService<VideoTask, VideoTask> {
}

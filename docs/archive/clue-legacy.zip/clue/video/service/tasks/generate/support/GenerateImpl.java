package com.th4.edge.decoboon.clue.video.service.tasks.generate.support;

import com.th4.edge.decoboon.clue.company.model.Employee;
import com.th4.edge.decoboon.clue.company.repository.EmployeeRepository;
import com.th4.edge.decoboon.clue.video.configure.VideoState;
import com.th4.edge.decoboon.clue.video.configure.VideoTaskState;
import com.th4.edge.decoboon.clue.video.model.Template;
import com.th4.edge.decoboon.clue.video.model.Video;
import com.th4.edge.decoboon.clue.video.model.VideoTask;
import com.th4.edge.decoboon.clue.video.pipeline.VideoPipelineService;
import com.th4.edge.decoboon.clue.video.repository.TemplateRepository;
import com.th4.edge.decoboon.clue.video.repository.VideoRepository;
import com.th4.edge.decoboon.clue.video.repository.VideoTaskRepository;
import com.th4.edge.decoboon.clue.video.service.tasks.generate.Generate;
import com.th4.edge.framework.core.annotation.Description;
import com.th4.edge.framework.core.annotation.Note;
import com.th4.edge.framework.data.jackson.annotation.IgnoreProperties;
import com.th4.edge.framework.data.jackson.annotation.Properties;
import com.th4.edge.framework.data.jackson.annotation.ServiceProperties;
import com.th4.edge.framework.exception.DefaultErrorCode;
import com.th4.edge.framework.exception.DefinedException;
import com.th4.edge.framework.provider.inject.annotation.AutoInject;
import com.th4.edge.framework.provider.validation.annotation.Length;
import com.th4.edge.framework.provider.validation.annotation.NotNull;
import com.th4.edge.framework.service.annotation.ServiceName;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * 视频生成实现：前端提交字段经 @AutoInject 注入并校验，
 * 组装 业务员/模板/视频 对象关联后创建任务并异步驱动流水线。
 */
@Note("视频生成")
@Description("业务员选模板+钩子+素材 → 创建 VideoTask → 异步驱动出片流水线")
@ServiceProperties(
        uris = "decoboon/clue/video/generate",
        properties = @Properties(ignore = {
                @IgnoreProperties(model = Employee.class, properties = {"phone", "wechat", "displayCompanyName", "active"}),
                @IgnoreProperties(model = Video.class, properties = {"url", "size", "duration"})
        })
)
@Service("decoboon/clue/video/generate")
@ServiceName("generate")
public class GenerateImpl implements Generate {

    private static final Logger log = LoggerFactory.getLogger(GenerateImpl.class);

    /** 前端传入：业务员 */
    @AutoInject
    @NotNull
    private Long empId;

    /** 前端传入：模板 */
    @AutoInject
    @NotNull
    private Long tempId;

    /** 前端传入：选定的话题钩子 */
    @AutoInject
    @Length(max = 512)
    private String hook;

    /** 前端传入：素材图片ID列表 */
    @AutoInject
    @Length(max = 512)
    private String assetIds;

    /** 前端传入：视频标题 */
    @AutoInject
    @Length(max = 128)
    private String title;

    private final VideoRepository videoRepository;
    private final VideoTaskRepository taskRepository;
    private final TemplateRepository templateRepository;
    private final EmployeeRepository employeeRepository;
    private final VideoPipelineService pipeline;

    public GenerateImpl(VideoRepository videoRepository,
                        VideoTaskRepository taskRepository,
                        TemplateRepository templateRepository,
                        EmployeeRepository employeeRepository,
                        VideoPipelineService pipeline) {
        this.videoRepository = videoRepository;
        this.taskRepository = taskRepository;
        this.templateRepository = templateRepository;
        this.employeeRepository = employeeRepository;
        this.pipeline = pipeline;
    }

    @Override
    @Transactional
    public VideoTask call(VideoTask task) {
        Employee emp = employeeRepository.findByEmpId(empId);
        Template template = templateRepository.findByTempId(tempId);
        if (template == null || !Boolean.TRUE.equals(template.getEnabled())) {
            throw new DefinedException(new DefaultErrorCode("400", "模板不存在或未启用"));
        }

        Video video = new Video();
        video.setEmp(emp);
        video.setTemplate(template);
        video.setTitle(title);
        video.setState(VideoState.Draft);
        video = videoRepository.save(video);

        VideoTask created = new VideoTask();
        created.setEmp(emp);
        created.setVideo(video);
        created.setTemplate(template);
        created.setHook(hook);
        created.setAssetIds(assetIds);
        created.setState(VideoTaskState.Created);
        created.setRetryCount(0);
        created = taskRepository.save(created);

        log.info("[VideoGenerate] 任务{} 已创建（emp={}, temp={}），异步出片启动", created.getTaskId(), empId, tempId);
        // @Async 触发流水线
        pipeline.run(created);
        return created;
    }
}

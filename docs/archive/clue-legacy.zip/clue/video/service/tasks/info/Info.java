package com.th4.edge.decoboon.clue.video.service.tasks.info;

import com.th4.edge.decoboon.clue.video.model.VideoTask;
import com.th4.edge.framework.service.ModelService;

/**
 * 生成任务详情服务：按任务索引查询视频生成任务。
 * 入参 = 生成任务实体，响应 = 任务实体。
 */
public interface Info extends ModelService<VideoTask, VideoTask> {
}

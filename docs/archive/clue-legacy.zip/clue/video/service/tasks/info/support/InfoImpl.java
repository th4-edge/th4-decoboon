package com.th4.edge.decoboon.clue.video.service.tasks.info.support;

import com.th4.edge.decoboon.clue.company.model.Employee;
import com.th4.edge.decoboon.clue.video.model.Video;
import com.th4.edge.decoboon.clue.video.model.VideoTask;
import com.th4.edge.decoboon.clue.video.repository.VideoTaskRepository;
import com.th4.edge.decoboon.clue.video.service.tasks.info.Info;
import com.th4.edge.framework.core.annotation.Description;
import com.th4.edge.framework.core.annotation.Note;
import com.th4.edge.framework.data.jackson.annotation.IgnoreProperties;
import com.th4.edge.framework.data.jackson.annotation.Properties;
import com.th4.edge.framework.data.jackson.annotation.ServiceProperties;
import com.th4.edge.framework.exception.DefaultErrorCode;
import com.th4.edge.framework.exception.DefinedException;
import com.th4.edge.framework.provider.inject.annotation.AutoInject;
import com.th4.edge.framework.provider.validation.annotation.NotNull;
import com.th4.edge.framework.service.annotation.ServiceName;
import org.springframework.stereotype.Service;

/**
 * 生成任务详情实现：按任务索引查询（含 detail 进度 JSON，前端可轮询进度）。
 */
@Note("生成任务详情")
@Description("按任务索引查询视频生成任务详情")
@ServiceProperties(
        uris = "decoboon/clue/video/task/info",
        properties = @Properties(ignore = {
                @IgnoreProperties(model = Employee.class, properties = {"phone", "wechat", "displayCompanyName", "active", "company"}),
                @IgnoreProperties(model = Video.class, properties = {"cover", "size", "channel", "published"})
        })
)
@Service("decoboon/clue/video/task/info")
@ServiceName("info")
public class InfoImpl implements Info {

    /** 前端传入：任务索引 */
    @AutoInject
    @NotNull
    private Long taskId;

    private final VideoTaskRepository taskRepository;

    public InfoImpl(VideoTaskRepository taskRepository) {
        this.taskRepository = taskRepository;
    }

    @Override
    public VideoTask call(VideoTask task) {
        VideoTask exist = taskRepository.findByTaskId(taskId);
        if (exist == null) {
            throw new DefinedException(new DefaultErrorCode("400", "任务不存在"));
        }
        return exist;
    }
}

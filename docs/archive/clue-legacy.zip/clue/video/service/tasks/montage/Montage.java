package com.th4.edge.decoboon.clue.video.service.tasks.montage;

import com.th4.edge.decoboon.clue.video.model.VideoTask;
import com.th4.edge.framework.service.ModelService;

/**
 * 混剪任务创建服务：业务员选图片素材 → 创建 VideoTask（mode=Montage）→ 提交渲染调度器。
 * 入参 = 生成任务实体，响应 = 创建后的任务。
 */
public interface Montage extends ModelService<VideoTask, VideoTask> {
}

package com.th4.edge.decoboon.clue.video.service.tasks.montage.support;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.th4.edge.decoboon.clue.company.model.Employee;
import com.th4.edge.decoboon.clue.company.repository.EmployeeRepository;
import com.th4.edge.decoboon.clue.video.configure.VideoPipelineMode;
import com.th4.edge.decoboon.clue.video.configure.VideoState;
import com.th4.edge.decoboon.clue.video.configure.VideoTaskState;
import com.th4.edge.decoboon.clue.video.model.Video;
import com.th4.edge.decoboon.clue.video.model.VideoTask;
import com.th4.edge.decoboon.clue.video.repository.VideoRepository;
import com.th4.edge.decoboon.clue.video.repository.VideoTaskRepository;
import com.th4.edge.decoboon.clue.video.scheduler.VideoRenderScheduler;
import com.th4.edge.decoboon.clue.video.service.tasks.montage.Montage;
import com.th4.edge.framework.core.annotation.Description;
import com.th4.edge.framework.core.annotation.Note;
import com.th4.edge.framework.data.jackson.annotation.IgnoreProperties;
import com.th4.edge.framework.data.jackson.annotation.Properties;
import com.th4.edge.framework.data.jackson.annotation.ServiceProperties;
import com.th4.edge.framework.exception.DefaultErrorCode;
import com.th4.edge.framework.exception.DefinedException;
import com.th4.edge.framework.provider.inject.annotation.AutoInject;
import com.th4.edge.framework.provider.validation.annotation.Length;
import com.th4.edge.framework.provider.validation.annotation.NotEmpty;
import com.th4.edge.framework.provider.validation.annotation.NotNull;
import com.th4.edge.framework.service.annotation.ServiceName;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * 混剪任务创建实现：前端提交字段经 @AutoInject 注入并校验，
 * 组装 业务员/视频 对象关联后创建任务（detail 标记 mode=Montage），提交调度器异步渲染。
 */
@Note("混剪任务创建")
@Description("业务员选图片素材 → 创建混剪任务 → 提交渲染调度器异步出片")
@ServiceProperties(
        uris = "decoboon/clue/video/task/montage",
        properties = @Properties(ignore = {
                @IgnoreProperties(model = Employee.class, properties = {"phone", "wechat", "displayCompanyName", "active", "company"}),
                @IgnoreProperties(model = Video.class, properties = {"cover", "url", "size", "duration", "channel", "published"})
        })
)
@Service("decoboon/clue/video/task/montage")
@ServiceName("montage")
public class MontageImpl implements Montage {

    private static final Logger log = LoggerFactory.getLogger(MontageImpl.class);

    /** 前端传入：业务员 */
    @AutoInject
    @NotNull
    private Long empId;

    /** 前端传入：视频标题 */
    @AutoInject
    @Length(max = 128)
    private String title;

    /** 前端传入：素材图片ID列表 */
    @AutoInject
    @NotEmpty
    @Length(max = 512)
    private String assetIds;

    private final VideoRepository videoRepository;
    private final VideoTaskRepository taskRepository;
    private final EmployeeRepository employeeRepository;
    private final VideoRenderScheduler scheduler;
    private final ObjectMapper objectMapper;

    public MontageImpl(VideoRepository videoRepository,
                       VideoTaskRepository taskRepository,
                       EmployeeRepository employeeRepository,
                       VideoRenderScheduler scheduler,
                       ObjectMapper objectMapper) {
        this.videoRepository = videoRepository;
        this.taskRepository = taskRepository;
        this.employeeRepository = employeeRepository;
        this.scheduler = scheduler;
        this.objectMapper = objectMapper;
    }

    @Override
    @Transactional
    public VideoTask call(VideoTask task) {
        Employee emp = employeeRepository.findByEmpId(empId);
        if (emp == null) {
            throw new DefinedException(new DefaultErrorCode("400", "业务员不存在"));
        }

        Video video = new Video();
        video.setEmp(emp);
        video.setTitle(title == null || title.isBlank() ? "图片混剪" : title);
        video.setState(VideoState.Draft);
        video = videoRepository.save(video);

        VideoTask created = new VideoTask();
        created.setEmp(emp);
        created.setVideo(video);
        created.setState(VideoTaskState.Created);
        created.setRetryCount(0);
        created.setDetail(buildDetail(empId, video.getVideoId(), title));

        created = taskRepository.save(created);
        // 异步调度：创建只落库入队，渲染由调度器按配额执行，Provider 线程不阻塞
        scheduler.submit(created.getTaskId());
        log.info("[Montage] 任务{} 创建（emp={}, assets={}）已提交调度器", created.getTaskId(), empId, assetIds);
        return created;
    }

    /** detail 记录模式/业务员/视频关联，供调度器无懒加载地消费 */
    private String buildDetail(Long empId, Long videoId, String title) {
        try {
            Map<String, Object> d = new LinkedHashMap<>();
            d.put("mode", VideoPipelineMode.Montage.name());
            d.put("empId", empId);
            d.put("videoId", videoId);
            d.put("title", title);
            return objectMapper.writeValueAsString(d);
        } catch (Exception e) {
            log.warn("[Montage] detail 序列化失败，降级为模式标记", e);
            return "{\"mode\":\"" + VideoPipelineMode.Montage.name() + "\"}";
        }
    }
}

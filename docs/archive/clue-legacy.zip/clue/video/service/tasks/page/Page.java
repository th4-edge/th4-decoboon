package com.th4.edge.decoboon.clue.video.service.tasks.page;

import com.th4.edge.decoboon.clue.video.model.VideoTask;
import com.th4.edge.framework.service.ModelService;

/**
 * 生成任务分页服务：按通用查询语法分页查询视频生成任务。
 * 入参 = 生成任务实体，响应 = 任务分页。
 */
public interface Page extends ModelService<VideoTask, org.springframework.data.domain.Page<VideoTask>> {
}

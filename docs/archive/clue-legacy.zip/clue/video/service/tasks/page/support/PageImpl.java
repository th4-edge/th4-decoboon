package com.th4.edge.decoboon.clue.video.service.tasks.page.support;

import com.th4.edge.decoboon.clue.company.model.Employee;
import com.th4.edge.decoboon.clue.video.model.Video;
import com.th4.edge.decoboon.clue.video.model.VideoTask;
import com.th4.edge.decoboon.clue.video.service.tasks.page.Page;
import com.th4.edge.framework.core.annotation.Description;
import com.th4.edge.framework.core.annotation.Note;
import com.th4.edge.framework.data.jackson.annotation.IgnoreProperties;
import com.th4.edge.framework.data.jackson.annotation.Properties;
import com.th4.edge.framework.data.jackson.annotation.ServiceProperties;
import com.th4.edge.framework.service.annotation.ServiceName;
import com.th4.edge.framework.service.page.context.AbstractPage;
import jakarta.persistence.EntityManager;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

/**
 * 生成任务分页实现：继承框架分页骨架（Criteria 通用查询）。
 */
@Note("生成任务分页")
@Description("按通用查询语法分页查询视频生成任务")
@ServiceProperties(
        uris = "decoboon/clue/video/task/page",
        properties = @Properties(ignore = {
                @IgnoreProperties(model = Employee.class, properties = {"phone", "wechat", "displayCompanyName", "active", "company"}),
                @IgnoreProperties(model = Video.class, properties = {"cover", "url", "size", "duration", "channel", "published"})
        })
)
@Service("decoboon/clue/video/task/page")
@ServiceName("page")
@Scope("prototype")
public class PageImpl extends AbstractPage<VideoTask> implements Page {

    public PageImpl(EntityManager entityManager) {
        super(entityManager);
    }
}

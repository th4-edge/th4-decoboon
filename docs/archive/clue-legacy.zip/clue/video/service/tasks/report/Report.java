package com.th4.edge.decoboon.clue.video.service.tasks.report;

import com.th4.edge.decoboon.clue.video.model.VideoTask;
import com.th4.edge.framework.provider.Provider;

/**
 * 生成任务报表服务（统计类）：按状态聚合任务数量 + 调度器实时运行/排队数。
 * 入参 = 生成任务实体（仅占位），响应 = 报表 Vo。
 */
public interface Report extends Provider<VideoTask, VideoTaskReportVo> {
}

package com.th4.edge.decoboon.clue.video.service.tasks.report;

/**
 * 生成任务报表 Vo（统计类服务允许语义化结果对象）。
 */
public class VideoTaskReportVo {

    /** 任务总量 */
    private Long total;
    /** 排队中（Created） */
    private Long created;
    /** 渲染中（Rendering） */
    private Long rendering;
    /** 已完成（Done） */
    private Long done;
    /** 失败（Failed） */
    private Long failed;
    /** 调度器实时运行任务数 */
    private Integer running;
    /** 调度器排队任务数（混剪 Created 且未派发） */
    private Integer queued;

    public Long getTotal() {
        return total;
    }

    public void setTotal(Long total) {
        this.total = total;
    }

    public Long getCreated() {
        return created;
    }

    public void setCreated(Long created) {
        this.created = created;
    }

    public Long getRendering() {
        return rendering;
    }

    public void setRendering(Long rendering) {
        this.rendering = rendering;
    }

    public Long getDone() {
        return done;
    }

    public void setDone(Long done) {
        this.done = done;
    }

    public Long getFailed() {
        return failed;
    }

    public void setFailed(Long failed) {
        this.failed = failed;
    }

    public Integer getRunning() {
        return running;
    }

    public void setRunning(Integer running) {
        this.running = running;
    }

    public Integer getQueued() {
        return queued;
    }

    public void setQueued(Integer queued) {
        this.queued = queued;
    }
}

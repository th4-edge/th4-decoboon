package com.th4.edge.decoboon.clue.video.service.tasks.report.support;

import com.th4.edge.decoboon.clue.video.configure.VideoTaskState;
import com.th4.edge.decoboon.clue.video.model.VideoTask;
import com.th4.edge.decoboon.clue.video.repository.VideoTaskRepository;
import com.th4.edge.decoboon.clue.video.scheduler.VideoRenderScheduler;
import com.th4.edge.decoboon.clue.video.service.tasks.report.Report;
import com.th4.edge.decoboon.clue.video.service.tasks.report.VideoTaskReportVo;
import com.th4.edge.framework.core.annotation.Description;
import com.th4.edge.framework.core.annotation.Note;
import com.th4.edge.framework.service.annotation.ServiceName;
import org.springframework.stereotype.Service;

/**
 * 生成任务报表实现：状态计数 + 调度器实时指标。
 */
@Note("生成任务报表")
@Description("按状态聚合生成任务数量，并返回调度器实时运行/排队数")
@Service("decoboon/clue/video/task/report")
@ServiceName("report")
public class ReportImpl implements Report {

    private final VideoTaskRepository taskRepository;
    private final VideoRenderScheduler scheduler;

    public ReportImpl(VideoTaskRepository taskRepository, VideoRenderScheduler scheduler) {
        this.taskRepository = taskRepository;
        this.scheduler = scheduler;
    }

    @Override
    public VideoTaskReportVo call(VideoTask task) {
        VideoTaskReportVo vo = new VideoTaskReportVo();
        vo.setTotal(taskRepository.count());
        vo.setCreated(taskRepository.countByState(VideoTaskState.Created));
        vo.setRendering(taskRepository.countByState(VideoTaskState.Rendering));
        vo.setDone(taskRepository.countByState(VideoTaskState.Done));
        vo.setFailed(taskRepository.countByState(VideoTaskState.Failed));
        vo.setRunning(scheduler.runningCount());
        vo.setQueued(scheduler.queueCount());
        return vo;
    }
}

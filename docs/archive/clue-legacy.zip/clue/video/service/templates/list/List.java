package com.th4.edge.decoboon.clue.video.service.templates.list;

import com.th4.edge.decoboon.clue.video.model.Template;
import com.th4.edge.framework.service.ModelService;

/**
 * 模板列表服务：5 类内容模板及话题钩子列表（业务员选模板）。
 * 入参 = 模板实体，响应 = 模板列表。
 */
public interface List extends ModelService<Template, java.util.List<Template>> {
}

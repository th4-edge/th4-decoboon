package com.th4.edge.decoboon.clue.video.service.templates.list.support;

import com.th4.edge.decoboon.clue.video.configure.TemplateType;
import com.th4.edge.decoboon.clue.video.model.Template;
import com.th4.edge.decoboon.clue.video.repository.TemplateRepository;
import com.th4.edge.decoboon.clue.video.service.templates.list.List;
import com.th4.edge.framework.core.annotation.Description;
import com.th4.edge.framework.core.annotation.Note;
import com.th4.edge.framework.provider.inject.annotation.AutoInject;
import com.th4.edge.framework.service.annotation.ServiceName;
import org.springframework.stereotype.Service;

/**
 * 模板列表实现：模板类型经 @AutoInject 注入（不传则返回全部启用模板）。
 */
@Note("模板列表")
@Description("5 类内容模板及话题钩子列表（业务员选模板）")
@Service("decoboon/clue/video/template-list")
@ServiceName("list")
public class ListImpl implements List {

    /** 前端传入：模板类型（可选） */
    @AutoInject
    private TemplateType type;

    private final TemplateRepository templateRepository;

    public ListImpl(TemplateRepository templateRepository) {
        this.templateRepository = templateRepository;
    }

    @Override
    public java.util.List<Template> call(Template template) {
        if (type == null) {
            return templateRepository.findByEnabledTrueOrderByTempIdAsc();
        }
        return templateRepository.findByTypeAndEnabledTrue(type);
    }
}

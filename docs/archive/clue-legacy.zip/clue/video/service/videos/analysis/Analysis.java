package com.th4.edge.decoboon.clue.video.service.videos.analysis;

import com.th4.edge.decoboon.clue.video.model.Video;
import com.th4.edge.framework.provider.Provider;

/**
 * 视频智能分析服务（统计/分析类，允许语义化 Vo 响应）。
 * 入参 = 视频实体，响应 = 规则化分析结果。
 */
public interface Analysis extends Provider<Video, VideoAnalysisVo> {
}

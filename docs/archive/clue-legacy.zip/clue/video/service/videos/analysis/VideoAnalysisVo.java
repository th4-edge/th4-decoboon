package com.th4.edge.decoboon.clue.video.service.videos.analysis;

import com.th4.edge.framework.core.annotation.Note;

/**
 * 视频智能分析结果（统计/分析类语义化 Vo，非实体）。
 */
@Note("视频智能分析结果")
public class VideoAnalysisVo {

    @Note("规则化分析文本")
    private String content;

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}

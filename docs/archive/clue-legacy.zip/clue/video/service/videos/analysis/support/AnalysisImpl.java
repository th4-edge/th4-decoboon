package com.th4.edge.decoboon.clue.video.service.videos.analysis.support;

import com.th4.edge.decoboon.clue.video.model.Video;
import com.th4.edge.decoboon.clue.video.model.VideoStat;
import com.th4.edge.decoboon.clue.video.repository.VideoRepository;
import com.th4.edge.decoboon.clue.video.repository.VideoStatRepository;
import com.th4.edge.decoboon.clue.video.service.videos.analysis.Analysis;
import com.th4.edge.decoboon.clue.video.service.videos.analysis.VideoAnalysisVo;
import com.th4.edge.framework.core.annotation.Description;
import com.th4.edge.framework.core.annotation.Note;
import com.th4.edge.framework.exception.DefaultErrorCode;
import com.th4.edge.framework.exception.DefinedException;
import com.th4.edge.framework.provider.inject.annotation.AutoInject;
import com.th4.edge.framework.provider.validation.annotation.NotNull;
import com.th4.edge.framework.service.annotation.ServiceName;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 视频智能分析实现（一期规则化占位，不调用外部 AI）：
 * 聚合播放/评论/点赞/转发/线索数据，生成规则化中文分析文本。
 */
@Note("视频智能分析")
@Description("聚合视频数据并生成规则化分析文本（一期占位）")
@Service("decoboon/clue/video/analysis")
@ServiceName("analysis")
public class AnalysisImpl implements Analysis {

    @AutoInject
    @NotNull
    private Long videoId;

    private final VideoRepository videoRepository;
    private final VideoStatRepository videoStatRepository;

    public AnalysisImpl(VideoRepository videoRepository, VideoStatRepository videoStatRepository) {
        this.videoRepository = videoRepository;
        this.videoStatRepository = videoStatRepository;
    }

    @Override
    public VideoAnalysisVo call(Video video) {
        Video exist = videoRepository.findByVideoId(videoId);
        if (exist == null) {
            throw new DefinedException(new DefaultErrorCode("400", "视频不存在"));
        }

        List<VideoStat> stats = videoStatRepository.findByVideo_VideoId(videoId);

        long viewSum = 0L;
        long commentSum = 0L;
        long likeSum = 0L;
        long forwardSum = 0L;
        long leadSum = 0L;
        for (VideoStat stat : stats) {
            viewSum += stat.getViewCount() == null ? 0L : stat.getViewCount();
            commentSum += stat.getCommentCount() == null ? 0L : stat.getCommentCount();
            likeSum += stat.getLikeCount() == null ? 0L : stat.getLikeCount();
            forwardSum += stat.getForwardCount() == null ? 0L : stat.getForwardCount();
            leadSum += stat.getLeadCount() == null ? 0L : stat.getLeadCount();
        }

        StringBuilder sb = new StringBuilder();

        // 播放量评价
        if (viewSum < 100) {
            sb.append("播放量偏低，建议优化封面标题。");
        } else if (viewSum <= 1000) {
            sb.append("播放量中等，有提升空间。");
        } else {
            sb.append("播放量优秀，爆款潜质。");
        }

        // 互动率
        long interaction = commentSum + likeSum + forwardSum;
        double interactionRate = viewSum == 0L ? 0.0 : (interaction * 100.0 / viewSum);
        if (interactionRate < 1.0) {
            sb.append("互动率偏低，建议增加引导互动的话术。");
        } else if (interactionRate <= 5.0) {
            sb.append("互动率良好。");
        } else {
            sb.append("互动率优秀。");
        }

        // 线索转化
        if (leadSum > 0) {
            sb.append("已带来").append(leadSum).append("条线索，内容获客有效，建议持续产出同类内容。");
        } else {
            sb.append("暂未带来线索，建议在视频中增加联系方式引导。");
        }

        VideoAnalysisVo vo = new VideoAnalysisVo();
        vo.setContent(sb.toString());
        return vo;
    }
}

package com.th4.edge.decoboon.clue.video.service.videos.delist;

import com.th4.edge.decoboon.clue.video.model.Video;
import com.th4.edge.framework.provider.Provider;

/**
 * 视频下架抖音服务：入参 = 视频实体，响应 = 下架后的视频。
 */
public interface Delist extends Provider<Video, Video> {
}

package com.th4.edge.decoboon.clue.video.service.videos.delist.support;

import com.th4.edge.decoboon.clue.company.model.Employee;
import com.th4.edge.decoboon.clue.video.model.Video;
import com.th4.edge.decoboon.clue.video.repository.VideoRepository;
import com.th4.edge.decoboon.clue.video.service.videos.delist.Delist;
import com.th4.edge.framework.core.annotation.Description;
import com.th4.edge.framework.core.annotation.Note;
import com.th4.edge.framework.data.jackson.annotation.IgnoreProperties;
import com.th4.edge.framework.data.jackson.annotation.Properties;
import com.th4.edge.framework.data.jackson.annotation.ServiceProperties;
import com.th4.edge.framework.exception.DefaultErrorCode;
import com.th4.edge.framework.exception.DefinedException;
import com.th4.edge.framework.provider.inject.annotation.AutoInject;
import com.th4.edge.framework.provider.validation.annotation.NotNull;
import com.th4.edge.framework.service.annotation.ServiceName;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * 视频下架抖音实现：将视频标记为未上架抖音平台。
 */
@Note("视频下架抖音")
@Description("将已上架抖音的视频标记为下架")
@ServiceProperties(
        uris = "decoboon/clue/video/delist",
        properties = @Properties(ignore = {
                @IgnoreProperties(model = Employee.class, properties = {"phone", "wechat"})
        })
)
@Service("decoboon/clue/video/delist")
@ServiceName("delist")
public class DelistImpl implements Delist {

    @AutoInject
    @NotNull
    private Long videoId;

    private final VideoRepository videoRepository;

    public DelistImpl(VideoRepository videoRepository) {
        this.videoRepository = videoRepository;
    }

    @Override
    @Transactional
    public Video call(Video video) {
        Video exist = videoRepository.findByVideoId(videoId);
        if (exist == null) {
            throw new DefinedException(new DefaultErrorCode("400", "视频不存在"));
        }
        exist.setPublished(Boolean.FALSE);
        return videoRepository.save(exist);
    }
}

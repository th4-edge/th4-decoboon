package com.th4.edge.decoboon.clue.video.service.videos.upload;

import com.th4.edge.decoboon.clue.video.model.Video;
import com.th4.edge.framework.provider.Provider;

/**
 * 视频上架抖音服务：入参 = 视频实体，响应 = 上架后的视频。
 */
public interface Upload extends Provider<Video, Video> {
}
